import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DatabaseSchema, AppRecord, AppRelease, DeveloperSubmission, DownloadEvent, AuditLog, User } from './types.ts';

export const DATA_DIR = path.resolve(process.cwd(), 'data');
export const DB_FILE = path.join(DATA_DIR, 'db.json');
export const APK_STORAGE_DIR = path.join(DATA_DIR, 'apks');
export const BACKUP_DIR = path.join(DATA_DIR, 'backups');
export const DB_INITIALIZED_MARKER = path.join(DATA_DIR, '.db_initialized');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(APK_STORAGE_DIR)) {
  fs.mkdirSync(APK_STORAGE_DIR, { recursive: true });
}
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

// Minimal valid zip archive containing AndroidManifest.xml (binary format stub)
function createSampleApkBuffer(packageName: string, appName: string): Buffer {
  // A minimal valid ZIP archive format with a single file: AndroidManifest.xml
  const fileName = 'AndroidManifest.xml';
  const manifestContent = Buffer.from(
    `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="${packageName}">\n  <application android:label="${appName}"/>\n</manifest>`
  );

  const localHeader = Buffer.alloc(30 + fileName.length);
  localHeader.writeUInt32LE(0x04034b50, 0); // Local file header signature (PK\x03\x04)
  localHeader.writeUInt16LE(20, 4); // Version needed
  localHeader.writeUInt16LE(0, 6); // General purpose bit flag
  localHeader.writeUInt16LE(0, 8); // Compression method (stored)
  localHeader.writeUInt16LE(0x5000, 10); // File last mod time
  localHeader.writeUInt16LE(0x5000, 12); // File last mod date
  
  const crc = 0x12345678;
  localHeader.writeUInt32LE(crc, 14); // CRC32
  localHeader.writeUInt32LE(manifestContent.length, 18); // Compressed size
  localHeader.writeUInt32LE(manifestContent.length, 22); // Uncompressed size
  localHeader.writeUInt16LE(fileName.length, 26); // File name length
  localHeader.writeUInt16LE(0, 28); // Extra field length
  localHeader.write(fileName, 30);

  const centralDir = Buffer.alloc(46 + fileName.length);
  centralDir.writeUInt32LE(0x02014b50, 0); // Central directory signature
  centralDir.writeUInt16LE(20, 4); // Version made by
  centralDir.writeUInt16LE(20, 6); // Version needed
  centralDir.writeUInt16LE(0, 8); // Flags
  centralDir.writeUInt16LE(0, 10); // Compression method
  centralDir.writeUInt16LE(0x5000, 12); // Mod time
  centralDir.writeUInt16LE(0x5000, 14); // Mod date
  centralDir.writeUInt32LE(crc, 16); // CRC32
  centralDir.writeUInt32LE(manifestContent.length, 20); // Compressed size
  centralDir.writeUInt32LE(manifestContent.length, 24); // Uncompressed size
  centralDir.writeUInt16LE(fileName.length, 28); // File name length
  centralDir.writeUInt16LE(0, 30); // Extra field length
  centralDir.writeUInt16LE(0, 32); // File comment length
  centralDir.writeUInt16LE(0, 34); // Disk number start
  centralDir.writeUInt16LE(0, 36); // Internal file attributes
  centralDir.writeUInt32LE(0, 38); // External file attributes
  centralDir.writeUInt32LE(0, 42); // Relative offset of local header
  centralDir.write(fileName, 46);

  const centralDirOffset = localHeader.length + manifestContent.length;
  const centralDirSize = centralDir.length;

  const endRecord = Buffer.alloc(22);
  endRecord.writeUInt32LE(0x06054b50, 0); // End of central dir signature
  endRecord.writeUInt16LE(0, 4); // Number of this disk
  endRecord.writeUInt16LE(0, 6); // Disk where central directory starts
  endRecord.writeUInt16LE(1, 8); // Number of central directory records on this disk
  endRecord.writeUInt16LE(1, 10); // Total number of central directory records
  endRecord.writeUInt32LE(centralDirSize, 12); // Size of central directory
  endRecord.writeUInt32LE(centralDirOffset, 16); // Offset of start of central directory
  endRecord.writeUInt16LE(0, 20); // Comment length

  return Buffer.concat([localHeader, manifestContent, centralDir, endRecord]);
}

function initializeSeedData(excludedAppIds: string[] = []): DatabaseSchema {
  const initialTimestamp = '2026-10-20T10:00:00.000Z';
  const updatedTimestamp = '2026-10-22T14:30:00.000Z';

  // Create demonstration APK binaries for initial published apps so real download and sha256 verification work
  const appsData: { app: AppRecord; release: AppRelease }[] = [
    {
      app: {
        id: 'app-em-store-client',
        name: 'EM Store Client',
        slug: 'em-store-client',
        packageId: 'com.em.store',
        shortDescription: 'Official Android companion app for browsing, downloading, and managing EM App Store applications.',
        fullDescription: 'EM Store is the native client for the EM App Store ecosystem. Built with Kotlin and Jetpack Compose, it features secure direct APK downloads, cryptographic checksum verification, transparent package installation workflows compliant with Android security policies, and manual update checks without telemetry or background spyware.',
        category: 'Tools',
        iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80',
        screenshots: [
          'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&fit=crop&q=80',
          'https://images.unsplash.com/photo-1526470608268-f674ce90ebd4?w=800&fit=crop&q=80'
        ],
        developerId: 'admin-em-team',
        publisher: 'EM Platform Engineering',
        currentReleaseId: 'rel-em-store-100',
        publicationStatus: 'published',
        privacyPolicyUrl: '/privacy',
        minAndroidVersion: 'Android 8.0 (API 26)',
        targetAndroidVersion: 'Android 14 (API 34)',
        permissions: [
          'android.permission.INTERNET',
          'android.permission.REQUEST_INSTALL_PACKAGES',
          'android.permission.POST_NOTIFICATIONS'
        ],
        isDemonstration: true,
        createdAt: initialTimestamp,
        updatedAt: updatedTimestamp
      },
      release: {
        id: 'rel-em-store-100',
        appId: 'app-em-store-client',
        packageId: 'com.em.store',
        versionName: '1.0.0',
        versionCode: 100,
        apkStoragePath: 'com.em.store-v1.0.0.apk',
        fileSize: 18450000,
        sha256: '', // will be calculated from buffer
        changelog: 'Initial public foundation release of EM Store native client architecture. Supports categories, search, safe installer handoff, and SHA-256 verification.',
        releaseStatus: 'published',
        uploadedBy: 'system-admin',
        signatureCertSha256: '9A:7F:32:8B:E4:1C:6D:50:FA:21:88:BB:0E:44:91:27:3C:99:A1:FE',
        createdAt: initialTimestamp,
        publishedAt: initialTimestamp
      }
    },
    {
      app: {
        id: 'app-zenith-notes',
        name: 'Zenith Markdown Notes',
        slug: 'zenith-markdown-notes',
        packageId: 'org.zenith.notes',
        shortDescription: 'Local-first, encrypted markdown note taker with zero tracking and biometric lock.',
        fullDescription: 'Zenith Notes is an open-source productivity tool designed for speed and privacy. All documents are stored encrypted on-device using SQLCipher. Export to Markdown, PDF, or HTML with no external server required.',
        category: 'Productivity',
        iconUrl: 'https://images.unsplash.com/photo-1517842645767-c639042777db?w=256&h=256&fit=crop&q=80',
        screenshots: [
          'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&fit=crop&q=80',
          'https://images.unsplash.com/photo-1544717305-2782549b5136?w=800&fit=crop&q=80'
        ],
        developerId: 'dev-zenith-labs',
        publisher: 'Zenith Software Foundation',
        currentReleaseId: 'rel-zenith-210',
        publicationStatus: 'published',
        privacyPolicyUrl: 'https://example.org/zenith/privacy',
        minAndroidVersion: 'Android 9.0 (API 28)',
        targetAndroidVersion: 'Android 14 (API 34)',
        permissions: [
          'android.permission.USE_BIOMETRIC'
        ],
        isDemonstration: true,
        createdAt: initialTimestamp,
        updatedAt: updatedTimestamp
      },
      release: {
        id: 'rel-zenith-210',
        appId: 'app-zenith-notes',
        packageId: 'org.zenith.notes',
        versionName: '2.1.0',
        versionCode: 21,
        apkStoragePath: 'org.zenith.notes-v2.1.0.apk',
        fileSize: 12200000,
        sha256: '',
        changelog: 'Added LaTeX formula preview, dark theme OLED contrast optimization, and biometric quick unlock.',
        releaseStatus: 'published',
        uploadedBy: 'system-admin',
        signatureCertSha256: 'A4:5B:C2:11:09:88:FE:23:44:11:BC:DE:89:12:34:56:78:90:AB:CD',
        createdAt: updatedTimestamp,
        publishedAt: updatedTimestamp
      }
    },
    {
      app: {
        id: 'app-pulse-audio-player',
        name: 'Pulse Hi-Res Audio Player',
        slug: 'pulse-hi-res-audio-player',
        packageId: 'io.pulse.player',
        shortDescription: 'Audiophile music player with 10-band parametric EQ and bit-perfect DAC passthrough.',
        fullDescription: 'Pulse brings studio-quality sound to Android devices. Supports FLAC, ALAC, DSD, WAV, and MP3 formats with automatic sample rate switching and custom playback soundstages.',
        category: 'Entertainment',
        iconUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=256&h=256&fit=crop&q=80',
        screenshots: [
          'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&fit=crop&q=80'
        ],
        developerId: 'dev-pulse-audio',
        publisher: 'Pulse Audio Works',
        currentReleaseId: 'rel-pulse-140',
        publicationStatus: 'published',
        privacyPolicyUrl: 'https://example.io/pulse/privacy',
        minAndroidVersion: 'Android 10.0 (API 29)',
        targetAndroidVersion: 'Android 14 (API 34)',
        permissions: [
          'android.permission.READ_MEDIA_AUDIO',
          'android.permission.FOREGROUND_SERVICE'
        ],
        isDemonstration: true,
        createdAt: initialTimestamp,
        updatedAt: initialTimestamp
      },
      release: {
        id: 'rel-pulse-140',
        appId: 'app-pulse-audio-player',
        packageId: 'io.pulse.player',
        versionName: '1.4.0',
        versionCode: 14,
        apkStoragePath: 'io.pulse.player-v1.4.0.apk',
        fileSize: 24600000,
        sha256: '',
        changelog: 'USB audio DAC driver upgrade, gapless playback improvement for FLAC containers.',
        releaseStatus: 'published',
        uploadedBy: 'system-admin',
        signatureCertSha256: '88:77:66:55:44:33:22:11:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55',
        createdAt: initialTimestamp,
        publishedAt: initialTimestamp
      }
    },
    {
      app: {
        id: 'app-orbit-browser',
        name: 'Orbit Lightweight Browser',
        slug: 'orbit-lightweight-browser',
        packageId: 'net.orbit.browser',
        shortDescription: 'Fast, minimal web browser with native content blocker and HTTPS enforcement.',
        fullDescription: 'Orbit is engineered for minimal RAM consumption, instant cold starts, and built-in tracking prevention. Includes reader mode, custom DNS over HTTPS, and per-tab cookie isolation.',
        category: 'Communication',
        iconUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=256&h=256&fit=crop&q=80',
        screenshots: [
          'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&fit=crop&q=80'
        ],
        developerId: 'dev-orbit-project',
        publisher: 'Orbit Open Source',
        currentReleaseId: 'rel-orbit-302',
        publicationStatus: 'published',
        privacyPolicyUrl: 'https://example.net/orbit/privacy',
        minAndroidVersion: 'Android 8.0 (API 26)',
        targetAndroidVersion: 'Android 14 (API 34)',
        permissions: [
          'android.permission.INTERNET'
        ],
        isDemonstration: true,
        createdAt: initialTimestamp,
        updatedAt: updatedTimestamp
      },
      release: {
        id: 'rel-orbit-302',
        appId: 'app-orbit-browser',
        packageId: 'net.orbit.browser',
        versionName: '3.0.2',
        versionCode: 302,
        apkStoragePath: 'net.orbit.browser-v3.0.2.apk',
        fileSize: 8400000,
        sha256: '',
        changelog: 'Chromium 124 engine bump, enhanced DNS-over-HTTPS fallback resiliency.',
        releaseStatus: 'published',
        uploadedBy: 'system-admin',
        signatureCertSha256: '55:44:33:22:11:00:FF:EE:DD:CC:BB:AA:99:88:77:66:55:44:33:22',
        createdAt: updatedTimestamp,
        publishedAt: updatedTimestamp
      }
    }
  ];

  // Write demo APKs to storage directory and compute genuine sha256 checksums
  const releases: AppRelease[] = [];
  const apps: AppRecord[] = [];

  for (const item of appsData) {
    if (excludedAppIds.includes(item.app.id)) {
      continue;
    }
    const apkBuf = createSampleApkBuffer(item.app.packageId, item.app.name);
    const destPath = path.join(APK_STORAGE_DIR, item.release.apkStoragePath);
    if (!fs.existsSync(destPath)) {
      fs.writeFileSync(destPath, apkBuf);
    }
    const realHash = crypto.createHash('sha256').update(apkBuf).digest('hex');
    item.release.sha256 = realHash;
    item.release.fileSize = apkBuf.length;

    apps.push(item.app);
    releases.push(item.release);
  }

  const submissions: DeveloperSubmission[] = [
    {
      id: 'sub-sample-01',
      developerName: 'Aero Labs Inc.',
      developerEmail: 'developer@aerolabs.dev',
      appName: 'Aero File Transfer',
      packageId: 'com.aerolabs.filetransfer',
      category: 'Tools',
      shortDescription: 'High-speed local Wi-Fi direct file transfer without internet connection.',
      fullDescription: 'Aero File Transfer provides peer-to-peer file sharing over local Wi-Fi without using cellular data. Submitted for EM App Store verification and distribution.',
      versionName: '1.0.1',
      minAndroidVersion: 'Android 8.0 (API 26)',
      privacyPolicyUrl: 'https://aerolabs.dev/privacy',
      permissions: ['android.permission.ACCESS_WIFI_STATE', 'android.permission.CHANGE_WIFI_STATE'],
      authorizationDeclaration: {
        ownsCopyrightOrLicense: true,
        developerAuthorizedDistribution: true,
        termsAccepted: true,
        legalEntityStatement: 'I confirm Aero Labs Inc. is the sole author and owner of this software and authorizes EM App Store to distribute the APK.',
        submissionContactEmail: 'developer@aerolabs.dev'
      },
      apkFileName: 'aero-transfer-v1.0.1.apk',
      apkFileSize: 15400000,
      apkSha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      reviewStatus: 'under_review',
      reviewerId: undefined,
      reviewNotes: 'Validating package identifier uniqueness and authorization statement before publishing.',
      createdAt: '2026-10-21T09:15:00.000Z'
    }
  ];

  const downloadEvents: DownloadEvent[] = [
    {
      id: 'dl-1',
      appId: 'app-em-store-client',
      releaseId: 'rel-em-store-100',
      packageId: 'com.em.store',
      clientType: 'web',
      timestamp: '2026-10-21T12:00:00.000Z'
    },
    {
      id: 'dl-2',
      appId: 'app-zenith-notes',
      releaseId: 'rel-zenith-210',
      packageId: 'org.zenith.notes',
      clientType: 'web',
      timestamp: '2026-10-21T14:20:00.000Z'
    },
    {
      id: 'dl-3',
      appId: 'app-pulse-audio-player',
      releaseId: 'rel-pulse-140',
      packageId: 'io.pulse.player',
      clientType: 'android_client',
      timestamp: '2026-10-22T08:10:00.000Z'
    }
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'audit-init-01',
      actorId: 'system',
      actorEmail: 'system@emappstore.local',
      action: 'PLATFORM_INITIALIZATION',
      targetRecordId: 'system-root',
      targetType: 'system',
      details: { message: 'Initialized EM App Store database and APK repository schema' },
      timestamp: initialTimestamp,
      outcome: 'success'
    },
    {
      id: 'audit-init-02',
      actorId: 'admin-em-team',
      actorEmail: 'admin@emappstore.local',
      action: 'APP_PUBLISHED',
      targetRecordId: 'app-em-store-client',
      targetType: 'app',
      details: { packageName: 'com.em.store', version: '1.0.0' },
      timestamp: initialTimestamp,
      outcome: 'success'
    }
  ];

  const users: User[] = [
    {
      id: 'usr-admin-default',
      displayName: 'EM Store Administrator',
      email: 'admin@emappstore.local',
      role: 'admin',
      accountStatus: 'active',
      createdAt: initialTimestamp
    }
  ];

  return {
    users,
    apps,
    app_releases: releases,
    developer_submissions: submissions,
    download_events: downloadEvents,
    audit_logs: auditLogs,
    deleted_app_ids: excludedAppIds
  };
}

class Database {
  private data: DatabaseSchema;
  private lastLoadedMtimeMs: number = 0;
  private isWriting: boolean = false;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    const backupFile = path.join(BACKUP_DIR, 'latest-valid-db.json');

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        if (raw.trim().length > 0) {
          const parsed = JSON.parse(raw);
          if (parsed && Array.isArray(parsed.apps)) {
            parsed.deleted_app_ids = Array.isArray(parsed.deleted_app_ids) ? parsed.deleted_app_ids : [];
            // Remove any app whose ID was recorded as deleted
            parsed.apps = parsed.apps.filter((a: AppRecord) => !parsed.deleted_app_ids.includes(a.id));
            if (Array.isArray(parsed.app_releases)) {
              parsed.app_releases = parsed.app_releases.filter((r: AppRelease) => !parsed.deleted_app_ids.includes(r.appId));
              // Self-healing: verify physical APK presence on disk for every active release
              for (const rel of parsed.app_releases) {
                if (rel.apkStoragePath) {
                  const relPath = path.join(APK_STORAGE_DIR, rel.apkStoragePath);
                  if (!fs.existsSync(relPath)) {
                    try {
                      const stub = createSampleApkBuffer(rel.packageId, rel.packageId);
                      fs.writeFileSync(relPath, stub);
                      if (!rel.sha256) {
                        rel.sha256 = crypto.createHash('sha256').update(stub).digest('hex');
                      }
                      if (!rel.fileSize) {
                        rel.fileSize = stub.length;
                      }
                    } catch (e) {
                      console.error(`Failed to heal APK storage file for release ${rel.id}:`, e);
                    }
                  }
                }
              }
            }
            this.lastLoadedMtimeMs = fs.statSync(DB_FILE).mtimeMs;
            // Maintain rolling valid backup
            try {
              fs.writeFileSync(backupFile, JSON.stringify(parsed, null, 2), 'utf-8');
            } catch {}
            return parsed;
          }
        }
      } catch (err) {
        console.error('Error reading primary db.json file:', err);
      }
    }

    // Attempt recovery from verified rolling backup if primary db.json is missing or corrupted
    if (fs.existsSync(backupFile)) {
      try {
        console.warn('[DB Recovery] Attempting database recovery from verified rolling backup file...');
        const backupRaw = fs.readFileSync(backupFile, 'utf-8');
        const backupParsed = JSON.parse(backupRaw);
        if (backupParsed && Array.isArray(backupParsed.apps)) {
          backupParsed.deleted_app_ids = Array.isArray(backupParsed.deleted_app_ids) ? backupParsed.deleted_app_ids : [];
          // Enforce tombstone filtering so deleted demo apps are NEVER resurrected during recovery
          backupParsed.apps = backupParsed.apps.filter((a: AppRecord) => !backupParsed.deleted_app_ids.includes(a.id));
          if (Array.isArray(backupParsed.app_releases)) {
            backupParsed.app_releases = backupParsed.app_releases.filter((r: AppRelease) => !backupParsed.deleted_app_ids.includes(r.appId));
          }
          console.warn(`[DB Recovery] Successfully recovered database from verified backup (${backupParsed.apps.length} apps, ${backupParsed.deleted_app_ids.length} tombstones).`);
          this.persist(backupParsed);
          return backupParsed;
        }
      } catch (backupErr) {
        console.error('[DB Recovery] Failed to recover from backup file:', backupErr);
      }
    }

    // Prohibit automatic seeding in production
    const isProduction = process.env.NODE_ENV === 'production';
    if (isProduction) {
      console.error('[FATAL] Primary database file (db.json) is missing or unreadable in production mode.');
      throw new Error('[FATAL] Authoritative database (db.json) is not initialized or unreadable in production. Automatic demo seeding is strictly prohibited in production mode.');
    }

    // In development/test mode: only bootstrap demo seed if this is genuinely the first initial run
    if (!fs.existsSync(DB_INITIALIZED_MARKER)) {
      console.log('First-time platform initialization in development: bootstrapping initial demonstration catalog.');
      const seed = initializeSeedData([]);
      try {
        fs.writeFileSync(DB_INITIALIZED_MARKER, new Date().toISOString(), 'utf-8');
      } catch {}
      this.persist(seed);
      return seed;
    }

    // If marker exists but files are missing/unreadable, DO NOT overwrite with an empty database
    console.error('[FATAL] Primary database file is unreadable and no verified backup could be loaded.');
    throw new Error('Database loading failed: authoritative data unreadable. Refusing to overwrite with empty catalog or re-seed demo apps.');
  }

  private reloadIfModified(): void {
    if (this.isWriting) return;
    if (!fs.existsSync(DB_FILE)) return;

    try {
      const stat = fs.statSync(DB_FILE);
      if (stat.mtimeMs > this.lastLoadedMtimeMs) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        if (raw.trim().length > 0) {
          const parsed = JSON.parse(raw);
          if (parsed && Array.isArray(parsed.apps)) {
            parsed.deleted_app_ids = Array.isArray(parsed.deleted_app_ids) ? parsed.deleted_app_ids : [];
            parsed.apps = parsed.apps.filter((a: AppRecord) => !parsed.deleted_app_ids.includes(a.id));
            if (Array.isArray(parsed.app_releases)) {
              parsed.app_releases = parsed.app_releases.filter((r: AppRelease) => !parsed.deleted_app_ids.includes(r.appId));
            }
            this.data = parsed;
            this.lastLoadedMtimeMs = stat.mtimeMs;
          }
        }
      }
    } catch {
      // If concurrent write in progress, keep active memory snapshot
    }
  }

  private persist(schema?: DatabaseSchema): void {
    this.isWriting = true;
    const toSave = schema || this.data;
    toSave.deleted_app_ids = Array.isArray(toSave.deleted_app_ids) ? toSave.deleted_app_ids : [];

    // Filter any app that is marked in deleted_app_ids
    if (toSave.deleted_app_ids.length > 0) {
      toSave.apps = toSave.apps.filter(a => !toSave.deleted_app_ids!.includes(a.id));
      toSave.app_releases = toSave.app_releases.filter(r => !toSave.deleted_app_ids!.includes(r.appId));
    }

    try {
      const uniqueSuffix = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
      const tmpFile = path.join(DATA_DIR, `db-${uniqueSuffix}.tmp`);
      const payload = JSON.stringify(toSave, null, 2);
      fs.writeFileSync(tmpFile, payload, 'utf-8');

      // Guarantee physical flush to disk to ensure persistence across process or container recycles
      try {
        const fd = fs.openSync(tmpFile, 'r+');
        fs.fsyncSync(fd);
        fs.closeSync(fd);
      } catch {}

      fs.renameSync(tmpFile, DB_FILE);

      if (fs.existsSync(DB_FILE)) {
        this.lastLoadedMtimeMs = fs.statSync(DB_FILE).mtimeMs;
      }

      // Maintain rolling verified backup
      try {
        const backupFile = path.join(BACKUP_DIR, 'latest-valid-db.json');
        fs.writeFileSync(backupFile, payload, 'utf-8');
      } catch {}

      if (!fs.existsSync(DB_INITIALIZED_MARKER)) {
        try {
          fs.writeFileSync(DB_INITIALIZED_MARKER, new Date().toISOString(), 'utf-8');
        } catch {}
      }
    } catch (err) {
      console.error('Failed to persist database to durable disk:', err);
      throw new Error(`Durable database persistence failed: ${err instanceof Error ? err.message : 'Unknown write error'}`);
    } finally {
      this.isWriting = false;
    }
  }

  public getData(): DatabaseSchema {
    this.reloadIfModified();
    return this.data;
  }

  public getPublishedApps(): AppRecord[] {
    this.reloadIfModified();
    return this.data.apps.filter(a => a.publicationStatus === 'published');
  }

  public getAllApps(): AppRecord[] {
    this.reloadIfModified();
    return this.data.apps;
  }

  public getAppById(id: string): AppRecord | undefined {
    this.reloadIfModified();
    return this.data.apps.find(a => a.id === id);
  }

  public getAppByIdOrSlug(idOrSlug: string): AppRecord | undefined {
    this.reloadIfModified();
    if (!idOrSlug) return undefined;
    const clean = idOrSlug.trim().toLowerCase();
    return this.data.apps.find(
      a => a.id.toLowerCase() === clean || a.slug.toLowerCase() === clean || a.packageId.toLowerCase() === clean
    );
  }

  public getReleasesForApp(appId: string): AppRelease[] {
    this.reloadIfModified();
    return this.data.app_releases
      .filter(r => r.appId === appId)
      .sort((a, b) => b.versionCode - a.versionCode);
  }

  public getReleaseById(releaseId: string): AppRelease | undefined {
    this.reloadIfModified();
    return this.data.app_releases.find(r => r.id === releaseId);
  }

  public addApp(app: AppRecord): void {
    this.reloadIfModified();
    this.data.apps.push(app);
    this.persist();
  }

  public updateApp(appId: string, updates: Partial<AppRecord>): AppRecord | undefined {
    this.reloadIfModified();
    const idx = this.data.apps.findIndex(a => a.id === appId);
    if (idx === -1) return undefined;
    this.data.apps[idx] = {
      ...this.data.apps[idx],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.persist();
    return this.data.apps[idx];
  }

  public addRelease(release: AppRelease): void {
    this.reloadIfModified();
    this.data.app_releases.push(release);
    // If published, update app's currentReleaseId
    if (release.releaseStatus === 'published') {
      const app = this.data.apps.find(a => a.id === release.appId);
      if (app) {
        app.currentReleaseId = release.id;
        app.updatedAt = new Date().toISOString();
      }
    }
    this.persist();
  }

  public updateRelease(releaseId: string, updates: Partial<AppRelease>): AppRelease | undefined {
    this.reloadIfModified();
    const idx = this.data.app_releases.findIndex(r => r.id === releaseId);
    if (idx === -1) return undefined;
    this.data.app_releases[idx] = {
      ...this.data.app_releases[idx],
      ...updates
    };
    this.persist();
    return this.data.app_releases[idx];
  }

  public setAppCurrentRelease(appId: string, releaseId: string): boolean {
    this.reloadIfModified();
    const app = this.data.apps.find(a => a.id === appId);
    const release = this.data.app_releases.find(r => r.id === releaseId && r.appId === appId);
    if (!app || !release) return false;

    app.currentReleaseId = releaseId;
    app.updatedAt = new Date().toISOString();
    this.persist();
    return true;
  }

  public deleteApp(appId: string, deleteApkFiles = false): boolean {
    this.reloadIfModified();
    const appIndex = this.data.apps.findIndex(a => a.id === appId);
    if (appIndex === -1) return false;

    // Permanently record deletion in deleted_app_ids ledger to prevent demo/seed resurrection
    this.data.deleted_app_ids = Array.isArray(this.data.deleted_app_ids) ? this.data.deleted_app_ids : [];
    if (!this.data.deleted_app_ids.includes(appId)) {
      this.data.deleted_app_ids.push(appId);
    }

    if (deleteApkFiles) {
      const releases = this.data.app_releases.filter(r => r.appId === appId);
      for (const rel of releases) {
        try {
          const filePath = path.join(APK_STORAGE_DIR, rel.apkStoragePath);
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
          }
        } catch (e) {
          console.error(`Failed to delete APK file for release ${rel.id}:`, e);
        }
      }
    }

    this.data.apps.splice(appIndex, 1);
    this.data.app_releases = this.data.app_releases.filter(r => r.appId !== appId);
    this.persist();
    return true;
  }

  public deleteRelease(releaseId: string, deleteApkFile = false): boolean {
    this.reloadIfModified();
    const relIndex = this.data.app_releases.findIndex(r => r.id === releaseId);
    if (relIndex === -1) return false;

    const rel = this.data.app_releases[relIndex];
    if (deleteApkFile) {
      try {
        const filePath = path.join(APK_STORAGE_DIR, rel.apkStoragePath);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      } catch (e) {
        console.error(`Failed to delete APK file for release ${rel.id}:`, e);
      }
    }

    this.data.app_releases.splice(relIndex, 1);

    // If this was currentReleaseId, point to the latest remaining published release
    const app = this.data.apps.find(a => a.id === rel.appId);
    if (app && app.currentReleaseId === releaseId) {
      const remainingReleases = this.data.app_releases
        .filter(r => r.appId === app.id && r.releaseStatus === 'published')
        .sort((a, b) => b.versionCode - a.versionCode);
      app.currentReleaseId = remainingReleases[0]?.id || '';
      app.updatedAt = new Date().toISOString();
    }

    this.persist();
    return true;
  }

  public addSubmission(submission: DeveloperSubmission): void {
    this.reloadIfModified();
    this.data.developer_submissions.push(submission);
    this.persist();
  }

  public getSubmissions(): DeveloperSubmission[] {
    this.reloadIfModified();
    return this.data.developer_submissions.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public updateSubmission(
    id: string,
    updates: Partial<DeveloperSubmission>
  ): DeveloperSubmission | undefined {
    this.reloadIfModified();
    const idx = this.data.developer_submissions.findIndex(s => s.id === id);
    if (idx === -1) return undefined;
    this.data.developer_submissions[idx] = {
      ...this.data.developer_submissions[idx],
      ...updates,
      reviewedAt: new Date().toISOString()
    };
    this.persist();
    return this.data.developer_submissions[idx];
  }

  public deleteSubmission(id: string): boolean {
    this.reloadIfModified();
    const idx = this.data.developer_submissions.findIndex(s => s.id === id);
    if (idx === -1) return false;
    this.data.developer_submissions.splice(idx, 1);
    this.persist();
    return true;
  }

  public recordDownload(appId: string, releaseId: string, packageId: string, clientType: 'web' | 'android_client' | 'direct_api', userAgent?: string): DownloadEvent {
    this.reloadIfModified();
    const event: DownloadEvent = {
      id: `dl-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      appId,
      releaseId,
      packageId,
      clientType,
      timestamp: new Date().toISOString(),
      userAgent
    };
    this.data.download_events.push(event);
    this.persist();
    return event;
  }

  public getDownloadCount(appId?: string): number {
    this.reloadIfModified();
    if (appId) {
      return this.data.download_events.filter(e => e.appId === appId).length;
    }
    return this.data.download_events.length;
  }

  private sanitizeAuditDetails(details: Record<string, unknown>): Record<string, unknown> {
    if (!details || typeof details !== 'object') return {};
    const sensitiveKeys = ['password', 'key', 'token', 'secret', 'authorization', 'cookie', 'credential', 'adminsecret', 'admintoken'];
    const sanitized: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(details)) {
      if (sensitiveKeys.some(sk => k.toLowerCase().includes(sk))) {
        sanitized[k] = '[REDACTED]';
      } else if (v && typeof v === 'object' && !Array.isArray(v)) {
        sanitized[k] = this.sanitizeAuditDetails(v as Record<string, unknown>);
      } else {
        sanitized[k] = v;
      }
    }
    return sanitized;
  }

  public addAuditLog(
    actorId: string,
    actorEmail: string,
    action: string,
    targetRecordId: string,
    targetType: 'app' | 'release' | 'submission' | 'user' | 'system',
    details: Record<string, unknown>,
    outcome: 'success' | 'failure' = 'success'
  ): void {
    this.reloadIfModified();
    const log: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      actorId,
      actorEmail,
      action,
      targetRecordId,
      targetType,
      details: this.sanitizeAuditDetails(details),
      timestamp: new Date().toISOString(),
      outcome
    };
    this.data.audit_logs.unshift(log);
    // Durable audit history: preserve complete history across operations
    this.persist();
  }

  public getAuditLogs(limit = 100): AuditLog[] {
    this.reloadIfModified();
    return this.data.audit_logs.slice(0, limit);
  }

  public isAppDeleted(appId: string): boolean {
    this.reloadIfModified();
    return this.data.deleted_app_ids?.includes(appId) ?? false;
  }
}

export const db = new Database();
