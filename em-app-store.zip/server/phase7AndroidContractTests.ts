import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db } from './db.ts';

const BASE_URL = 'http://localhost:3000';

async function runPhase7AndroidContractTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 7: NATIVE ANDROID API & DOWNLOAD CONTRACT SUITE');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  const initialAppsCount = db.getData().apps.length;
  const initialReleasesCount = db.getData().app_releases.length;
  const initialPublishedCount = db.getPublishedApps().length;

  // 1. GET /api/apps conforms strictly to Android AppListResponse model
  await step('Test 1: GET /api/apps conforms strictly to Android AppListResponse model', async () => {
    const res = await fetch(`${BASE_URL}/api/apps`);
    assert.strictEqual(res.status, 200, 'GET /api/apps must return 200');
    assert.ok(res.headers.get('content-type')?.includes('application/json'), 'Content-Type must be JSON');

    const data = await res.json();
    assert.ok(Array.isArray(data.apps), 'data.apps must be an array');
    assert.strictEqual(typeof data.total, 'number', 'data.total must be a number');
    assert.ok(data.apps.length > 0, 'data.apps must contain published apps');

    for (const app of data.apps) {
      assert.strictEqual(typeof app.id, 'string', 'app.id must be a string');
      assert.strictEqual(typeof app.name, 'string', 'app.name must be a string');
      assert.strictEqual(typeof app.packageId, 'string', 'app.packageId must be a string');
      assert.strictEqual(typeof app.category, 'string', 'app.category must be a string');
      assert.strictEqual(typeof app.publisher, 'string', 'app.publisher must be a string');
      assert.strictEqual(typeof app.downloads, 'number', 'app.downloads must be a number');
      assert.strictEqual(app.publicationStatus, 'published', 'app.publicationStatus must be published');

      if (app.currentRelease) {
        assert.strictEqual(typeof app.currentRelease.versionName, 'string', 'versionName must be string');
        assert.strictEqual(typeof app.currentRelease.versionCode, 'number', 'versionCode must be number');
        assert.strictEqual(typeof app.currentRelease.fileSize, 'number', 'fileSize must be number');
        assert.strictEqual(typeof app.currentRelease.sha256, 'string', 'sha256 must be string');
        assert.strictEqual(app.currentRelease.sha256.length, 64, 'sha256 must be 64-char hex');
      }
    }
  });

  // 2. GET /api/apps/{slugOrId} conforms to Android AppDetailsResponse model
  await step('Test 2: GET /api/apps/{slugOrId} conforms to Android AppDetailsResponse model', async () => {
    const listRes = await fetch(`${BASE_URL}/api/apps`);
    const listData = await listRes.json();
    const targetApp = listData.apps[0];
    assert.ok(targetApp, 'Target app must exist');

    const res = await fetch(`${BASE_URL}/api/apps/${targetApp.id}`);
    assert.strictEqual(res.status, 200, 'Must return 200 for valid app ID');
    const data = await res.json();

    assert.ok(data.app, 'Response must have app object');
    assert.strictEqual(data.app.id, targetApp.id);
    assert.ok(Array.isArray(data.releases), 'Response must have releases array');
    assert.strictEqual(typeof data.downloads, 'number', 'Response must have downloads number');

    for (const rel of data.releases) {
      assert.strictEqual(typeof rel.versionName, 'string', 'Release versionName must be string');
      assert.strictEqual(typeof rel.versionCode, 'number', 'Release versionCode must be number');
      assert.strictEqual(typeof rel.fileSize, 'number', 'Release fileSize must be number');
      assert.strictEqual(typeof rel.sha256, 'string', 'Release sha256 must be string');
    }
  });

  // 3. GET /api/categories conforms to Android CategoriesResponse model
  await step('Test 3: GET /api/categories conforms to Android CategoriesResponse model', async () => {
    const res = await fetch(`${BASE_URL}/api/categories`);
    assert.strictEqual(res.status, 200, 'Must return 200');
    const data = await res.json();

    assert.ok(Array.isArray(data.categories), 'data.categories must be array');
    for (const cat of data.categories) {
      assert.strictEqual(typeof cat.name, 'string', 'Category name must be string');
      assert.strictEqual(typeof cat.count, 'number', 'Category count must be number');
    }
  });

  // 4. GET /api/stats conforms to Android PlatformStatsDto model
  await step('Test 4: GET /api/stats conforms to Android PlatformStatsDto model', async () => {
    const res = await fetch(`${BASE_URL}/api/stats`);
    assert.strictEqual(res.status, 200, 'Must return 200');
    const data = await res.json();

    assert.strictEqual(typeof data.publishedAppsCount, 'number', 'publishedAppsCount must be number');
    assert.strictEqual(typeof data.totalDownloadsRecorded, 'number', 'totalDownloadsRecorded must be number');
    assert.strictEqual(typeof data.publishedReleasesCount, 'number', 'publishedReleasesCount must be number');
  });

  // 5. GET /api/download/{releaseId}?client=android_client returns binary stream with correct MIME and headers
  await step('Test 5: GET /api/download/{releaseId}?client=android_client returns binary stream and headers', async () => {
    const publishedApps = db.getPublishedApps();
    const appWithRelease = publishedApps.find(a => a.currentReleaseId);
    assert.ok(appWithRelease, 'App with release must exist');

    const releaseId = appWithRelease.currentReleaseId!;
    const res = await fetch(`${BASE_URL}/api/download/${releaseId}?client=android_client`);

    assert.strictEqual(res.status, 200, 'Download endpoint must return 200 OK');
    assert.strictEqual(res.headers.get('content-type'), 'application/vnd.android.package-archive', 'Content-Type must be APK MIME');
    assert.ok(res.headers.get('content-disposition')?.includes('.apk'), 'Content-Disposition must specify .apk');
    assert.ok(res.headers.get('x-apk-sha256'), 'x-apk-sha256 header must be present');
    assert.ok(res.headers.get('x-apk-package-id'), 'x-apk-package-id header must be present');
    assert.ok(res.headers.get('content-length'), 'content-length header must be present for progress tracking');

    const arrayBuffer = await res.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    assert.ok(buffer.length > 0, 'Downloaded APK buffer must not be empty');

    const computedSha = crypto.createHash('sha256').update(buffer).digest('hex');
    assert.strictEqual(
      computedSha.toLowerCase(),
      res.headers.get('x-apk-sha256')?.toLowerCase(),
      'Streamed byte SHA-256 must match X-APK-SHA256 header'
    );
  });

  // 6. Downloaded APK conforms to Android ZIP structure with AndroidManifest.xml
  await step('Test 6: Downloaded APK conforms to Android ZIP container with AndroidManifest.xml', async () => {
    const publishedApps = db.getPublishedApps();
    const appWithRelease = publishedApps.find(a => a.currentReleaseId);
    const releaseId = appWithRelease!.currentReleaseId!;

    const res = await fetch(`${BASE_URL}/api/download/${releaseId}?client=android_client`);
    const buffer = Buffer.from(await res.arrayBuffer());

    // Check PK\x03\x04 zip header
    assert.strictEqual(buffer[0], 0x50, 'ZIP magic byte 0');
    assert.strictEqual(buffer[1], 0x4b, 'ZIP magic byte 1');
    assert.strictEqual(buffer[2], 0x03, 'ZIP magic byte 2');
    assert.strictEqual(buffer[3], 0x04, 'ZIP magic byte 3');

    // Confirm presence of AndroidManifest.xml string inside binary
    const hasManifest = buffer.includes(Buffer.from('AndroidManifest.xml'));
    assert.ok(hasManifest, 'APK package must contain AndroidManifest.xml');
  });

  // 7. Error handling returns JSON 404 for invalid release IDs, never HTML
  await step('Test 7: Error handling returns JSON 404 for invalid release IDs, never HTML', async () => {
    const res = await fetch(`${BASE_URL}/api/download/non-existent-release-99999`);
    assert.strictEqual(res.status, 404, 'Non-existent release must return 404');
    assert.ok(res.headers.get('content-type')?.includes('application/json'), 'Must return JSON error');

    const data = await res.json();
    assert.ok(data.error, 'Response must have error message');
  });

  // 8. Arbitrary unmatched /api routes return JSON 404, never <!doctype html>
  await step('Test 8: Arbitrary unmatched /api routes return JSON 404 (prevents Retrofit parser crashes)', async () => {
    const res = await fetch(`${BASE_URL}/api/arbitrary-unknown-endpoint-for-android`);
    assert.strictEqual(res.status, 404, 'Unmatched API route must return 404');
    assert.ok(res.headers.get('content-type')?.includes('application/json'), 'Must return application/json');

    const data = await res.json();
    assert.ok(data.error, 'Response must have error object');
    assert.strictEqual(data.code, 'ENDPOINT_NOT_FOUND', 'Response must return ENDPOINT_NOT_FOUND');
  });

  // 9. Android download recording logs clientType 'android_client' in database
  await step('Test 9: Android download event recorded with clientType android_client', async () => {
    const downloadEvents = db.getData().download_events;
    const hasAndroidLog = downloadEvents.some(log => log.clientType === 'android_client');
    assert.ok(hasAndroidLog, 'At least one download event must record clientType android_client');
  });

  // 10. Data protection: Zero side-effects on database, apps, or releases
  await step('Test 10: Zero data mutation or app unpublishing during Android operations', async () => {
    const currentAppsCount = db.getData().apps.length;
    const currentReleasesCount = db.getData().app_releases.length;
    const currentPublishedCount = db.getPublishedApps().length;

    assert.strictEqual(currentAppsCount, initialAppsCount, 'App count must be strictly preserved');
    assert.strictEqual(currentReleasesCount, initialReleasesCount, 'Release count must be strictly preserved');
    assert.strictEqual(currentPublishedCount, initialPublishedCount, 'Published count must be strictly preserved');
  });

  console.log('\n========================================================================');
  console.log(`PHASE 7 ANDROID CONTRACT SUITE FINISHED: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase7AndroidContractTestSuite().catch(err => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
