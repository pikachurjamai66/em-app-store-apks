import assert from 'assert';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { db, APK_STORAGE_DIR } from './db.ts';
import { inspectApkFile } from './apkInspector.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = 'em-admin-token-secure-init';

async function runTests() {
  console.log('--- STARTING EM APP STORE PHASE 2 BACKEND TEST SUITE ---\n');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      process.stdout.write(`• ${name}... `);
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('  Error:', err.message);
      failed++;
    }
  }

  // 1. Public users cannot create applications through admin endpoints
  await test('Public users cannot create applications (Admin Protected)', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Unauthorized App', packageId: 'com.hack.app' })
    });
    assert.strictEqual(res.status, 401, 'Should return 401 Unauthorized');
    const data = await res.json();
    assert.strictEqual(data.code, 'AUTH_REQUIRED');
  });

  // 2. Public users cannot upload APK files to admin endpoints
  await test('Public users cannot upload APK files to admin release endpoint', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      method: 'POST',
      body: new FormData()
    });
    assert.strictEqual(res.status, 401, 'Should return 401 Unauthorized');
  });

  // 3. Draft applications do not appear in public catalog
  await test('Draft applications do not appear in public catalog', async () => {
    // Create a draft app as admin
    const draftPackageId = `com.test.draft.${Date.now()}`;
    const draftName = 'Internal Test Draft';
    const draftSlug = `internal-draft-${Date.now()}`;

    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: draftName,
        slug: draftSlug,
        packageId: draftPackageId,
        shortDescription: 'Draft only',
        fullDescription: 'Not yet ready for public catalog',
        category: 'Tools',
        publisher: 'Test Publisher',
        publicationStatus: 'draft'
      })
    });
    assert.strictEqual(res.status, 201, 'Should create draft app successfully');
    const created = await res.json();
    assert.strictEqual(created.app.publicationStatus, 'draft');

    // Query public catalog
    const publicRes = await fetch(`${BASE_URL}/api/apps?q=${encodeURIComponent(draftName)}`);
    assert.strictEqual(publicRes.status, 200);
    const publicData = await publicRes.json();
    const found = publicData.apps.find((a: any) => a.packageId === draftPackageId);
    assert.strictEqual(found, undefined, 'Draft app must NOT appear in public catalog query');

    // Query public app details
    const publicDetailsRes = await fetch(`${BASE_URL}/api/apps/${draftSlug}`);
    assert.strictEqual(publicDetailsRes.status, 404, 'Public app details must return 404 for draft app');
  });

  // 4. Draft/archived releases cannot be downloaded publicly
  await test('Draft or inactive releases cannot be downloaded publicly', async () => {
    // Add a draft release to existing app
    const draftRelRes = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      method: 'POST',
      headers: { 'x-admin-token': ADMIN_TOKEN },
      body: (() => {
        const fd = new FormData();
        fd.append('versionName', '99.0.0-draft');
        fd.append('versionCode', '9900');
        fd.append('releaseStatus', 'draft');
        // create sample valid apk
        const apkBuffer = fs.readFileSync(path.join(APK_STORAGE_DIR, 'com.em.store-v1.0.0.apk'));
        const blob = new Blob([apkBuffer], { type: 'application/vnd.android.package-archive' });
        fd.append('apkFile', blob, 'test-draft.apk');
        return fd;
      })()
    });

    const relData = await draftRelRes.json();
    assert.strictEqual(draftRelRes.status, 201);
    const draftRelId = relData.release.id;

    // Public download attempt
    const dlRes = await fetch(`${BASE_URL}/api/download/${draftRelId}`);
    assert.strictEqual(dlRes.status, 403, 'Public download of draft release must be rejected with 403');
  });

  // 5. Published applications return the correct release
  await test('Published applications return correct verified release', async () => {
    const res = await fetch(`${BASE_URL}/api/apps/em-store-client`);
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.app.name, 'EM Store Client');
    assert.ok(data.currentRelease, 'Current release must be present');
    assert.ok(typeof data.currentRelease.versionName === 'string' && data.currentRelease.versionName.length > 0, 'versionName must be string');
    assert.ok(data.currentRelease.sha256 && data.currentRelease.sha256.length === 64, 'SHA-256 must be 64-char hex string');
  });

  // 6. Invalid or non-APK files rejected by inspector
  await test('Invalid non-APK files (missing AndroidManifest.xml) rejected', async () => {
    // Create a plain text or generic zip without AndroidManifest.xml
    const invalidFilePath = path.join(APK_STORAGE_DIR, 'invalid-test.apk');
    fs.writeFileSync(invalidFilePath, 'This is just a text file with .apk extension');

    try {
      const inspection = inspectApkFile(invalidFilePath);
      assert.strictEqual(inspection.isValidZip, false);
      assert.strictEqual(inspection.verificationStatus, 'invalid');
    } finally {
      if (fs.existsSync(invalidFilePath)) fs.unlinkSync(invalidFilePath);
    }
  });

  // 7. SHA-256 calculation matches crypto output
  await test('SHA-256 calculation matches file hash', async () => {
    const samplePath = path.join(APK_STORAGE_DIR, 'com.em.store-v1.0.0.apk');
    const inspection = inspectApkFile(samplePath);
    const rawBuffer = fs.readFileSync(samplePath);
    const expected = crypto.createHash('sha256').update(rawBuffer).digest('hex');
    assert.strictEqual(inspection.sha256, expected, 'Calculated SHA-256 must match crypto digest');
  });

  // 8. New release preserves previous release record
  await test('Uploading new release preserves previous release history', async () => {
    const listRes1 = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    const { releases: initialReleases } = await listRes1.json();
    const countBefore = initialReleases.length;

    // Upload release 1.0.1
    const fd = new FormData();
    fd.append('versionName', '1.0.1');
    fd.append('versionCode', '101');
    fd.append('changelog', 'Preservation verification release');
    fd.append('releaseStatus', 'published');
    const apkBuffer = fs.readFileSync(path.join(APK_STORAGE_DIR, 'com.em.store-v1.0.0.apk'));
    fd.append('apkFile', new Blob([apkBuffer]), 'em-store-v1.0.1.apk');

    const res = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      method: 'POST',
      headers: { 'x-admin-token': ADMIN_TOKEN },
      body: fd
    });
    assert.strictEqual(res.status, 201);

    const listRes2 = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    const { releases: afterReleases } = await listRes2.json();
    assert.strictEqual(afterReleases.length, countBefore + 1, 'Previous release must be preserved');
    const hasOld = afterReleases.some((r: any) => r.versionName === '1.0.0');
    const hasNew = afterReleases.some((r: any) => r.versionName === '1.0.1');
    assert.ok(hasOld && hasNew, 'Both old and new releases must exist concurrently');
  });

  // 9. Version code monotonicity check
  await test('Version code monotonicity warning when versionCode <= existing', async () => {
    const fd = new FormData();
    fd.append('versionName', '1.0.0-downgrade');
    fd.append('versionCode', '50'); // existing is >= 100
    fd.append('changelog', 'Downgrade attempt');
    const apkBuffer = fs.readFileSync(path.join(APK_STORAGE_DIR, 'com.em.store-v1.0.0.apk'));
    fd.append('apkFile', new Blob([apkBuffer]), 'test-downgrade.apk');

    const res = await fetch(`${BASE_URL}/api/admin/apps/app-em-store-client/releases`, {
      method: 'POST',
      headers: { 'x-admin-token': ADMIN_TOKEN },
      body: fd
    });
    const data = await res.json();
    assert.strictEqual(res.status, 201);
    assert.ok(data.compatibilityWarning, 'Must return compatibility warning for non-increasing versionCode');
  });

  // 10. Unpublishing an app prevents public downloads
  await test('Unpublishing an application prevents public downloads', async () => {
    const appRes = await fetch(`${BASE_URL}/api/apps/pulse-hi-res-audio-player`);
    const appData = await appRes.json();
    const releaseId = appData.currentRelease.id;

    // Check download works when published
    const preRes = await fetch(`${BASE_URL}/api/download/${releaseId}`);
    assert.strictEqual(preRes.status, 200, 'Published download should work');

    // Unpublish app
    await fetch(`${BASE_URL}/api/admin/apps/app-pulse-audio-player`, {
      method: 'PUT',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ publicationStatus: 'draft' })
    });

    // Attempt public download now
    const blockedRes = await fetch(`${BASE_URL}/api/download/${releaseId}`);
    assert.strictEqual(blockedRes.status, 403, 'Public download must be blocked (403) after unpublishing app');

    // Restore to published
    await fetch(`${BASE_URL}/api/admin/apps/app-pulse-audio-player`, {
      method: 'PUT',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ publicationStatus: 'published' })
    });
  });

  // 11. Unknown release IDs return safe error
  await test('Unknown release ID returns 404 with safe error message', async () => {
    const res = await fetch(`${BASE_URL}/api/download/non-existent-release-99999`);
    assert.strictEqual(res.status, 404);
    const data = await res.json();
    assert.ok(data.error);
    assert.strictEqual(data.storageReference, undefined, 'Must NOT leak internal storageReference');
  });

  // 12. Path traversal attempts rejected
  await test('Path traversal attempts are rejected safely', async () => {
    const res = await fetch(`${BASE_URL}/api/download/%2e%2e%2f%2e%2e%2fpackage.json`);
    assert.ok(res.status === 404 || res.status === 403, 'Path traversal must be rejected with 404 or 403');
  });

  console.log(`\n--- TEST RESULTS: ${passed} PASSED, ${failed} FAILED ---`);
  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Fatal error during test execution:', err);
  process.exit(1);
});
