import fs from 'fs';
import crypto from 'crypto';

export interface ApkInspectionResult {
  isValidZip: boolean;
  hasManifest: boolean;
  hasDex: boolean;
  hasResourcesArsc: boolean;
  hasSigningBlock: boolean;
  entryCount: number;
  entries: string[];
  fileSize: number;
  sha256: string;
  verificationStatus: 'verified' | 'suspicious' | 'invalid';
  inspectionSummary: string;
}

/**
 * Inspects an APK package binary file without relying on external native binaries.
 * Validates ZIP container headers, parses the central directory, checks for required
 * Android components (AndroidManifest.xml, classes.dex, resources.arsc), and computes SHA-256.
 */
export function inspectApkFile(filePath: string): ApkInspectionResult {
  if (!fs.existsSync(filePath)) {
    throw new Error('APK file does not exist at specified path.');
  }

  const stat = fs.statSync(filePath);
  if (stat.size < 22) {
    throw new Error('File is too small to be a valid ZIP/APK archive container.');
  }

  const buffer = fs.readFileSync(filePath);

  // 1. Compute Cryptographic SHA-256 Checksum
  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  // 2. Validate Local File Header (Magic Bytes: PK\x03\x04 / 0x04034b50)
  if (
    buffer.length < 4 ||
    buffer[0] !== 0x50 ||
    buffer[1] !== 0x4b ||
    buffer[2] !== 0x03 ||
    buffer[3] !== 0x04
  ) {
    return {
      isValidZip: false,
      hasManifest: false,
      hasDex: false,
      hasResourcesArsc: false,
      hasSigningBlock: false,
      entryCount: 0,
      entries: [],
      fileSize: stat.size,
      sha256,
      verificationStatus: 'invalid',
      inspectionSummary: 'Rejected: File missing standard ZIP local header magic bytes (PK\\x03\\x04).'
    };
  }

  // 3. Find End of Central Directory Record (EOCD: PK\x05\x06 / 0x06054b50)
  // Search backward from end of file (max comment size is 65535 bytes + 22 bytes header)
  let eocdOffset = -1;
  const maxSearch = Math.min(buffer.length, 65557);
  for (let i = buffer.length - 22; i >= buffer.length - maxSearch; i--) {
    if (
      buffer[i] === 0x50 &&
      buffer[i + 1] === 0x4b &&
      buffer[i + 2] === 0x05 &&
      buffer[i + 3] === 0x06
    ) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset === -1) {
    return {
      isValidZip: false,
      hasManifest: false,
      hasDex: false,
      hasResourcesArsc: false,
      hasSigningBlock: false,
      entryCount: 0,
      entries: [],
      fileSize: stat.size,
      sha256,
      verificationStatus: 'invalid',
      inspectionSummary: 'Rejected: End of Central Directory (EOCD) record not found. Corrupt ZIP container.'
    };
  }

  // Parse EOCD:
  // Offset 10: Total entries in the central directory on this disk (2 bytes)
  // Offset 12: Total entries in the central directory (2 bytes)
  // Offset 16: Size of central directory (4 bytes)
  // Offset 20: Offset of start of central directory (4 bytes)
  const totalEntries = buffer.readUInt16LE(eocdOffset + 10);
  const cdSize = buffer.readUInt32LE(eocdOffset + 12);
  const cdOffset = buffer.readUInt32LE(eocdOffset + 16);

  if (cdOffset + cdSize > buffer.length) {
    return {
      isValidZip: false,
      hasManifest: false,
      hasDex: false,
      hasResourcesArsc: false,
      hasSigningBlock: false,
      entryCount: totalEntries,
      entries: [],
      fileSize: stat.size,
      sha256,
      verificationStatus: 'invalid',
      inspectionSummary: 'Rejected: Central directory offset points beyond file boundaries.'
    };
  }

  // 4. Iterate Central Directory headers (Signature: PK\x01\x02 / 0x02014b50)
  const entries: string[] = [];
  let currOffset = cdOffset;
  let parsedCount = 0;

  while (
    currOffset < cdOffset + cdSize &&
    currOffset + 46 <= buffer.length &&
    parsedCount < Math.min(totalEntries, 50000)
  ) {
    if (
      buffer[currOffset] !== 0x50 ||
      buffer[currOffset + 1] !== 0x4b ||
      buffer[currOffset + 2] !== 0x01 ||
      buffer[currOffset + 3] !== 0x02
    ) {
      break;
    }

    const fileNameLen = buffer.readUInt16LE(currOffset + 28);
    const extraLen = buffer.readUInt16LE(currOffset + 30);
    const commentLen = buffer.readUInt16LE(currOffset + 32);

    const nameStart = currOffset + 46;
    if (nameStart + fileNameLen <= buffer.length) {
      const fileName = buffer.toString('utf8', nameStart, nameStart + fileNameLen);
      entries.push(fileName);
    }

    currOffset += 46 + fileNameLen + extraLen + commentLen;
    parsedCount++;
  }

  // 5. Check for key Android components
  const hasManifest = entries.some(
    e => e.toLowerCase() === 'androidmanifest.xml' || e.toLowerCase().endsWith('/androidmanifest.xml')
  );
  const hasDex = entries.some(e => e.toLowerCase().endsWith('.dex'));
  const hasResourcesArsc = entries.some(e => e.toLowerCase() === 'resources.arsc');

  // Check for Android APK Signing Block (magic string "APK Sig Block 42" before Central Directory)
  let hasSigningBlock = false;
  if (cdOffset >= 24) {
    // Signature block magic bytes: 0x32, 0x34, 0x20, 0x6b, 0x63, 0x6f, 0x6c, 0x42 ("APK Sig Block 42" in LE)
    const magicSearch = buffer.subarray(Math.max(0, cdOffset - 256), cdOffset);
    if (magicSearch.includes(Buffer.from('APK Sig Block 42'))) {
      hasSigningBlock = true;
    }
  }

  let verificationStatus: 'verified' | 'suspicious' | 'invalid' = 'verified';
  let summary = '';

  if (!hasManifest) {
    verificationStatus = 'invalid';
    summary = 'Rejected: Missing AndroidManifest.xml. The file is a valid ZIP archive but not an Android APK package.';
  } else {
    verificationStatus = 'verified';
    summary = `Verified Android APK container: AndroidManifest.xml identified, ${entries.length} archive entries cataloged, SHA-256 calculated.`;
  }

  return {
    isValidZip: true,
    hasManifest,
    hasDex,
    hasResourcesArsc,
    hasSigningBlock,
    entryCount: entries.length,
    entries: entries.slice(0, 50), // sample entries
    fileSize: stat.size,
    sha256,
    verificationStatus,
    inspectionSummary: summary
  };
}
