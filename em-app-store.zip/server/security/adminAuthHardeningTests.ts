import assert from 'assert';
import crypto from 'crypto';
import {
  getAdminSecretStatus,
  getAdminSecret,
  isDefaultBootstrapKeyInUse,
  verifyAdminSessionToken,
  createAdminSessionToken,
  revokeAdminSession,
  invalidateAllAdminSessions,
  recordFailedLoginAttempt,
  clearLoginRateLimit,
  DEFAULT_BOOTSTRAP_KEY,
  DEFAULT_DEV_ADMIN_TOKEN,
  SESSION_TTL_MS
} from './authManager.ts';

async function runAdminAuthHardeningTests() {
  console.log('========================================================================');
  console.log('   EM APP STORE: ADMIN AUTHENTICATION HARDENING TEST SUITE');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => void | Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  const originalEnv = { ...process.env };

  function restoreEnv() {
    process.env = { ...originalEnv };
  }

  try {
    // 1. Production: Missing ADMIN_INIT_KEY fails-closed
    await step('Test 1: In production, missing ADMIN_INIT_KEY fails-closed', () => {
      process.env.NODE_ENV = 'production';
      delete process.env.ADMIN_INIT_KEY;

      const status = getAdminSecretStatus();
      assert.strictEqual(status.isProduction, true);
      assert.strictEqual(status.isValidForAuth, false);
      assert.strictEqual(status.isConfigured, false);
      assert.ok(status.failureReason?.includes('not configured'));

      // getAdminSecret() must return null in production when not configured
      assert.strictEqual(getAdminSecret(), null);

      // Session verification must fail closed
      assert.strictEqual(verifyAdminSessionToken('any-token'), false);
    });

    // 2. Production: Default bootstrap key fails-closed
    await step('Test 2: In production, default bootstrap key is strictly blocked', () => {
      process.env.NODE_ENV = 'production';
      process.env.ADMIN_INIT_KEY = DEFAULT_BOOTSTRAP_KEY;

      const status = getAdminSecretStatus();
      assert.strictEqual(status.isProduction, true);
      assert.strictEqual(status.isValidForAuth, false);
      assert.strictEqual(status.isDefaultSecret, true);
      assert.ok(status.failureReason?.includes('Default bootstrap key cannot be used in production'));

      // Must return null
      assert.strictEqual(getAdminSecret(), null);

      // Default bootstrap key cannot be used to authenticate
      assert.strictEqual(verifyAdminSessionToken(DEFAULT_BOOTSTRAP_KEY), false);
    });

    // 3. Production: Short secret (<16 chars) fails-closed
    await step('Test 3: In production, secret shorter than 16 chars is rejected', () => {
      process.env.NODE_ENV = 'production';
      process.env.ADMIN_INIT_KEY = 'short-key-123';

      const status = getAdminSecretStatus();
      assert.strictEqual(status.isProduction, true);
      assert.strictEqual(status.isValidForAuth, false);
      assert.ok(status.failureReason?.includes('at least 16 characters'));
      assert.strictEqual(getAdminSecret(), null);
    });

    // 4. Production: Strong custom secret (>=16 chars) is valid
    await step('Test 4: In production, strong secret (>=16 chars) succeeds', () => {
      process.env.NODE_ENV = 'production';
      const secureSecret = 'my-super-secure-production-admin-key-2026';
      process.env.ADMIN_INIT_KEY = secureSecret;

      const status = getAdminSecretStatus();
      assert.strictEqual(status.isProduction, true);
      assert.strictEqual(status.isValidForAuth, true);
      assert.strictEqual(status.isDefaultSecret, false);
      assert.strictEqual(getAdminSecret(), secureSecret);

      // Creating a signed session token works
      const sessionToken = createAdminSessionToken('admin@emappstore.local');
      assert.ok(sessionToken.startsWith('em-admin-session-'));

      // Verification of genuine token succeeds
      assert.strictEqual(verifyAdminSessionToken(sessionToken), true);

      // Default bootstrap key is STILL rejected even with valid custom secret in prod
      assert.strictEqual(verifyAdminSessionToken(DEFAULT_BOOTSTRAP_KEY), false);

      // Dev token is strictly rejected in production
      assert.strictEqual(verifyAdminSessionToken(DEFAULT_DEV_ADMIN_TOKEN), false);
    });

    // 5. Invalidation on secret rotation
    await step('Test 5: Secret rotation invalidates tokens created with prior secret', () => {
      process.env.NODE_ENV = 'production';
      process.env.ADMIN_INIT_KEY = 'first-secure-production-secret-1111';

      const tokenFromFirstSecret = createAdminSessionToken('admin@emappstore.local');
      assert.strictEqual(verifyAdminSessionToken(tokenFromFirstSecret), true);

      // Rotate secret to a new secure key
      process.env.ADMIN_INIT_KEY = 'second-secure-production-secret-2222';

      // Token generated with previous secret must now be REJECTED immediately
      assert.strictEqual(
        verifyAdminSessionToken(tokenFromFirstSecret),
        false,
        'Old token signed with rotated secret must be rejected'
      );

      // New token with new secret works
      const tokenFromSecondSecret = createAdminSessionToken('admin@emappstore.local');
      assert.strictEqual(verifyAdminSessionToken(tokenFromSecondSecret), true);
    });

    // 6. Token tampering, expiration, and future timestamp checks
    await step('Test 6: Tampered, expired, or future tokens are rejected', () => {
      process.env.NODE_ENV = 'production';
      const secret = 'valid-test-secret-with-sufficient-length';
      process.env.ADMIN_INIT_KEY = secret;

      // Tampered signature
      const validToken = createAdminSessionToken('admin@emappstore.local');
      const parts = validToken.split('-');
      parts[4] = '00000000000000000000000000000000';
      const tampered = parts.join('-');
      assert.strictEqual(verifyAdminSessionToken(tampered), false);

      // Expired token (created 25 hours ago)
      const expiredTs = (Date.now() - (SESSION_TTL_MS + 3600000)).toString();
      const expiredSig = crypto
        .createHmac('sha256', secret)
        .update(expiredTs)
        .digest('hex')
        .substring(0, 32);
      const expiredToken = `em-admin-session-${expiredTs}-${expiredSig}`;
      assert.strictEqual(verifyAdminSessionToken(expiredToken), false);

      // Future token (> 1 minute ahead)
      const futureTs = (Date.now() + 120000).toString();
      const futureSig = crypto
        .createHmac('sha256', secret)
        .update(futureTs)
        .digest('hex')
        .substring(0, 32);
      const futureToken = `em-admin-session-${futureTs}-${futureSig}`;
      assert.strictEqual(verifyAdminSessionToken(futureToken), false);
    });

    // 7. Session revocation works
    await step('Test 7: Session revocation explicitly invalidates tokens', () => {
      process.env.NODE_ENV = 'production';
      process.env.ADMIN_INIT_KEY = 'valid-test-secret-with-sufficient-length';

      const token = createAdminSessionToken('admin@emappstore.local');
      assert.strictEqual(verifyAdminSessionToken(token), true);

      revokeAdminSession(token);
      assert.strictEqual(verifyAdminSessionToken(token), false);
    });

    // 8. Rate limiter mechanics
    await step('Test 8: Rate limiter locks IP after 5 consecutive failed attempts', () => {
      const testIp = '192.168.1.99';
      clearLoginRateLimit(testIp);

      let record = recordFailedLoginAttempt(testIp);
      assert.strictEqual(record.remainingAttempts, 4);
      assert.strictEqual(record.isLocked, false);

      recordFailedLoginAttempt(testIp); // 2
      recordFailedLoginAttempt(testIp); // 3
      recordFailedLoginAttempt(testIp); // 4
      record = recordFailedLoginAttempt(testIp); // 5

      assert.strictEqual(record.remainingAttempts, 0);
      assert.strictEqual(record.isLocked, true);

      clearLoginRateLimit(testIp);
    });

    // 9. Non-production / dev fallback behavior
    await step('Test 9: Non-production environment allows dev fallback safely', () => {
      process.env.NODE_ENV = 'development';
      delete process.env.ADMIN_INIT_KEY;

      const status = getAdminSecretStatus();
      assert.strictEqual(status.isProduction, false);
      assert.strictEqual(status.isValidForAuth, true);
      assert.strictEqual(status.isDefaultSecret, true);

      // In dev mode, DEFAULT_DEV_ADMIN_TOKEN is accepted
      assert.strictEqual(verifyAdminSessionToken(DEFAULT_DEV_ADMIN_TOKEN), true);

      // Random garbage is still rejected
      assert.strictEqual(verifyAdminSessionToken('invalid-garbage-key'), false);
    });

  } finally {
    restoreEnv();
  }

  console.log(`\n========================================================================`);
  console.log(`   SUITE COMPLETE: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runAdminAuthHardeningTests();
