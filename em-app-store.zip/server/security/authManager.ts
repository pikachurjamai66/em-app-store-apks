import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { db } from '../db.ts';

export const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours maximum session lifetime
export const DEFAULT_BOOTSTRAP_KEY = 'admin-bootstrap-change-in-production';
export const DEFAULT_DEV_ADMIN_TOKEN = 'em-admin-token-secure-init';

// Active session token cache and revoked session set
const activeAdminSessions = new Map<string, { createdAtMs: number; userEmail: string; secretHash?: string }>();
const revokedAdminSessions = new Set<string>();

// Login rate limiting state: ip -> { attempts: number, lockUntilMs: number, firstAttemptMs: number }
interface RateLimitRecord {
  attempts: number;
  lockUntilMs: number;
  firstAttemptMs: number;
}
const loginRateLimitMap = new Map<string, RateLimitRecord>();

// Clean up stale rate limit entries periodically (every 10 minutes)
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of loginRateLimitMap.entries()) {
    if (now > record.lockUntilMs && now - record.firstAttemptMs > 15 * 60 * 1000) {
      loginRateLimitMap.delete(ip);
    }
  }
}, 10 * 60 * 1000).unref();

export interface AdminSecretStatus {
  isConfigured: boolean;
  isProduction: boolean;
  isDefaultSecret: boolean;
  isValidForAuth: boolean;
  failureReason?: string;
}

export function getAdminSecretStatus(): AdminSecretStatus {
  const isProduction = process.env.NODE_ENV === 'production';
  const rawSecret = process.env.ADMIN_INIT_KEY;
  const isConfigured = Boolean(rawSecret && rawSecret.trim().length > 0);
  const secret = isConfigured ? rawSecret!.trim() : '';
  const isDefaultSecret = !isConfigured || secret === DEFAULT_BOOTSTRAP_KEY;

  if (isProduction) {
    if (!isConfigured) {
      return {
        isConfigured: false,
        isProduction: true,
        isDefaultSecret: true,
        isValidForAuth: false,
        failureReason: 'ADMIN_INIT_KEY environment variable is not configured. Admin authentication is fail-closed in production.'
      };
    }
    if (isDefaultSecret) {
      return {
        isConfigured: true,
        isProduction: true,
        isDefaultSecret: true,
        isValidForAuth: false,
        failureReason: 'Default bootstrap key cannot be used in production. Configure a strong custom ADMIN_INIT_KEY secret.'
      };
    }
    if (secret.length < 16) {
      return {
        isConfigured: true,
        isProduction: true,
        isDefaultSecret: false,
        isValidForAuth: false,
        failureReason: 'ADMIN_INIT_KEY must be at least 16 characters long in production.'
      };
    }
    return {
      isConfigured: true,
      isProduction: true,
      isDefaultSecret: false,
      isValidForAuth: true
    };
  }

  // Development and test environments
  return {
    isConfigured,
    isProduction: false,
    isDefaultSecret,
    isValidForAuth: true
  };
}

let lastLoggedSecretWarning = false;

export function getAdminSecret(): string | null {
  const status = getAdminSecretStatus();
  if (status.isProduction && !status.isValidForAuth) {
    if (!lastLoggedSecretWarning) {
      console.warn(
        `[SECURITY FAIL-CLOSED] Production admin authentication disabled: ${status.failureReason}`
      );
      lastLoggedSecretWarning = true;
    }
    return null;
  }

  const rawSecret = process.env.ADMIN_INIT_KEY;
  if (!rawSecret || rawSecret.trim().length === 0) {
    return DEFAULT_BOOTSTRAP_KEY;
  }
  return rawSecret.trim();
}

export function isDefaultBootstrapKeyInUse(): boolean {
  const rawSecret = process.env.ADMIN_INIT_KEY;
  if (!rawSecret || rawSecret.trim().length === 0) return true;
  return rawSecret.trim() === DEFAULT_BOOTSTRAP_KEY;
}

function getSecretHash(secret: string): string {
  return crypto.createHash('sha256').update(secret).digest('hex').substring(0, 16);
}

/**
 * Timing-safe HMAC session signature validator with expiration checking
 */
export function verifyAdminSessionToken(token: string): boolean {
  if (!token || typeof token !== 'string') return false;

  const isProd = process.env.NODE_ENV === 'production';
  const status = getAdminSecretStatus();

  // Fail-closed in production if secret is missing, default, or invalid
  if (isProd && !status.isValidForAuth) {
    return false;
  }

  const adminSecret = getAdminSecret();
  if (!adminSecret) {
    return false;
  }

  // Check if token was explicitly revoked
  if (revokedAdminSessions.has(token)) {
    return false;
  }

  // In production, reject default bootstrap key under all circumstances
  if (isProd && (isDefaultBootstrapKeyInUse() || adminSecret === DEFAULT_BOOTSTRAP_KEY)) {
    return false;
  }

  // Allow developer master token in non-production mode only
  if (!isProd && token === DEFAULT_DEV_ADMIN_TOKEN) {
    return true;
  }

  // Allow static administrative secret in non-production mode only if explicitly configured
  if (!isProd && token === adminSecret && !isDefaultBootstrapKeyInUse()) {
    return true;
  }

  // Verify HMAC-signed session tokens: em-admin-session-<timestamp>-<signature>
  if (token.startsWith('em-admin-session-')) {
    const parts = token.split('-');
    if (parts.length >= 5) {
      const timestampStr = parts[3];
      const providedSignature = parts[4];

      const timestamp = parseInt(timestampStr, 10);
      if (isNaN(timestamp)) return false;

      const now = Date.now();
      // Expiration check: reject sessions older than 24 hours or with future timestamps (> 1 minute in future)
      if (now - timestamp > SESSION_TTL_MS || timestamp > now + 60000) {
        return false;
      }

      const currentSecretHash = getSecretHash(adminSecret);

      // Check if session in active cache is still valid and was signed with current secret
      const cached = activeAdminSessions.get(token);
      if (cached) {
        if (now - cached.createdAtMs > SESSION_TTL_MS || cached.secretHash !== currentSecretHash) {
          activeAdminSessions.delete(token);
          return false;
        }
      }

      const expected = crypto
        .createHmac('sha256', adminSecret)
        .update(timestampStr)
        .digest('hex')
        .substring(0, 32);

      try {
        const bufA = Buffer.from(providedSignature, 'hex');
        const bufB = Buffer.from(expected, 'hex');
        if (bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB)) {
          if (!cached) {
            activeAdminSessions.set(token, {
              createdAtMs: timestamp,
              userEmail: 'admin@emappstore.local',
              secretHash: currentSecretHash
            });
          }
          return true;
        }
      } catch {
        return false;
      }
    }
  }

  return false;
}

/**
 * Creates a cryptographically signed administrator session token
 */
export function createAdminSessionToken(userEmail = 'admin@emappstore.local'): string {
  const adminSecret = getAdminSecret();
  if (!adminSecret) {
    throw new Error('Cannot create admin session: Production administrator authentication is not configured.');
  }

  const timestamp = Date.now().toString();
  const signature = crypto
    .createHmac('sha256', adminSecret)
    .update(timestamp)
    .digest('hex')
    .substring(0, 32);

  const token = `em-admin-session-${timestamp}-${signature}`;
  const secretHash = getSecretHash(adminSecret);
  activeAdminSessions.set(token, { createdAtMs: parseInt(timestamp, 10), userEmail, secretHash });
  return token;
}

/**
 * Revokes an administrator session token
 */
export function revokeAdminSession(token: string): boolean {
  if (!token) return false;
  revokedAdminSessions.add(token);
  activeAdminSessions.delete(token);
  return true;
}

/**
 * Invalidate all active sessions (e.g. after secret change)
 */
export function invalidateAllAdminSessions(): void {
  activeAdminSessions.clear();
}

/**
 * Extracts client IP from Express request, handling standard proxy headers
 */
export function getClientIp(req: Request): string {
  const xForwardedFor = req.headers['x-forwarded-for'];
  if (xForwardedFor) {
    const ips = (typeof xForwardedFor === 'string' ? xForwardedFor : xForwardedFor[0]).split(',');
    return ips[0].trim();
  }
  return req.socket.remoteAddress || '127.0.0.1';
}

/**
 * Rate limiter middleware specifically protecting /api/admin/login
 * Limits to 5 failed attempts per 15 minutes per IP.
 */
export function adminLoginRateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = getClientIp(req);
  const now = Date.now();
  const record = loginRateLimitMap.get(ip);

  if (record) {
    if (now < record.lockUntilMs) {
      const waitSeconds = Math.ceil((record.lockUntilMs - now) / 1000);
      res.setHeader('Retry-After', waitSeconds.toString());
      res.status(429).json({
        error: `Too many failed login attempts. Access temporarily locked. Please try again in ${waitSeconds} seconds.`,
        code: 'RATE_LIMIT_EXCEEDED',
        retryAfterSeconds: waitSeconds
      });
      return;
    }

    // Reset counter if window has passed
    if (now - record.firstAttemptMs > 15 * 60 * 1000) {
      loginRateLimitMap.delete(ip);
    }
  }

  next();
}

/**
 * Record a failed admin login attempt for rate limiting
 */
export function recordFailedLoginAttempt(ip: string): { remainingAttempts: number; isLocked: boolean } {
  const now = Date.now();
  let record = loginRateLimitMap.get(ip);

  if (!record || now - record.firstAttemptMs > 15 * 60 * 1000) {
    record = {
      attempts: 1,
      lockUntilMs: 0,
      firstAttemptMs: now
    };
  } else {
    record.attempts += 1;
  }

  const maxAttempts = 5;
  if (record.attempts >= maxAttempts) {
    record.lockUntilMs = now + 15 * 60 * 1000; // Lock for 15 minutes
  }

  loginRateLimitMap.set(ip, record);

  return {
    remainingAttempts: Math.max(0, maxAttempts - record.attempts),
    isLocked: record.attempts >= maxAttempts
  };
}

/**
 * Clear rate limit on successful admin login
 */
export function clearLoginRateLimit(ip: string): void {
  loginRateLimitMap.delete(ip);
}

/**
 * Safe sanitization of error messages to prevent leaking server paths, stack traces, or credentials
 */
export function sanitizeErrorMessage(err: unknown): string {
  if (err instanceof Error) {
    const msg = err.message || 'An unexpected internal error occurred.';
    // Strip file paths
    const sanitized = msg.replace(/\/app\/[a-zA-Z0-9_\/.-]+/g, '[system-path]');
    return sanitized;
  }
  return 'An unexpected server error occurred.';
}
