import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DatabaseSchema } from '../types.ts';
import { DATA_DIR, DB_FILE, BACKUP_DIR, APK_STORAGE_DIR } from '../db.ts';
import { validateDatabaseIntegrity } from './integrityValidator.ts';

export interface BackupManifest {
  backupId: string;
  timestamp: string;
  schemaVersion: string;
  source: string;
  appsCount: number;
  releasesCount: number;
  tombstonesCount: number;
  checksumSha256: string;
  apkFiles: Array<{ filename: string; sha256: string; size: number }>;
}

export interface BackupComparisonResult {
  canSafelyRestore: boolean;
  isDowngrade: boolean;
  activeAppsCount: number;
  backupAppsCount: number;
  activeReleasesCount: number;
  backupReleasesCount: number;
  warning?: string;
}

export function createVerifiedTimestampedBackup(
  customOutputDir?: string
): { success: boolean; backupDir: string; manifest: BackupManifest } {
  if (!fs.existsSync(DB_FILE)) {
    throw new Error(`Primary database file not found at ${DB_FILE}; cannot create verified backup.`);
  }

  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  const dbData: DatabaseSchema = JSON.parse(raw);

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const targetDir = customOutputDir || path.join(BACKUP_DIR, `backup-${timestamp}`);
  const targetApkDir = path.join(targetDir, 'apks');

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  if (!fs.existsSync(targetApkDir)) {
    fs.mkdirSync(targetApkDir, { recursive: true });
  }

  // 1. Write db.json
  const targetDbFile = path.join(targetDir, 'db.json');
  fs.writeFileSync(targetDbFile, JSON.stringify(dbData, null, 2), 'utf-8');
  const dbSha256 = crypto.createHash('sha256').update(fs.readFileSync(targetDbFile)).digest('hex');

  // 2. Backup and checksum all APK files
  const backedUpApks: Array<{ filename: string; sha256: string; size: number }> = [];
  if (fs.existsSync(APK_STORAGE_DIR)) {
    const files = fs.readdirSync(APK_STORAGE_DIR);
    for (const f of files) {
      if (f.endsWith('.apk')) {
        const srcPath = path.join(APK_STORAGE_DIR, f);
        const destPath = path.join(targetApkDir, f);
        fs.copyFileSync(srcPath, destPath);

        const buf = fs.readFileSync(destPath);
        const sha256 = crypto.createHash('sha256').update(buf).digest('hex').toUpperCase();
        backedUpApks.push({
          filename: f,
          sha256,
          size: buf.length
        });
      }
    }
  }

  // 3. Create manifest
  const manifest: BackupManifest = {
    backupId: `backup-${timestamp}`,
    timestamp: new Date().toISOString(),
    schemaVersion: '1.0',
    source: DB_FILE,
    appsCount: (dbData.apps || []).length,
    releasesCount: (dbData.app_releases || []).length,
    tombstonesCount: (dbData.deleted_app_ids || []).length,
    checksumSha256: dbSha256,
    apkFiles: backedUpApks
  };

  const manifestPath = path.join(targetDir, 'manifest.json');
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf-8');

  // Verify backup can be parsed back and passes integrity check
  const verifyData = JSON.parse(fs.readFileSync(targetDbFile, 'utf-8'));
  const report = validateDatabaseIntegrity(verifyData, targetApkDir);
  if (!report.isValid) {
    throw new Error(`Backup verification failed: created backup has integrity errors (${report.issues.length} issues)`);
  }

  return {
    success: true,
    backupDir: targetDir,
    manifest
  };
}

export function compareBackupWithActive(
  backupDb: DatabaseSchema,
  activeDb: DatabaseSchema
): BackupComparisonResult {
  const activeApps = (activeDb.apps || []).length;
  const backupApps = (backupDb.apps || []).length;
  const activeReleases = (activeDb.app_releases || []).length;
  const backupReleases = (backupDb.app_releases || []).length;

  // Find latest timestamp in active vs backup
  const getLatestTimestamp = (db: DatabaseSchema) => {
    let latest = 0;
    for (const a of db.apps || []) {
      const t = new Date(a.updatedAt || a.createdAt).getTime();
      if (t > latest) latest = t;
    }
    return latest;
  };

  const activeLatest = getLatestTimestamp(activeDb);
  const backupLatest = getLatestTimestamp(backupDb);

  const isFewerApps = backupApps < activeApps;
  const isOlderTimestamp = backupLatest < activeLatest && activeLatest > 0;
  const isDowngrade = isFewerApps || isOlderTimestamp;

  let warning: string | undefined = undefined;
  if (isDowngrade) {
    warning = `Downgrade Warning: Backup has ${backupApps} apps (active has ${activeApps}) and backup timestamp is older than active data. Restoring would result in data loss.`;
  }

  return {
    canSafelyRestore: !isDowngrade,
    isDowngrade,
    activeAppsCount: activeApps,
    backupAppsCount: backupApps,
    activeReleasesCount: activeReleases,
    backupReleasesCount: backupReleases,
    warning
  };
}

export function safeRestoreFromBackup(
  backupDir: string,
  options: {
    actorEmail: string;
    confirmationPhrase: string;
    allowDowngradeOverride?: boolean;
  }
): { success: boolean; message: string; report: any } {
  if (options.confirmationPhrase !== 'CONFIRM_AUTHORITATIVE_RESTORE') {
    throw new Error(
      `Restoration rejected: Confirmation phrase mismatch. Must explicitly provide 'CONFIRM_AUTHORITATIVE_RESTORE'.`
    );
  }

  const backupDbPath = path.join(backupDir, 'db.json');
  if (!fs.existsSync(backupDbPath)) {
    throw new Error(`Backup database file not found at ${backupDbPath}`);
  }

  const backupData: DatabaseSchema = JSON.parse(fs.readFileSync(backupDbPath, 'utf-8'));
  const activeData: DatabaseSchema = fs.existsSync(DB_FILE)
    ? JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'))
    : { users: [], apps: [], app_releases: [], developer_submissions: [], download_events: [], audit_logs: [] };

  const comparison = compareBackupWithActive(backupData, activeData);

  if (comparison.isDowngrade && !options.allowDowngradeOverride) {
    throw new Error(
      `Restoration aborted by safety guard: ${comparison.warning}. To force this recovery, explicit administrator downgrade override is required.`
    );
  }

  // Record recovery audit log in backup before write
  backupData.audit_logs = Array.isArray(backupData.audit_logs) ? backupData.audit_logs : [];
  backupData.audit_logs.unshift({
    id: `audit-${Date.now()}-restore`,
    actorId: 'admin',
    actorEmail: options.actorEmail,
    action: 'DISASTER_RECOVERY_RESTORE',
    targetRecordId: backupDir,
    targetType: 'system',
    details: {
      preRestoreAppsCount: comparison.activeAppsCount,
      restoredAppsCount: comparison.backupAppsCount,
      isDowngrade: comparison.isDowngrade,
      timestamp: new Date().toISOString()
    },
    timestamp: new Date().toISOString(),
    outcome: 'success'
  });

  // Write atomically
  const tmpFile = path.join(DATA_DIR, `db-restore-${Date.now()}.tmp`);
  fs.writeFileSync(tmpFile, JSON.stringify(backupData, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);

  return {
    success: true,
    message: `Database successfully restored from backup ${path.basename(backupDir)} by ${options.actorEmail}.`,
    report: {
      preRestoreApps: comparison.activeAppsCount,
      restoredApps: comparison.backupAppsCount,
      timestamp: new Date().toISOString()
    }
  };
}
