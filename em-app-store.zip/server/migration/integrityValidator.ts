import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DatabaseSchema, AppRecord, AppRelease, DeveloperSubmission, AuditLog } from '../types.ts';
import { APK_STORAGE_DIR } from '../db.ts';

export interface IntegrityIssue {
  severity: 'error' | 'warning';
  entity: 'app' | 'release' | 'submission' | 'tombstone' | 'backup';
  entityId: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface IntegrityReport {
  timestamp: string;
  isValid: boolean;
  appsCount: number;
  publishedAppsCount: number;
  releasesCount: number;
  submissionsCount: number;
  auditLogsCount: number;
  tombstonesCount: number;
  verifiedApkFilesCount: number;
  missingApkFilesCount: number;
  issues: IntegrityIssue[];
}

export function validateDatabaseIntegrity(
  data: DatabaseSchema,
  apkStorageDir: string = APK_STORAGE_DIR
): IntegrityReport {
  const issues: IntegrityIssue[] = [];

  const appIds = new Set<string>();
  const packageIds = new Set<string>();
  const slugs = new Set<string>();
  const tombstoneSet = new Set(data.deleted_app_ids || []);

  let publishedAppsCount = 0;

  // 1. Validate Applications
  for (const app of data.apps || []) {
    // Check required fields
    if (!app.id || !app.name || !app.packageId || !app.slug) {
      issues.push({
        severity: 'error',
        entity: 'app',
        entityId: app.id || 'unknown',
        message: 'Application missing required identification fields (id, name, packageId, or slug)'
      });
    }

    // Check unique App ID
    if (appIds.has(app.id)) {
      issues.push({
        severity: 'error',
        entity: 'app',
        entityId: app.id,
        message: `Duplicate application ID detected: ${app.id}`
      });
    }
    appIds.add(app.id);

    // Check unique Package ID
    const pkgLower = (app.packageId || '').toLowerCase();
    if (packageIds.has(pkgLower)) {
      issues.push({
        severity: 'error',
        entity: 'app',
        entityId: app.id,
        message: `Duplicate package ID detected across applications: ${app.packageId}`
      });
    }
    packageIds.add(pkgLower);

    // Check unique Slug
    const slugLower = (app.slug || '').toLowerCase();
    if (slugs.has(slugLower)) {
      issues.push({
        severity: 'warning',
        entity: 'app',
        entityId: app.id,
        message: `Duplicate URL slug detected: ${app.slug}`
      });
    }
    slugs.add(slugLower);

    // Check tombstone collision
    if (tombstoneSet.has(app.id)) {
      issues.push({
        severity: 'error',
        entity: 'app',
        entityId: app.id,
        message: `Application ID ${app.id} exists in active apps list but is also marked in deleted_app_ids tombstones`
      });
    }

    // Check publication status
    if (app.publicationStatus === 'published') {
      publishedAppsCount++;
      if (!app.currentReleaseId) {
        issues.push({
          severity: 'warning',
          entity: 'app',
          entityId: app.id,
          message: `Published app '${app.name}' has no currentReleaseId specified`
        });
      }
    }
  }

  // 2. Validate Releases
  const releaseIds = new Set<string>();
  let verifiedApkFilesCount = 0;
  let missingApkFilesCount = 0;

  for (const rel of data.app_releases || []) {
    if (!rel.id || !rel.appId || !rel.packageId) {
      issues.push({
        severity: 'error',
        entity: 'release',
        entityId: rel.id || 'unknown',
        message: 'Release record missing required identification fields'
      });
    }

    if (releaseIds.has(rel.id)) {
      issues.push({
        severity: 'error',
        entity: 'release',
        entityId: rel.id,
        message: `Duplicate release ID detected: ${rel.id}`
      });
    }
    releaseIds.add(rel.id);

    // Verify app association
    if (!appIds.has(rel.appId)) {
      // Check if it belongs to a tombstoned app
      if (tombstoneSet.has(rel.appId)) {
        issues.push({
          severity: 'warning',
          entity: 'release',
          entityId: rel.id,
          message: `Release ${rel.id} belongs to a deleted/tombstoned app (${rel.appId})`
        });
      } else {
        issues.push({
          severity: 'error',
          entity: 'release',
          entityId: rel.id,
          message: `Orphaned release: appId ${rel.appId} does not exist in applications`
        });
      }
    }

    // Verify APK binary presence on disk if local storage is accessible
    if (rel.apkStoragePath && fs.existsSync(apkStorageDir)) {
      const safePath = path.resolve(apkStorageDir, path.basename(rel.apkStoragePath));
      if (fs.existsSync(safePath)) {
        verifiedApkFilesCount++;
        // Check size
        const stat = fs.statSync(safePath);
        if (rel.fileSize && stat.size !== rel.fileSize) {
          issues.push({
            severity: 'warning',
            entity: 'release',
            entityId: rel.id,
            message: `File size mismatch for release ${rel.id}: expected ${rel.fileSize} bytes, physical file is ${stat.size} bytes`
          });
        }
      } else {
        missingApkFilesCount++;
        issues.push({
          severity: 'warning',
          entity: 'release',
          entityId: rel.id,
          message: `Physical APK binary not found on local disk: ${rel.apkStoragePath}. Must trigger download error without unpublishing.`
        });
      }
    }
  }

  // 3. Verify currentReleaseId references for all apps
  for (const app of data.apps || []) {
    if (app.currentReleaseId && !releaseIds.has(app.currentReleaseId)) {
      issues.push({
        severity: 'error',
        entity: 'app',
        entityId: app.id,
        message: `currentReleaseId '${app.currentReleaseId}' of app '${app.name}' does not match any valid release ID`
      });
    }
  }

  const hasCriticalErrors = issues.some(i => i.severity === 'error');

  return {
    timestamp: new Date().toISOString(),
    isValid: !hasCriticalErrors,
    appsCount: (data.apps || []).length,
    publishedAppsCount,
    releasesCount: (data.app_releases || []).length,
    submissionsCount: (data.developer_submissions || []).length,
    auditLogsCount: (data.audit_logs || []).length,
    tombstonesCount: tombstoneSet.size,
    verifiedApkFilesCount,
    missingApkFilesCount,
    issues
  };
}
