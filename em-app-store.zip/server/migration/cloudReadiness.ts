import { Firestore } from '@google-cloud/firestore';
import { Storage } from '@google-cloud/storage';

export interface CloudReadinessStatus {
  timestamp: string;
  projectId: string | null;
  serviceAccount: string | null;
  firestore: {
    configured: boolean;
    reachable: boolean;
    databaseId: string;
    error?: string;
  };
  gcs: {
    configured: boolean;
    reachable: boolean;
    bucketName: string | null;
    error?: string;
  };
  overallReady: boolean;
  blockers: string[];
  manualSteps: string[];
}

export async function checkCloudReadiness(): Promise<CloudReadinessStatus> {
  const projectId = process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || null;
  const bucketName = process.env.GCS_APK_BUCKET || null;
  const databaseId = process.env.FIRESTORE_DATABASE_ID || '(default)';

  let serviceAccount: string | null = null;
  try {
    const res = await fetch('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email', {
      headers: { 'Metadata-Flavor': 'Google' },
      signal: AbortSignal.timeout(1500)
    });
    if (res.ok) {
      serviceAccount = (await res.text()).trim();
    }
  } catch {
    // Not running on GCP instance metadata server
  }

  const blockers: string[] = [];
  const manualSteps: string[] = [];

  // 1. Check Firestore
  let firestoreReachable = false;
  let firestoreError: string | undefined = undefined;

  try {
    const fsClient = new Firestore({
      projectId: projectId || undefined,
      databaseId: databaseId !== '(default)' ? databaseId : undefined
    });
    // Attempt lightweight metadata read with short timeout
    await Promise.race([
      fsClient.collection('_healthcheck').doc('ping').get(),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Firestore connection timeout (3000ms)')), 3000))
    ]);
    firestoreReachable = true;
  } catch (err: any) {
    firestoreReachable = false;
    firestoreError = err.message || String(err);
    blockers.push(`Firestore Native Mode is not reachable: ${firestoreError}`);
    manualSteps.push(`Run: gcloud firestore databases create --location=asia-southeast1 --type=firestore-native --project=${projectId || 'YOUR_PROJECT_ID'}`);
  }

  // 2. Check GCS
  let gcsReachable = false;
  let gcsError: string | undefined = undefined;

  if (!bucketName) {
    gcsError = 'GCS_APK_BUCKET environment variable is not defined.';
    blockers.push('Google Cloud Storage bucket for APK binaries is not configured (GCS_APK_BUCKET).');
    manualSteps.push(`Run: gcloud storage buckets create gs://em-appstore-apks --location=asia-southeast1 --uniform-bucket-level-access --project=${projectId || 'YOUR_PROJECT_ID'}`);
  } else {
    try {
      const storageClient = new Storage({ projectId: projectId || undefined });
      const bucket = storageClient.bucket(bucketName);
      const [exists] = await Promise.race([
        bucket.exists(),
        new Promise<[boolean]>((_, reject) => setTimeout(() => reject(new Error('GCS bucket connection timeout (3000ms)')), 3000))
      ]);
      gcsReachable = exists;
      if (!exists) {
        gcsError = `Bucket gs://${bucketName} does not exist.`;
        blockers.push(`GCS bucket gs://${bucketName} does not exist.`);
      }
    } catch (err: any) {
      gcsReachable = false;
      gcsError = err.message || String(err);
      blockers.push(`GCS access failed: ${gcsError}`);
      manualSteps.push(`Grant roles/storage.objectAdmin to ${serviceAccount || 'your Cloud Run service account'} on gs://${bucketName}`);
    }
  }

  return {
    timestamp: new Date().toISOString(),
    projectId,
    serviceAccount,
    firestore: {
      configured: Boolean(projectId),
      reachable: firestoreReachable,
      databaseId,
      error: firestoreError
    },
    gcs: {
      configured: Boolean(bucketName),
      reachable: gcsReachable,
      bucketName,
      error: gcsError
    },
    overallReady: firestoreReachable && gcsReachable,
    blockers,
    manualSteps
  };
}
