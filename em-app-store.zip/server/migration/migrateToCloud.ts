import fs from 'fs';
import path from 'path';
import { DatabaseSchema, AppRecord, AppRelease, DeveloperSubmission, DownloadEvent, AuditLog } from '../types.ts';
import { DATA_DIR, DB_FILE, APK_STORAGE_DIR } from '../db.ts';
import { createVerifiedTimestampedBackup } from './disasterRecovery.ts';
import { validateDatabaseIntegrity, IntegrityReport } from './integrityValidator.ts';
import { IStorageProvider, IApkStorageProvider } from '../storage/types.ts';

export interface MigrationPlan {
  timestamp: string;
  isDryRun: boolean;
  canExecuteRealMigration: boolean;
  blockers: string[];
  sourceIntegrity: IntegrityReport;
  summary: {
    appsToMigrate: number;
    releasesToMigrate: number;
    submissionsToMigrate: number;
    downloadsToMigrate: number;
    auditLogsToMigrate: number;
    tombstonesToMigrate: number;
    apkFilesToUpload: number;
  };
  sampleAppIds: string[];
  sampleReleaseIds: string[];
}

export interface MigrationResult {
  success: boolean;
  isDryRun: boolean;
  backupCreated?: string;
  migratedApps: number;
  migratedReleases: number;
  migratedSubmissions: number;
  migratedDownloads: number;
  migratedTombstones: number;
  migratedApks: number;
  discrepancies: string[];
  durationMs: number;
}

export function generateMigrationPlan(sourceData?: DatabaseSchema): MigrationPlan {
  const data: DatabaseSchema = sourceData || (fs.existsSync(DB_FILE)
    ? JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'))
    : { users: [], apps: [], app_releases: [], developer_submissions: [], download_events: [], audit_logs: [] });

  const integrity = validateDatabaseIntegrity(data);

  const blockers: string[] = [];

  // Check if live cloud environment is configured
  const backendEnv = process.env.STORAGE_BACKEND;
  const bucketEnv = process.env.GCS_APK_BUCKET;
  const projectEnv = process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT;

  if (backendEnv !== 'firestore') {
    blockers.push('STORAGE_BACKEND is currently set to local. Set STORAGE_BACKEND=firestore to target Cloud Firestore.');
  }
  if (!bucketEnv) {
    blockers.push('GCS_APK_BUCKET is not set. A Google Cloud Storage bucket name is required.');
  }
  if (!projectEnv) {
    blockers.push('GCP_PROJECT_ID is not configured in environment.');
  }

  const sampleApps = (data.apps || []).slice(0, 5).map(a => `${a.id} (${a.name})`);
  const sampleRels = (data.app_releases || []).slice(0, 5).map(r => `${r.id} (${r.packageId} v${r.versionName})`);

  let apkCount = 0;
  if (fs.existsSync(APK_STORAGE_DIR)) {
    apkCount = fs.readdirSync(APK_STORAGE_DIR).filter(f => f.endsWith('.apk')).length;
  }

  return {
    timestamp: new Date().toISOString(),
    isDryRun: true,
    canExecuteRealMigration: blockers.length === 0 && integrity.isValid,
    blockers,
    sourceIntegrity: integrity,
    summary: {
      appsToMigrate: (data.apps || []).length,
      releasesToMigrate: (data.app_releases || []).length,
      submissionsToMigrate: (data.developer_submissions || []).length,
      downloadsToMigrate: (data.download_events || []).length,
      auditLogsToMigrate: (data.audit_logs || []).length,
      tombstonesToMigrate: (data.deleted_app_ids || []).length,
      apkFilesToUpload: apkCount
    },
    sampleAppIds: sampleApps,
    sampleReleaseIds: sampleRels
  };
}

export async function executeSafeMigration(
  targetStorage: IStorageProvider,
  targetApkStorage: IApkStorageProvider,
  options: {
    dryRun?: boolean;
    actorEmail: string;
    sourceDataOverride?: DatabaseSchema;
  }
): Promise<MigrationResult> {
  const startTime = Date.now();
  const isDryRun = options.dryRun ?? true;

  const data: DatabaseSchema = options.sourceDataOverride || (fs.existsSync(DB_FILE)
    ? JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'))
    : { users: [], apps: [], app_releases: [], developer_submissions: [], download_events: [], audit_logs: [] });

  const plan = generateMigrationPlan(data);
  if (!plan.sourceIntegrity.isValid) {
    throw new Error(
      `Migration aborted: Source data integrity check failed with ${plan.sourceIntegrity.issues.length} issues.`
    );
  }

  // In dry-run mode, simulate and return plan metrics
  if (isDryRun) {
    return {
      success: true,
      isDryRun: true,
      migratedApps: plan.summary.appsToMigrate,
      migratedReleases: plan.summary.releasesToMigrate,
      migratedSubmissions: plan.summary.submissionsToMigrate,
      migratedDownloads: plan.summary.downloadsToMigrate,
      migratedTombstones: plan.summary.tombstonesToMigrate,
      migratedApks: plan.summary.apkFilesToUpload,
      discrepancies: [],
      durationMs: Date.now() - startTime
    };
  }

  // Pre-migration step: Create verified timestamped backup
  const backup = createVerifiedTimestampedBackup();

  const discrepancies: string[] = [];

  // Idempotent migration of applications
  for (const app of data.apps || []) {
    try {
      await targetStorage.addApp(app);
    } catch (err: any) {
      discrepancies.push(`Failed to migrate app ${app.id}: ${err.message}`);
    }
  }

  // Idempotent migration of releases
  for (const rel of data.app_releases || []) {
    try {
      await targetStorage.addRelease(rel);
    } catch (err: any) {
      discrepancies.push(`Failed to migrate release ${rel.id}: ${err.message}`);
    }
  }

  // Idempotent migration of submissions
  for (const sub of data.developer_submissions || []) {
    try {
      await targetStorage.addSubmission(sub);
    } catch (err: any) {
      discrepancies.push(`Failed to migrate submission ${sub.id}: ${err.message}`);
    }
  }

  // Idempotent migration of downloads
  for (const dl of data.download_events || []) {
    try {
      await targetStorage.recordDownload(dl.appId, dl.releaseId, dl.packageId, dl.clientType, dl.userAgent);
    } catch (err: any) {
      discrepancies.push(`Failed to migrate download event ${dl.id}: ${err.message}`);
    }
  }

  // Record migration completion audit log
  await targetStorage.addAuditLog(
    'admin',
    options.actorEmail,
    'PRODUCTION_MIGRATION_COMPLETED',
    backup.backupDir,
    'system',
    {
      appsMigrated: (data.apps || []).length,
      releasesMigrated: (data.app_releases || []).length,
      discrepanciesCount: discrepancies.length
    },
    discrepancies.length === 0 ? 'success' : 'failure'
  );

  return {
    success: discrepancies.length === 0,
    isDryRun: false,
    backupCreated: backup.backupDir,
    migratedApps: (data.apps || []).length,
    migratedReleases: (data.app_releases || []).length,
    migratedSubmissions: (data.developer_submissions || []).length,
    migratedDownloads: (data.download_events || []).length,
    migratedTombstones: (data.deleted_app_ids || []).length,
    migratedApks: plan.summary.apkFilesToUpload,
    discrepancies,
    durationMs: Date.now() - startTime
  };
}
