import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db, APK_STORAGE_DIR } from './db.ts';
import { getApkStorageProvider } from './storage/index.ts';

const BASE_URL = 'http://localhost:3000';

async function runPhase6CatalogTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 6: PUBLIC CATALOG, SEARCH & DOWNLOAD SUITE');
  console.log('   (Covers all 13 criteria specified in Phase 6 Step 9)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // 1. Public app listing with existing records
  await step('Test 1: Public app listing returns authoritative published apps', async () => {
    const res = await fetch(`${BASE_URL}/api/apps`);
    assert.strictEqual(res.status, 200, 'GET /api/apps must return 200');
    assert.ok(res.headers.get('content-type')?.includes('application/json'), 'Content-Type must be JSON');

    const data = await res.json();
    assert.ok(Array.isArray(data.apps), 'data.apps must be an array');
    assert.strictEqual(typeof data.total, 'number', 'data.total must be a number');
    assert.strictEqual(data.total, data.apps.length, 'total must match apps count');
    assert.ok(data.apps.length >= 4, `Must return at least 4 published apps (found ${data.apps.length})`);

    // Verify all returned apps are published and have required fields
    for (const app of data.apps) {
      assert.strictEqual(app.publicationStatus, 'published', `App ${app.id} must be published`);
      assert.ok(app.id, 'App must have id');
      assert.ok(app.name, 'App must have name');
      assert.ok(app.slug, 'App must have slug');
      assert.ok(app.packageId, 'App must have packageId');
      assert.ok(app.category, 'App must have category');
      assert.ok(app.iconUrl, 'App must have iconUrl');
      assert.strictEqual(typeof app.downloads, 'number', 'App downloads must be a number');
      if (app.currentRelease) {
        assert.ok(app.currentRelease.versionName, 'Current release must have versionName');
        assert.ok(app.currentRelease.versionCode > 0, 'Current release must have positive versionCode');
        assert.ok(app.currentRelease.sha256, 'Current release must have sha256');
      }
    }
  });

  // 2. A genuinely empty catalog versus a database outage
  await step('Test 2: Differentiates genuine empty catalog from database error', async () => {
    // When a search query matches nothing, return 200 with empty list
    const emptySearchRes = await fetch(`${BASE_URL}/api/apps?q=non_existent_search_query_xyz_12345`);
    assert.strictEqual(emptySearchRes.status, 200, 'Empty search must return 200');
    const emptyData = await emptySearchRes.json();
    assert.strictEqual(emptyData.apps.length, 0, 'Empty search apps must be length 0');
    assert.strictEqual(emptyData.total, 0, 'Empty search total must be 0');

    // A DB query error or unhandled error should NOT return empty catalog
    // Verify error format: an invalid endpoint returns 404 JSON, not fake apps
    const invalidApiRes = await fetch(`${BASE_URL}/api/apps_invalid_route`);
    assert.strictEqual(invalidApiRes.status, 404, 'Invalid route must return 404');
    const errBody = await invalidApiRes.json();
    assert.ok(errBody.error, 'Must return error message');
    assert.strictEqual(errBody.apps, undefined, 'Must not return fake empty apps array on error');
  });

  // 3. App detail lookup by stable ID, slug, and packageId
  await step('Test 3: App detail lookup resolves by stable ID, slug, and packageId', async () => {
    const listRes = await fetch(`${BASE_URL}/api/apps`);
    const listData = await listRes.json();
    const testApp = listData.apps[0];

    // 3a. Lookup by stable ID
    const byIdRes = await fetch(`${BASE_URL}/api/apps/${testApp.id}`);
    assert.strictEqual(byIdRes.status, 200, 'Lookup by ID must return 200');
    const byIdData = await byIdRes.json();
    assert.strictEqual(byIdData.app.id, testApp.id, 'App ID must match');

    // 3b. Lookup by slug
    const bySlugRes = await fetch(`${BASE_URL}/api/apps/${testApp.slug}`);
    assert.strictEqual(bySlugRes.status, 200, 'Lookup by slug must return 200');
    const bySlugData = await bySlugRes.json();
    assert.strictEqual(bySlugData.app.id, testApp.id, 'App resolved by slug must match');

    // 3c. Lookup by packageId
    const byPkgRes = await fetch(`${BASE_URL}/api/apps/${testApp.packageId}`);
    assert.strictEqual(byPkgRes.status, 200, 'Lookup by packageId must return 200');
    const byPkgData = await byPkgRes.json();
    assert.strictEqual(byPkgData.app.id, testApp.id, 'App resolved by packageId must match');

    // 3d. Case-insensitive lookup
    const upperSlug = testApp.slug.toUpperCase();
    const caseRes = await fetch(`${BASE_URL}/api/apps/${upperSlug}`);
    assert.strictEqual(caseRes.status, 200, 'Case-insensitive lookup must succeed');
  });

  // 4. Category and search filtering
  await step('Test 4: Category and search filtering work accurately', async () => {
    // 4a. Categories listing
    const catRes = await fetch(`${BASE_URL}/api/categories`);
    assert.strictEqual(catRes.status, 200, 'GET /api/categories must return 200');
    const catData = await catRes.json();
    assert.ok(Array.isArray(catData.categories), 'Must return categories array');
    assert.ok(catData.categories.length > 0, 'Categories must not be empty');

    const toolsCat = catData.categories.find((c: any) => c.name.toLowerCase() === 'tools');
    assert.ok(toolsCat, 'Tools category must exist');

    // 4b. Category filter
    const filteredRes = await fetch(`${BASE_URL}/api/apps?category=Tools`);
    assert.strictEqual(filteredRes.status, 200, 'Category filter must return 200');
    const filteredData = await filteredRes.json();
    for (const app of filteredData.apps) {
      assert.strictEqual(app.category.toLowerCase(), 'tools', 'All returned apps must belong to Tools category');
    }

    // 4c. Search filter
    const searchRes = await fetch(`${BASE_URL}/api/apps?q=browser`);
    assert.strictEqual(searchRes.status, 200, 'Search must return 200');
    const searchData = await searchRes.json();
    assert.ok(searchData.apps.length > 0, 'Search for browser must find matching app');
    assert.ok(
      searchData.apps.some((a: any) => a.packageId === 'net.orbit.browser' || a.name.toLowerCase().includes('browser')),
      'Must contain orbit browser'
    );
  });

  // 5. Downloading a valid release
  await step('Test 5: Downloading a valid published release streams correct bytes & headers', async () => {
    const listRes = await fetch(`${BASE_URL}/api/apps`);
    const listData = await listRes.json();
    const appWithRelease = listData.apps.find((a: any) => a.currentReleaseId);
    assert.ok(appWithRelease, 'Must have at least one app with active release');

    const releaseId = appWithRelease.currentReleaseId;
    const downloadRes = await fetch(`${BASE_URL}/api/download/${releaseId}?client=android_client`);
    assert.strictEqual(downloadRes.status, 200, 'Download must return 200');

    // Verify all required Android / HTTP streaming headers
    assert.strictEqual(
      downloadRes.headers.get('content-type'),
      'application/vnd.android.package-archive',
      'Content-Type must be Android APK MIME'
    );
    assert.ok(downloadRes.headers.get('content-disposition')?.includes('.apk'), 'Disposition must name .apk');
    assert.ok(downloadRes.headers.get('x-apk-sha256'), 'X-APK-SHA256 header must be present');
    assert.strictEqual(
      downloadRes.headers.get('x-apk-package-id'),
      appWithRelease.packageId,
      'X-APK-Package-ID must match'
    );
    assert.ok(downloadRes.headers.get('x-apk-version-code'), 'X-APK-Version-Code must be present');

    const buffer = Buffer.from(await downloadRes.arrayBuffer());
    assert.ok(buffer.length > 0, 'Downloaded buffer must not be empty');
    const computedHash = crypto.createHash('sha256').update(buffer).digest('hex');
    assert.strictEqual(
      computedHash.toLowerCase(),
      downloadRes.headers.get('x-apk-sha256')?.toLowerCase(),
      'Stream checksum must match X-APK-SHA256 header'
    );
  });

  // 6. Invalid release IDs and missing APK objects
  await step('Test 6: Invalid release IDs and missing objects return 404 JSON without unpublishing apps', async () => {
    // 6a. Non-existent release ID
    const notFoundRes = await fetch(`${BASE_URL}/api/download/non-existent-release-99999`);
    assert.strictEqual(notFoundRes.status, 404, 'Non-existent release must return 404');
    assert.ok(notFoundRes.headers.get('content-type')?.includes('application/json'), 'Must return JSON error');
    const notFoundData = await notFoundRes.json();
    assert.ok(notFoundData.error, 'Must have error message');

    // 6b. Verify no app was modified or unpublished
    const appsAfter = db.getPublishedApps();
    assert.ok(appsAfter.length >= 4, 'Published apps count must be preserved');
  });

  // 7. Storage permission errors and timeouts
  await step('Test 7: Storage provider errors propagate safely without corrupting metadata', async () => {
    const apkStorage = getApkStorageProvider();

    // Verify handling of empty/whitespace storage path
    const emptyResult = await apkStorage.getApkStream('');
    assert.strictEqual(emptyResult.exists, false, 'Empty storage path must report exists = false');
  });

  // 8. Correct HTTP status codes and content types
  await step('Test 8: API endpoints guarantee strict JSON content types and error codes', async () => {
    const endpoints = [
      { url: `${BASE_URL}/api/apps`, status: 200 },
      { url: `${BASE_URL}/api/categories`, status: 200 },
      { url: `${BASE_URL}/api/stats`, status: 200 },
      { url: `${BASE_URL}/api/health`, status: 200 },
      { url: `${BASE_URL}/api/apps/non-existent-slug-xyz`, status: 404 }
    ];

    for (const ep of endpoints) {
      const res = await fetch(ep.url);
      assert.strictEqual(res.status, ep.status, `${ep.url} must return ${ep.status}`);
      const ctype = res.headers.get('content-type') || '';
      assert.ok(ctype.includes('application/json'), `${ep.url} must return application/json (got ${ctype})`);
    }
  });

  // 9. Error responses that are JSON when expected by the API contract
  await step('Test 9: Explicit /api/* 404 handler prevents HTML SPA fallback leaks', async () => {
    const res = await fetch(`${BASE_URL}/api/any-arbitrary-unmatched-path-12345`);
    assert.strictEqual(res.status, 404, 'Unmatched API route must return 404');
    const contentType = res.headers.get('content-type') || '';
    assert.ok(contentType.includes('application/json'), 'Must return application/json, NOT text/html');

    const data = await res.json();
    assert.strictEqual(data.code, 'ENDPOINT_NOT_FOUND', 'Must return ENDPOINT_NOT_FOUND code');
    assert.ok(data.error.includes('not found'), 'Must have descriptive error');
  });

  // 10. Cache failure without permanent catalog disappearance
  await step('Test 10: Cache failures or flushes do not cause catalog data disappearance', async () => {
    // Repeated fetches return consistent authoritative results
    const fetch1 = await (await fetch(`${BASE_URL}/api/apps`)).json();
    const fetch2 = await (await fetch(`${BASE_URL}/api/apps`)).json();
    assert.strictEqual(fetch1.apps.length, fetch2.apps.length, 'Consecutive fetches must yield consistent counts');

    // Authoritative database remains intact
    const dbApps = db.getPublishedApps();
    assert.strictEqual(dbApps.length, fetch1.apps.length, 'Database matches API results');
  });

  // 11. Statistics failures without changing app records
  await step('Test 11: GET /api/stats accurately reports platform metrics without modifying data', async () => {
    const statsRes = await fetch(`${BASE_URL}/api/stats`);
    assert.strictEqual(statsRes.status, 200, 'GET /api/stats must return 200');
    const stats = await statsRes.json();

    assert.strictEqual(typeof stats.publishedAppsCount, 'number', 'publishedAppsCount must be number');
    assert.strictEqual(typeof stats.totalDownloadsRecorded, 'number', 'totalDownloadsRecorded must be number');
    assert.strictEqual(typeof stats.publishedReleasesCount, 'number', 'publishedReleasesCount must be number');

    assert.strictEqual(stats.publishedAppsCount, 4, 'Must report 4 published apps');
    assert.ok(stats.publishedReleasesCount >= 4, 'Must report at least 4 published releases');
    assert.ok(stats.totalDownloadsRecorded >= 15, 'Must report recorded download events');
  });

  // 12. Existing published apps remaining published after server restarts and failed requests
  await step('Test 12: Published apps retain published status across restarts and bad requests', async () => {
    const publishedApps = db.getPublishedApps();
    assert.strictEqual(publishedApps.length, 4, 'Must have exactly 4 published apps');

    const expectedIds = ['app-em-store-client', 'app-zenith-notes', 'app-pulse-audio-player', 'app-orbit-browser'];
    for (const id of expectedIds) {
      const app = db.getAppById(id);
      assert.ok(app, `App ${id} must exist in database`);
      assert.strictEqual(app.publicationStatus, 'published', `App ${id} must have status = published`);
    }
  });

  // 13. Compatibility with the existing Android API contracts
  await step('Test 13: 100% Contract compatibility verified with native Android Retrofit models', async () => {
    // 13a. Verify AppListResponse structure
    const listRes = await fetch(`${BASE_URL}/api/apps`);
    const listData = await listRes.json();
    assert.ok('apps' in listData, 'Must contain "apps" field');
    assert.ok('total' in listData, 'Must contain "total" field');

    const appItem = listData.apps[0];
    const requiredAppFields = [
      'id', 'name', 'slug', 'packageId', 'shortDescription', 'category',
      'iconUrl', 'currentReleaseId', 'publicationStatus', 'downloads', 'currentRelease'
    ];
    for (const field of requiredAppFields) {
      assert.ok(field in appItem, `AppItemDto missing field: ${field}`);
    }

    if (appItem.currentRelease) {
      const requiredReleaseFields = ['versionName', 'versionCode', 'fileSize', 'sha256'];
      for (const field of requiredReleaseFields) {
        assert.ok(field in appItem.currentRelease, `ReleaseItemDto missing field: ${field}`);
      }
    }

    // 13b. Verify AppDetailsResponse structure
    const detailsRes = await fetch(`${BASE_URL}/api/apps/${appItem.slug}`);
    const detailsData = await detailsRes.json();
    assert.ok('app' in detailsData, 'AppDetailsResponse must contain "app"');
    assert.ok('releases' in detailsData, 'AppDetailsResponse must contain "releases"');
    assert.ok('downloads' in detailsData, 'AppDetailsResponse must contain "downloads"');

    // 13c. Verify CategoriesResponse structure
    const catRes = await fetch(`${BASE_URL}/api/categories`);
    const catData = await catRes.json();
    assert.ok('categories' in catData, 'CategoriesResponse must contain "categories"');
    assert.ok('name' in catData.categories[0], 'CategoryDto must contain "name"');
    assert.ok('count' in catData.categories[0], 'CategoryDto must contain "count"');

    // 13d. Verify PlatformStatsDto structure
    const statsRes = await fetch(`${BASE_URL}/api/stats`);
    const statsData = await statsRes.json();
    const statsFields = ['publishedAppsCount', 'totalDownloadsRecorded', 'publishedReleasesCount'];
    for (const field of statsFields) {
      assert.ok(field in statsData, `PlatformStatsDto missing field: ${field}`);
    }
  });

  console.log('\n========================================================================');
  console.log(`   PHASE 6 TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase6CatalogTestSuite().catch(err => {
  console.error('Phase 6 Test suite crashed:', err);
  process.exit(1);
});
