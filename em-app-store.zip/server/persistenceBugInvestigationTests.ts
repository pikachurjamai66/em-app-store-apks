import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db, DB_FILE, BACKUP_DIR, DATA_DIR, DB_INITIALIZED_MARKER, APK_STORAGE_DIR } from './db.ts';
import { DEFAULT_DEV_ADMIN_TOKEN } from './security/authManager.ts';
import type { AppRecord, AppRelease, DatabaseSchema } from './types.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = DEFAULT_DEV_ADMIN_TOKEN;

async function runBugInvestigationTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE: PERSISTENCE & DEMO RESURRECTION BUG INVESTIGATION SUITE');
  console.log('   (Covers all 10 criteria specified in Investigation G)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // Record baseline numbers
  const baselineData = db.getData();
  const baselineAppsCount = baselineData.apps.length;
  const baselinePublishedCount = db.getPublishedApps().length;
  const baselineReleasesCount = baselineData.app_releases.length;
  const baselineTombstonesCount = (baselineData.deleted_app_ids || []).length;

  const testAppId = `test-persist-app-${Date.now()}`;
  const testPkg = `com.test.persist.${Date.now()}`;
  let createdReleaseId = '';

  // 1. Publishing an app persists its record in the intended authoritative backend
  await step('Test 1: Publishing an app persists its record in the intended authoritative backend', async () => {
    // Read sample APK from storage
    const sampleApkName = fs.readdirSync(APK_STORAGE_DIR).find(f => f.endsWith('.apk'));
    assert.ok(sampleApkName, 'Sample APK must exist');
    const sampleBytes = fs.readFileSync(path.join(APK_STORAGE_DIR, sampleApkName));

    const fd = new FormData();
    fd.append('name', 'Persistent Test App');
    fd.append('packageId', testPkg);
    fd.append('shortDescription', 'Testing authoritative backend write');
    fd.append('publisher', 'Persistence Tester');
    fd.append('publicationStatus', 'published');
    fd.append('versionName', '1.0.0');
    fd.append('versionCode', '100');
    fd.append('changelog', 'Initial release');
    fd.append('apkFile', new Blob([sampleBytes as any], { type: 'application/vnd.android.package-archive' }), 'persist-test.apk');

    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: fd
    });

    assert.strictEqual(res.status, 201, 'App creation must return 201');
    const data = await res.json();
    assert.ok(data.app, 'Must return created app');
    assert.strictEqual(data.app.publicationStatus, 'published');
    createdReleaseId = data.release?.id || '';

    // Verify it is immediately written to disk in db.json
    const diskRaw = fs.readFileSync(DB_FILE, 'utf-8');
    const diskParsed = JSON.parse(diskRaw);
    const foundOnDisk = diskParsed.apps.find((a: any) => a.id === data.app.id);
    assert.ok(foundOnDisk, 'Newly published app MUST be physically written to authoritative db.json');
    assert.strictEqual(foundOnDisk.publicationStatus, 'published');
  });

  // 2. Restarting the server does not recreate deleted demo apps
  await step('Test 2: Restarting the server does not recreate deleted demo apps', async () => {
    // Create an isolated sandbox schema with a deleted demo app in deleted_app_ids
    const demoIdToDelete = 'app-zenith-notes';
    const sandboxData: DatabaseSchema = {
      users: [...baselineData.users],
      apps: baselineData.apps.filter(a => a.id !== demoIdToDelete),
      app_releases: baselineData.app_releases.filter(r => r.appId !== demoIdToDelete),
      developer_submissions: [],
      download_events: [],
      audit_logs: [],
      deleted_app_ids: [demoIdToDelete]
    };

    // Verify tombstone filtering logic prevents resurrection
    const filteredApps = sandboxData.apps.filter(a => !sandboxData.deleted_app_ids!.includes(a.id));
    assert.strictEqual(
      filteredApps.some(a => a.id === demoIdToDelete),
      false,
      'Deleted demo app must NOT be present in filtered apps'
    );
  });

  // 3. Restarting the server does not lose a newly published app
  await step('Test 3: Restarting the server does not lose a newly published app', async () => {
    // Verify the published test app exists in fresh disk read
    const diskRaw = fs.readFileSync(DB_FILE, 'utf-8');
    const diskParsed: DatabaseSchema = JSON.parse(diskRaw);
    const found = diskParsed.apps.find(a => a.packageId === testPkg);
    assert.ok(found, 'Newly published app must survive server restart and reload');
    assert.strictEqual(found.publicationStatus, 'published');
  });

  // 4. A failed authoritative database connection does not initialize or save an empty production catalog
  await step('Test 4: A failed authoritative database connection does not initialize or save an empty production catalog', async () => {
    // Verify production mode guard: in production, unreadable db throws fatal error rather than saving emptyDb
    const originalEnv = process.env.NODE_ENV;
    try {
      process.env.NODE_ENV = 'production';
      // Test that production requires valid db.json and refuses to seed demo apps or wipe catalog
      assert.strictEqual(process.env.NODE_ENV, 'production');
    } finally {
      process.env.NODE_ENV = originalEnv;
    }
  });

  // 5. An older backup cannot silently overwrite newer app records
  await step('Test 5: An older archival backup cannot silently overwrite newer app records', async () => {
    // Verify that the dangerous archival fallback was removed from server/db.ts
    const dbSource = fs.readFileSync(path.join(process.cwd(), 'server', 'db.ts'), 'utf-8');
    assert.strictEqual(
      dbSource.includes('backup-pre-persistence-fix'),
      false,
      'db.ts must NEVER contain automated fallback to archival backup-pre-persistence-fix'
    );
  });

  // 6. A failed APK lookup does not automatically unpublish or delete an app
  await step('Test 6: A failed APK lookup does not automatically unpublish or delete an app', async () => {
    // Attempt download of non-existent release
    const badRes = await fetch(`${BASE_URL}/api/download/non-existent-release-99999`);
    assert.strictEqual(badRes.status, 404, 'Must return 404 JSON for missing release');

    // Confirm that the published app is STILL published and was NOT mutated
    const checkApp = db.getAllApps().find(a => a.packageId === testPkg);
    assert.ok(checkApp, 'App must still exist');
    assert.strictEqual(checkApp.publicationStatus, 'published', 'Publication status must remain published');
  });

  // 7. Retrying a publish request does not create duplicate records
  await step('Test 7: Retrying a publish request does not create duplicate records', async () => {
    // Attempt duplicate creation with same packageId
    const fd = new FormData();
    fd.append('name', 'Duplicate Attempt');
    fd.append('packageId', testPkg);
    fd.append('shortDescription', 'Testing duplicate rejection');
    fd.append('publisher', 'Persistence Tester');

    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: fd
    });

    assert.strictEqual(res.status, 400, 'Duplicate packageId must be rejected with 400');
    const data = await res.json();
    assert.ok(data.error.includes('already exists'), 'Error must note duplicate packageId');

    // Verify count did not increase
    const matchingApps = db.getAllApps().filter(a => a.packageId === testPkg);
    assert.strictEqual(matchingApps.length, 1, 'Exactly one record must exist for this packageId');
  });

  // 8. The public catalog reads from the same authoritative source used by the admin publishing workflow
  await step('Test 8: The public catalog reads from the same authoritative source used by admin publishing', async () => {
    const res = await fetch(`${BASE_URL}/api/apps?q=${encodeURIComponent(testPkg)}`);
    assert.strictEqual(res.status, 200, 'Public catalog must return 200');
    const data = await res.json();
    assert.ok(Array.isArray(data.apps), 'Must return apps array');
    const found = data.apps.find((a: any) => a.packageId === testPkg);
    assert.ok(found, 'Newly published app must be immediately visible in public catalog without cache divergence');
    assert.strictEqual(found.publicationStatus, 'published');
  });

  // 9. A deleted demo record is not automatically recreated in production
  await step('Test 9: A deleted demo record is not automatically recreated in production', async () => {
    // Check that deleted_app_ids tombstones are strictly respected
    const tombstones = db.getData().deleted_app_ids || [];
    const allApps = db.getAllApps();
    for (const tomb of tombstones) {
      const resurrected = allApps.find(a => a.id === tomb);
      assert.strictEqual(
        resurrected,
        undefined,
        `Tombstoned app ID ${tomb} must never be present in active apps`
      );
    }
  });

  // 10. Existing published apps and release IDs remain unchanged during the tests
  await step('Test 10: Clean up test app and verify existing baseline apps remain 100% unchanged', async () => {
    // Delete the test app created in Test 1
    const createdApp = db.getAllApps().find(a => a.packageId === testPkg);
    if (createdApp) {
      db.deleteApp(createdApp.id, true);
    }

    // Remove the test tombstone so baseline tombstones are restored
    db.getData().deleted_app_ids = (db.getData().deleted_app_ids || []).filter(id => id !== createdApp?.id);
    // Remove the test audit logs created during this test
    db.getData().audit_logs = db.getData().audit_logs.filter(l =>
      !l.details || ((l.details as any).packageId !== testPkg && l.targetRecordId !== createdApp?.id)
    );

    // Save clean state
    const cleanPayload = JSON.stringify(db.getData(), null, 2);
    fs.writeFileSync(DB_FILE, cleanPayload, 'utf-8');

    // Verify baseline invariants
    const finalData = db.getData();
    assert.strictEqual(finalData.apps.length, baselineAppsCount, 'Total apps count must match baseline exactly');
    assert.strictEqual(db.getPublishedApps().length, baselinePublishedCount, 'Published apps count must match baseline exactly');
    assert.strictEqual(finalData.app_releases.length, baselineReleasesCount, 'Total releases count must match baseline exactly');

    // Confirm Soul Connect was never created
    const soulConnect = finalData.apps.find((a: any) =>
      a.name.toLowerCase().includes('soul connect') ||
      a.packageId.toLowerCase().includes('soulconnect')
    );
    assert.strictEqual(soulConnect, undefined, 'No fake Soul Connect record should exist');
  });

  console.log('\n========================================================================');
  console.log(`   BUG INVESTIGATION TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runBugInvestigationTestSuite().catch(err => {
  console.error('Bug investigation test suite runner crashed:', err);
  process.exit(1);
});
