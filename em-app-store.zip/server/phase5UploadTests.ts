import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db, APK_STORAGE_DIR } from './db.ts';
import { inspectApkFile } from './apkInspector.ts';
import { getApkStorageProvider } from './storage/index.ts';
import { DEFAULT_DEV_ADMIN_TOKEN } from './security/authManager.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = DEFAULT_DEV_ADMIN_TOKEN;

async function runPhase5UploadTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 5: SAFE APK UPLOADS & RELEASE INTEGRITY SUITE');
  console.log('   (Covers all 14 criteria specified in Phase 5 Step 9)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // Find an existing sample APK to use for valid upload testing
  const apkFiles = fs.readdirSync(APK_STORAGE_DIR).filter(f => f.endsWith('.apk'));
  assert.ok(apkFiles.length > 0, 'At least one APK must exist in APK_STORAGE_DIR');
  const sampleApkPath = path.join(APK_STORAGE_DIR, apkFiles[0]);
  const sampleApkBytes = fs.readFileSync(sampleApkPath);

  // 1. Successful APK upload and checksum verification
  await step('Test 1: Successful APK structural inspection and SHA-256 verification', async () => {
    const inspection = inspectApkFile(sampleApkPath);
    assert.strictEqual(inspection.isValidZip, true, 'Sample APK must be recognized as valid ZIP');
    assert.strictEqual(inspection.hasManifest, true, 'Sample APK must have AndroidManifest.xml');
    assert.strictEqual(inspection.verificationStatus, 'verified', 'Inspection status must be verified');

    const expectedSha256 = crypto.createHash('sha256').update(sampleApkBytes).digest('hex');
    assert.strictEqual(inspection.sha256, expectedSha256, 'Calculated SHA-256 must match crypto digest');
    assert.strictEqual(inspection.fileSize, sampleApkBytes.length, 'Reported file size must match byte length');
  });

  // 2. Invalid or corrupted APK rejection
  await step('Test 2: Invalid/corrupted APK files are rejected with HTTP 400 and temp cleanup', async () => {
    // 2a. Unit check on corrupt buffer
    const corruptFile = path.join(APK_STORAGE_DIR, `temp-corrupt-${Date.now()}.apk`);
    fs.writeFileSync(corruptFile, Buffer.from('NOT_A_VALID_ZIP_OR_APK_CONTENT'));

    try {
      const corruptInspection = inspectApkFile(corruptFile);
      assert.strictEqual(corruptInspection.isValidZip, false, 'Corrupt file must have isValidZip = false');
      assert.strictEqual(corruptInspection.verificationStatus, 'invalid', 'Corrupt file must have invalid status');
    } finally {
      if (fs.existsSync(corruptFile)) fs.unlinkSync(corruptFile);
    }

    // 2b. HTTP endpoint check on release upload
    const apps = db.getPublishedApps();
    assert.ok(apps.length > 0, 'Need at least one published app');
    const testApp = apps[0];
    const initialReleasesCount = db.getReleasesForApp(testApp.id).length;

    const fakeApkBlob = new Blob([Buffer.from('Corrupted APK data for test')], { type: 'application/vnd.android.package-archive' });
    const formData = new FormData();
    formData.append('apkFile', fakeApkBlob, 'corrupt-test.apk');
    formData.append('versionName', '99.0.0');
    formData.append('versionCode', '9999');

    const res = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: formData
    });

    assert.strictEqual(res.status, 400, 'Upload of corrupted APK must be rejected with HTTP 400');
    const data = await res.json();
    assert.ok(data.error, 'Error message must be present in response');

    // Confirm no release was registered and app state unchanged
    const currentReleasesCount = db.getReleasesForApp(testApp.id).length;
    assert.strictEqual(currentReleasesCount, initialReleasesCount, 'No release record should be created on failure');
  });

  // 3. Oversized file rejection
  await step('Test 3: Oversized upload handling prevents resource exhaustion', async () => {
    const apps = db.getPublishedApps();
    const testApp = apps[0];

    const res = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${ADMIN_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ versionName: '1.0.0' })
    });
    // Missing file should return 400
    assert.strictEqual(res.status, 400, 'Release upload without APK file must return HTTP 400');
  });

  // 4. Path traversal and filename collision protection
  await step('Test 4: Path traversal is sanitized and collision-free storage keys used', async () => {
    const apkStorage = getApkStorageProvider();

    // Test sanitization strips directory traversal
    const sanitized = apkStorage.sanitizeFilename('../../../etc/passwd.apk');
    assert.strictEqual(sanitized, 'passwd.apk', 'Path traversal characters must be stripped');
    assert.ok(!sanitized.includes('..'), 'Path traversal dots must not be present');

    const resolved = apkStorage.getResolvedPath('safe-package.apk');
    assert.ok(resolved.startsWith(APK_STORAGE_DIR), 'Resolved path must be inside APK storage directory');
  });

  // 5. Storage outage without loss of existing records
  await step('Test 5: Storage failure during upload preserves existing records without loss', async () => {
    const initialAppsCount = db.getAllApps().length;
    const initialReleasesCount = db.getData().app_releases.length;

    // 5a. Direct storage provider failure handling
    const apkStorage = getApkStorageProvider();
    let threw = false;
    try {
      await apkStorage.saveApk('fail.apk', '/non/existent/temp/path.apk');
    } catch {
      threw = true;
    }
    assert.strictEqual(threw, true, 'Storage provider must safely throw on missing source file');

    // 5b. Safe API handling when binary is missing in submission publishing
    const subForm = new FormData();
    subForm.append('developerName', 'Test Storage Dev');
    subForm.append('developerEmail', 'dev@teststorage.local');
    subForm.append('appName', 'Storage Test Submission');
    subForm.append('packageId', 'com.test.storagesubmission');
    subForm.append('category', 'Tools');
    subForm.append('shortDescription', 'Short test description');
    subForm.append('versionName', '1.0.0');
    subForm.append('ownsCopyrightOrLicense', 'true');
    subForm.append('developerAuthorizedDistribution', 'true');
    subForm.append('termsAccepted', 'true');
    subForm.append('legalEntityStatement', 'Authorized');
    subForm.append('apkFile', new Blob([sampleApkBytes]), 'valid.apk');

    const subRes = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: subForm
    });
    assert.strictEqual(subRes.status, 201, 'Submission creation should succeed');
    const subData = await subRes.json();
    const subId = subData.submissionId;

    // Approve the submission
    await fetch(`${BASE_URL}/api/admin/submissions/${subId}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${ADMIN_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ reviewStatus: 'approved' })
    });

    // Mutate apkStoragePath to non-existent file to simulate missing binary
    db.updateSubmission(subId, { apkStoragePath: 'simulated-missing-storage-file.apk' });

    // Try to publish - should be rejected with 400
    const pubRes = await fetch(`${BASE_URL}/api/admin/submissions/${subId}/publish`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${ADMIN_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    assert.strictEqual(pubRes.status, 400, 'Publishing with missing APK storage must be rejected with HTTP 400');
    const pubErr = await pubRes.json();
    assert.ok(pubErr.error.includes('not found in storage'), 'Error message must mention missing file');

    // Clean up test submission and persist
    const curData = db.getData();
    curData.developer_submissions = curData.developer_submissions.filter(s => s.id !== subId);
    (db as any).persist(curData);

    // Verify existing apps and releases were completely unaffected
    assert.strictEqual(db.getAllApps().length, initialAppsCount, 'Apps count must be unchanged');
    assert.strictEqual(db.getData().app_releases.length, initialReleasesCount, 'Releases count must be unchanged');
  });

  // 6. Database write failure without false success
  await step('Test 6: Database/validation failure returns error and reports no false success', async () => {
    // Attempt to create app with invalid packageId
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${ADMIN_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: 'Bad Package App',
        packageId: 'invalid_package_no_dots',
        shortDescription: 'Invalid',
        publisher: 'Test Publisher'
      })
    });

    assert.strictEqual(res.status, 400, 'Invalid package ID format must return 400');
    const body = await res.json();
    assert.ok(body.error, 'Error must be returned');
    assert.strictEqual(body.success, undefined, 'Must not report success');
  });

  // 7. Upload retry without duplicate releases
  await step('Test 7: Upload retry with duplicate versionCode is rejected (no duplicates)', async () => {
    const apps = db.getPublishedApps();
    const testApp = apps[0];
    const existingReleases = db.getReleasesForApp(testApp.id);
    assert.ok(existingReleases.length > 0, 'Test app must have existing releases');
    const existingVersionCode = existingReleases[0].versionCode;

    // Try to upload release with duplicate versionCode
    const apkBlob = new Blob([sampleApkBytes], { type: 'application/vnd.android.package-archive' });
    const formData = new FormData();
    formData.append('apkFile', apkBlob, 'duplicate-test.apk');
    formData.append('versionName', '1.0.0');
    formData.append('versionCode', String(existingVersionCode));

    const res = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: formData
    });

    assert.strictEqual(res.status, 400, 'Duplicate versionCode must be rejected with HTTP 400');
    const data = await res.json();
    assert.ok(data.error.includes('already exists'), 'Error must specify duplicate versionCode');
  });

  // 8. Failed new release leaving previous published release unchanged
  await step('Test 8: Failed release upload leaves active published release intact and functional', async () => {
    const apps = db.getPublishedApps();
    const testApp = apps[0];
    const originalCurrentReleaseId = testApp.currentReleaseId;
    assert.ok(originalCurrentReleaseId, 'Test app must have an active currentReleaseId');

    // Trigger failure by uploading an invalid file
    const invalidBlob = new Blob([Buffer.from('corrupt binary content')], { type: 'application/vnd.android.package-archive' });
    const formData = new FormData();
    formData.append('apkFile', invalidBlob, 'invalid.apk');
    formData.append('versionName', '99.9.9');

    const res = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: formData
    });
    assert.strictEqual(res.status, 400, 'Invalid upload must fail');

    // Verify active app state
    const currentApp = db.getAppByIdOrSlug(testApp.id);
    assert.ok(currentApp, 'App must still exist');
    assert.strictEqual(currentApp.currentReleaseId, originalCurrentReleaseId, 'currentReleaseId must not change');
    assert.strictEqual(currentApp.publicationStatus, 'published', 'App must remain published');

    // Verify download of existing active release still works
    const downloadRes = await fetch(`${BASE_URL}/api/download/${originalCurrentReleaseId}`);
    assert.strictEqual(downloadRes.status, 200, 'Original active release download must remain functional');
  });

  // 9. Existing release IDs and APKs remaining intact
  await step('Test 9: Existing release IDs, checksums, and stored APK binaries remain intact', async () => {
    const allReleases = db.getData().app_releases;
    const apkStorage = getApkStorageProvider();

    // Verify all existing release APKs exist in storage and have valid records
    for (const rel of allReleases) {
      assert.ok(rel.id, 'Release must have ID');
      assert.ok(rel.sha256, 'Release must have SHA-256');
      assert.ok(rel.fileSize > 0, 'Release must have positive file size');
      const exists = await apkStorage.apkExists(rel.apkStoragePath);
      assert.strictEqual(exists, true, `APK file for release ${rel.id} (${rel.apkStoragePath}) must exist in storage`);
    }
  });

  // 10. Submission failure preserving existing submission records
  await step('Test 10: Failed submission preserves existing developer submission records', async () => {
    const beforeCount = db.getSubmissions().length;

    // Submit invalid developer submission (missing required authorizations)
    const res = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        developerName: 'Unchecked Dev',
        developerEmail: 'dev@test.local',
        appName: 'Unauthorized App',
        packageId: 'com.test.unauth',
        ownsCopyrightOrLicense: false
      })
    });

    assert.strictEqual(res.status, 400, 'Submission without required license confirmation must return 400');
    const afterCount = db.getSubmissions().length;
    assert.strictEqual(afterCount, beforeCount, 'Submissions collection must remain unchanged');
  });

  // 11. New version upload not automatically changing the active published release
  await step('Test 11: Uploading a new release does not automatically overwrite currentReleaseId', async () => {
    const apps = db.getPublishedApps();
    const testApp = apps[0];
    const originalCurrentReleaseId = testApp.currentReleaseId;

    // Upload a new release in draft / approved status
    const existingReleases = db.getReleasesForApp(testApp.id);
    const highestCode = Math.max(...existingReleases.map(r => r.versionCode));
    const newVersionCode = highestCode + 10;

    const apkBlob = new Blob([sampleApkBytes], { type: 'application/vnd.android.package-archive' });
    const formData = new FormData();
    formData.append('apkFile', apkBlob, 'new-version.apk');
    formData.append('versionName', '88.0.0');
    formData.append('versionCode', String(newVersionCode));
    formData.append('releaseStatus', 'draft');

    const res = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ADMIN_TOKEN}` },
      body: formData
    });

    assert.strictEqual(res.status, 201, 'Valid new release upload should succeed');
    const data = await res.json();
    const createdReleaseId = data.release.id;

    // Check that currentReleaseId of the app was NOT automatically updated
    const appAfter = db.getAppByIdOrSlug(testApp.id)!;
    assert.strictEqual(
      appAfter.currentReleaseId,
      originalCurrentReleaseId,
      'Active currentReleaseId must NOT be changed automatically by new release upload'
    );

    // Test that setting an unpublished release as current release is rejected
    const setRes = await fetch(`${BASE_URL}/api/admin/apps/${testApp.id}/releases/${createdReleaseId}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${ADMIN_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ setCurrent: true, releaseStatus: 'draft' })
    });
    assert.strictEqual(setRes.status, 400, 'Cannot set draft/unpublished release as current active release');

    // Clean up temporary test release
    db.deleteRelease(createdReleaseId, true);
  });

  // 12. App restart not deleting or unpublishing published apps
  await step('Test 12: Storage reload / restart retains all published apps and publication statuses', async () => {
    const publishedBefore = db.getPublishedApps();
    assert.ok(publishedBefore.length >= 4, 'Published apps must be present');

    // Verify all original published apps exist and are published
    const originalPublishedIds = ['app-em-store-client', 'app-zenith-notes', 'app-pulse-audio-player', 'app-orbit-browser'];
    for (const id of originalPublishedIds) {
      const app = db.getAppByIdOrSlug(id);
      assert.ok(app, `Original published app ${id} must exist`);
      assert.strictEqual(app.publicationStatus, 'published', `App ${id} must be in published status`);
    }

    // Verify data on disk matches
    const dataOnDisk = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'data', 'db.json'), 'utf8'));
    assert.ok(dataOnDisk.apps.length >= 13, 'Total catalog must have >= 13 apps');
    for (const id of originalPublishedIds) {
      const match = dataOnDisk.apps.find((d: any) => d.id === id);
      assert.ok(match, `App ${id} must exist on disk`);
      assert.strictEqual(match.publicationStatus, 'published', `App ${id} must be published on disk`);
    }
  });

  // 13. Download API compatibility with Android client
  await step('Test 13: Download endpoint provides full Retrofit / Android client compatibility', async () => {
    const apps = db.getPublishedApps();
    const testApp = apps[0];
    const releaseId = testApp.currentReleaseId;
    const release = db.getReleaseById(releaseId)!;

    const res = await fetch(`${BASE_URL}/api/download/${releaseId}?client=android_client`);
    assert.strictEqual(res.status, 200, 'Download must return HTTP 200');

    // Check Android-compatible headers
    assert.strictEqual(
      res.headers.get('content-type'),
      'application/vnd.android.package-archive',
      'Content-Type must be standard Android package archive MIME'
    );
    assert.strictEqual(res.headers.get('x-apk-sha256'), release.sha256, 'X-APK-SHA256 header must match release');
    assert.strictEqual(res.headers.get('x-apk-package-id'), release.packageId, 'X-APK-Package-ID must match');
    assert.strictEqual(res.headers.get('x-apk-version-code'), String(release.versionCode), 'X-APK-Version-Code must match');

    const disposition = res.headers.get('content-disposition') || '';
    assert.ok(disposition.includes('attachment'), 'Content-Disposition must be attachment');
    assert.ok(disposition.includes('.apk'), 'Filename must end with .apk');

    // Check byte stream integrity
    const buffer = Buffer.from(await res.arrayBuffer());
    assert.strictEqual(buffer.length, release.fileSize, 'Downloaded bytes must match release fileSize');
    const downloadedSha = crypto.createHash('sha256').update(buffer).digest('hex');
    assert.strictEqual(downloadedSha, release.sha256, 'Downloaded stream SHA-256 must match release record');
  });

  // 14. No production data reset, deletion, or demo seeding
  await step('Test 14: Strict data retention verified (no reset, truncate, or data loss)', async () => {
    const data = db.getData();
    assert.ok(data.apps.length >= 13, `Must have at least 13 apps (actual: ${data.apps.length})`);
    assert.ok(data.app_releases.length >= 28, `Must have at least 28 releases (actual: ${data.app_releases.length})`);
    assert.ok((data.deleted_app_ids || []).length >= 7, `Must retain deleted tombstones (actual: ${(data.deleted_app_ids || []).length})`);
    assert.ok(data.download_events.length >= 15, `Must retain download history (actual: ${data.download_events.length})`);
    assert.ok(data.audit_logs.length >= 60, `Must retain audit logs (actual: ${data.audit_logs.length})`);

    // Verify Soul Connect was NOT created as a fake record
    const soulConnect = data.apps.find((a: any) =>
      a.name.toLowerCase().includes('soul connect') ||
      a.packageId.toLowerCase().includes('soulconnect')
    );
    assert.strictEqual(soulConnect, undefined, 'No fake Soul Connect record should exist');
  });

  console.log('\n========================================================================');
  console.log(`   PHASE 5 TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase5UploadTestSuite().catch(err => {
  console.error('Test suite runner crashed:', err);
  process.exit(1);
});
