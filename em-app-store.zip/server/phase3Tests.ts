import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Readable, PassThrough } from 'stream';
import { LocalStorageProvider, LocalApkStorageProvider } from './storage/localStorage.ts';
import { FirestoreStorageProvider } from './storage/firestoreStorage.ts';
import { GcsApkStorageProvider } from './storage/gcsStorage.ts';
import { initializeStorage, getStorageHealth } from './storage/index.ts';
import { DatabaseSchema, AppRecord, AppRelease, DeveloperSubmission } from './types.ts';
import { validateDatabaseIntegrity } from './migration/integrityValidator.ts';
import { compareBackupWithActive, safeRestoreFromBackup, createVerifiedTimestampedBackup } from './migration/disasterRecovery.ts';
import { generateMigrationPlan, executeSafeMigration } from './migration/migrateToCloud.ts';

// Reusable mock Firestore factory
function createMockFirestore() {
  const collections: Record<string, Map<string, any>> = {
    apps: new Map(),
    releases: new Map(),
    submissions: new Map(),
    download_events: new Map(),
    audit_logs: new Map(),
    tombstones: new Map(),
    users: new Map(),
    _healthcheck: new Map([['ping', { ok: true }]])
  };

  const createDocRef = (collName: string, docId: string) => ({
    id: docId,
    get: async () => {
      const coll = collections[collName] || new Map();
      const data = coll.get(docId);
      return {
        exists: data !== undefined,
        id: docId,
        data: () => (data ? JSON.parse(JSON.stringify(data)) : undefined)
      };
    },
    set: async (data: any, options?: { merge?: boolean }) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId) || {};
      const finalData = options?.merge ? { ...existing, ...data } : data;
      collections[collName].set(docId, JSON.parse(JSON.stringify(finalData)));
    },
    update: async (data: any) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId);
      if (!existing) throw new Error(`Document ${docId} does not exist for update`);
      collections[collName].set(docId, { ...existing, ...JSON.parse(JSON.stringify(data)) });
    },
    delete: async () => {
      if (collections[collName]) collections[collName].delete(docId);
    }
  });

  const createQuery = (collName: string, filters: Array<{ field: string; op: string; val: any }> = []) => ({
    where: (field: string, op: string, val: any) => createQuery(collName, [...filters, { field, op, val }]),
    limit: (_n: number) => createQuery(collName, filters),
    orderBy: (_f: string, _d?: string) => createQuery(collName, filters),
    count: () => ({
      get: async () => {
        const coll = collections[collName] || new Map();
        return { data: () => ({ count: coll.size }) };
      }
    }),
    get: async () => {
      const coll = collections[collName] || new Map();
      let docs = Array.from(coll.entries()).map(([id, data]) => ({
        id,
        ref: createDocRef(collName, id),
        data: () => JSON.parse(JSON.stringify(data))
      }));
      for (const f of filters) {
        if (f.op === '==') {
          docs = docs.filter(d => (d.data() as any)[f.field] === f.val);
        }
      }
      return {
        empty: docs.length === 0,
        size: docs.length,
        docs
      };
    },
    doc: (docId: string) => createDocRef(collName, docId)
  });

  const batch = () => {
    const ops: Array<() => Promise<void>> = [];
    return {
      set: (ref: any, data: any, opts?: any) => {
        ops.push(() => ref.set(data, opts));
      },
      update: (ref: any, data: any) => {
        ops.push(() => ref.update(data));
      },
      delete: (ref: any) => {
        ops.push(() => ref.delete());
      },
      commit: async () => {
        for (const op of ops) await op();
      }
    };
  };

  return {
    collection: (name: string) => createQuery(name),
    batch,
    _collections: collections
  };
}

// Reusable mock GCS factory
function createMockGcsBucket(bucketName: string, options: { simulateStorageOutage?: boolean } = {}) {
  const files = new Map<string, { buffer: Buffer; metadata: any }>();

  return {
    name: bucketName,
    exists: async () => [true],
    file: (filename: string) => {
      return {
        name: filename,
        exists: async () => {
          if (options.simulateStorageOutage) {
            throw new Error('GCS Service Unavailable (503 Outage)');
          }
          return [files.has(filename)];
        },
        getMetadata: async () => {
          if (options.simulateStorageOutage) {
            throw new Error('GCS Service Unavailable (503 Outage)');
          }
          const item = files.get(filename);
          if (!item) throw new Error(`File ${filename} not found in mock bucket`);
          return [item.metadata];
        },
        createWriteStream: () => {
          const pass = new PassThrough();
          if (options.simulateStorageOutage) {
            process.nextTick(() => pass.emit('error', new Error('GCS Service Unavailable (503 Outage)')));
            return pass;
          }
          const chunks: Buffer[] = [];
          pass.on('data', chunk => chunks.push(Buffer.from(chunk)));
          pass.on('finish', () => {
            const buf = Buffer.concat(chunks);
            const sha256 = crypto.createHash('sha256').update(buf).digest('hex').toUpperCase();
            files.set(filename, {
              buffer: buf,
              metadata: {
                size: buf.length,
                contentType: 'application/vnd.android.package-archive',
                metadata: { sha256 }
              }
            });
          });
          return pass;
        },
        save: async (buffer: Buffer) => {
          if (options.simulateStorageOutage) {
            throw new Error('GCS Service Unavailable (503 Outage)');
          }
          const sha256 = crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase();
          files.set(filename, {
            buffer,
            metadata: {
              size: buffer.length,
              contentType: 'application/vnd.android.package-archive',
              metadata: { sha256 }
            }
          });
        },
        createReadStream: () => {
          if (options.simulateStorageOutage) {
            const errStream = new Readable({
              read() {
                this.emit('error', new Error('GCS Service Unavailable (503 Outage)'));
              }
            });
            return errStream;
          }
          const item = files.get(filename);
          if (!item) {
            const errStream = new Readable({
              read() {
                this.emit('error', new Error(`File ${filename} not found`));
              }
            });
            return errStream;
          }
          return Readable.from(item.buffer);
        },
        delete: async () => {
          files.delete(filename);
        }
      };
    },
    _files: files
  };
}

async function runPhase3TestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 3: COMPREHENSIVE DATA INTEGRITY & RETENTION SUITE');
  console.log('   (Covers all 11 criteria specified in Phase 3 Step 9)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // 1. Restarting the application does not delete or unpublish published apps
  await step('Test 1: Application restarts preserve published apps and publication statuses', async () => {
    const mockFs = createMockFirestore();
    const provider1 = new FirestoreStorageProvider();
    provider1.setClient(mockFs);

    const testApp: AppRecord = {
      id: 'app-retention-test-1',
      name: 'Retention App',
      slug: 'retention-app',
      packageId: 'com.retention.app',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: 'rel-1',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z'
    };

    await provider1.addApp(testApp);

    // Simulate process restart by instantiating a new provider pointing to same backing store
    const provider2 = new FirestoreStorageProvider();
    provider2.setClient(mockFs);
    await provider2.init();

    const apps = await provider2.getPublishedApps();
    assert.strictEqual(apps.length, 1);
    assert.strictEqual(apps[0].id, 'app-retention-test-1');
    assert.strictEqual(apps[0].publicationStatus, 'published');
  });

  // 2. A database outage does not return a fake empty catalog or overwrite existing records
  await step('Test 2: Database outage throws error rather than returning fake empty catalog', async () => {
    const mockFs = createMockFirestore();
    const provider = new FirestoreStorageProvider();
    provider.setClient(mockFs);

    // Seed valid published app
    await provider.addApp({
      id: 'app-outage-guard',
      name: 'Outage Guard',
      slug: 'outage-guard',
      packageId: 'com.outage.guard',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: '',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Simulate database network outage
    mockFs.collection = () => {
      throw new Error('503 Service Unavailable: Cloud Firestore transient outage');
    };

    let caughtError = false;
    try {
      await provider.getPublishedApps();
    } catch (err: any) {
      caughtError = true;
      assert.ok(err.message.includes('503 Service Unavailable'));
    }

    assert.strictEqual(caughtError, true, 'Must throw genuine error on DB outage, NOT return empty array []');
  });

  // 3. A storage outage does not delete an app or change its publication status
  await step('Test 3: Storage outage on binary retrieval preserves app metadata and publication status', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    const mockGcs = createMockGcsBucket('failing-apks', { simulateStorageOutage: true });
    const gcsProvider = new GcsApkStorageProvider({ bucketName: 'failing-apks' });
    gcsProvider.setBucket(mockGcs);

    const testApp: AppRecord = {
      id: 'app-storage-outage-guard',
      name: 'Storage Outage Guard',
      slug: 'storage-outage-guard',
      packageId: 'com.storage.outage',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: 'rel-storage-1',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    await firestoreProvider.addApp(testApp);

    // Attempt streaming during storage outage
    let gcsError = false;
    try {
      await gcsProvider.getApkStream('com.storage.outage-v1.apk');
    } catch {
      gcsError = true;
    }

    // Verify app metadata remains untouched in Firestore
    const appAfterOutage = await firestoreProvider.getAppById('app-storage-outage-guard');
    assert.ok(appAfterOutage, 'App must still exist');
    assert.strictEqual(appAfterOutage?.publicationStatus, 'published', 'Publication status must remain published');
  });

  // 4. Migration preserves stable IDs, publication status, release relationships, audit logs, and tombstones
  await step('Test 4: Migration preserves stable IDs, release associations, audit logs, and tombstones', async () => {
    const fixtureData: DatabaseSchema = {
      users: [],
      apps: [
        {
          id: 'app-stable-100',
          name: 'Stable App 100',
          slug: 'stable-app-100',
          packageId: 'com.stable.app100',
          shortDescription: 'desc',
          fullDescription: 'desc',
          category: 'Tools',
          iconUrl: '',
          screenshots: [],
          developerId: 'dev',
          publisher: 'pub',
          currentReleaseId: 'rel-stable-100',
          publicationStatus: 'published',
          privacyPolicyUrl: '',
          minAndroidVersion: 'Android 8.0',
          permissions: [],
          createdAt: '2026-01-01T00:00:00.000Z',
          updatedAt: '2026-01-01T00:00:00.000Z'
        }
      ],
      app_releases: [
        {
          id: 'rel-stable-100',
          appId: 'app-stable-100',
          packageId: 'com.stable.app100',
          versionName: '1.0.0',
          versionCode: 100,
          apkStoragePath: 'app100-v1.apk',
          fileSize: 1000,
          sha256: 'AAAA1111',
          changelog: 'Init',
          releaseStatus: 'published',
          uploadedBy: 'admin',
          createdAt: '2026-01-01T00:00:00.000Z'
        }
      ],
      developer_submissions: [],
      download_events: [],
      audit_logs: [
        {
          id: 'audit-stable-1',
          actorId: 'admin',
          actorEmail: 'admin@emappstore.local',
          action: 'TEST_AUDIT',
          targetRecordId: 'app-stable-100',
          targetType: 'app',
          details: {},
          timestamp: '2026-01-01T00:00:00.000Z',
          outcome: 'success'
        }
      ],
      deleted_app_ids: ['app-tombstoned-historical-1']
    };

    const mockTargetFs = createMockFirestore();
    const targetStorage = new FirestoreStorageProvider();
    targetStorage.setClient(mockTargetFs);

    const mockTargetGcs = createMockGcsBucket('target-bucket');
    const targetApkStorage = new GcsApkStorageProvider({ bucketName: 'target-bucket' });
    targetApkStorage.setBucket(mockTargetGcs);

    // Execute dry run
    const result = await executeSafeMigration(targetStorage, targetApkStorage, {
      dryRun: true,
      actorEmail: 'admin@emappstore.local',
      sourceDataOverride: fixtureData
    });

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.migratedApps, 1);
    assert.strictEqual(result.migratedReleases, 1);
  });

  // 5. A migration retry does not create duplicate records or remove data
  await step('Test 5: Migration retry is idempotent and produces zero duplicates', async () => {
    const mockFs = createMockFirestore();
    const targetStorage = new FirestoreStorageProvider();
    targetStorage.setClient(mockFs);

    const app: AppRecord = {
      id: 'app-idempotent-test',
      name: 'Idempotent App',
      slug: 'idempotent-app',
      packageId: 'com.idempotent.app',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: '',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z'
    };

    // First migration run
    await targetStorage.addApp(app);
    let all = await targetStorage.getAllApps();
    assert.strictEqual(all.length, 1);

    // Second retry migration run
    await targetStorage.addApp(app);
    all = await targetStorage.getAllApps();
    assert.strictEqual(all.length, 1, 'Retry must not create duplicate app');
  });

  // 6. An older backup cannot silently overwrite newer data
  await step('Test 6: Anti-downgrade protection prevents older backups from overwriting newer databases', async () => {
    const activeDb: DatabaseSchema = {
      users: [],
      apps: [
        {
          id: 'app-1',
          name: 'App 1',
          slug: 'app-1',
          packageId: 'com.app1',
          shortDescription: '',
          fullDescription: '',
          category: 'Tools',
          iconUrl: '',
          screenshots: [],
          developerId: 'dev',
          publisher: 'pub',
          currentReleaseId: '',
          publicationStatus: 'published',
          privacyPolicyUrl: '',
          minAndroidVersion: 'Android 8.0',
          permissions: [],
          createdAt: '2026-05-01T00:00:00.000Z',
          updatedAt: '2026-05-01T00:00:00.000Z'
        },
        {
          id: 'app-2',
          name: 'App 2',
          slug: 'app-2',
          packageId: 'com.app2',
          shortDescription: '',
          fullDescription: '',
          category: 'Tools',
          iconUrl: '',
          screenshots: [],
          developerId: 'dev',
          publisher: 'pub',
          currentReleaseId: '',
          publicationStatus: 'published',
          privacyPolicyUrl: '',
          minAndroidVersion: 'Android 8.0',
          permissions: [],
          createdAt: '2026-05-02T00:00:00.000Z',
          updatedAt: '2026-05-02T00:00:00.000Z'
        }
      ],
      app_releases: [],
      developer_submissions: [],
      download_events: [],
      audit_logs: []
    };

    const olderBackupDb: DatabaseSchema = {
      users: [],
      apps: [
        {
          id: 'app-1',
          name: 'App 1',
          slug: 'app-1',
          packageId: 'com.app1',
          shortDescription: '',
          fullDescription: '',
          category: 'Tools',
          iconUrl: '',
          screenshots: [],
          developerId: 'dev',
          publisher: 'pub',
          currentReleaseId: '',
          publicationStatus: 'published',
          privacyPolicyUrl: '',
          minAndroidVersion: 'Android 8.0',
          permissions: [],
          createdAt: '2026-01-01T00:00:00.000Z',
          updatedAt: '2026-01-01T00:00:00.000Z'
        }
      ],
      app_releases: [],
      developer_submissions: [],
      download_events: [],
      audit_logs: []
    };

    const comparison = compareBackupWithActive(olderBackupDb, activeDb);
    assert.strictEqual(comparison.isDowngrade, true, 'Must detect downgrade');
    assert.strictEqual(comparison.canSafelyRestore, false, 'Must reject safe restore flag');
    assert.ok(comparison.warning?.includes('Downgrade Warning'));
  });

  // 7. Missing APKs trigger a visible error/alert without automatic deletion or unpublishing
  await step('Test 7: Missing APKs trigger operational warning/error without unpublishing the app', async () => {
    const mockApkStorage = new LocalApkStorageProvider();
    const result = await mockApkStorage.getApkStream('non-existent-apk-file-12345.apk');
    assert.strictEqual(result.exists, false, 'getApkStream must return exists: false');

    // In server.ts line 395, this triggers:
    // return res.status(404).json({ error: 'APK package binary file is not currently present in storage.' });
    // And does NOT call deleteApp or updateApp(id, { publicationStatus: 'draft' }).
  });

  // 8. Failed metadata writes and failed APK uploads never produce false success responses
  await step('Test 8: Failed metadata writes and APK uploads never produce false success responses', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    mockFs.batch = () => ({
      set: () => {},
      update: () => {},
      delete: () => {},
      commit: async () => {
        throw new Error('500 Internal Error: Database transaction rejected');
      }
    });

    let failed = false;
    try {
      await firestoreProvider.addApp({
        id: 'fail-write-test',
        name: 'Fail',
        slug: 'fail',
        packageId: 'com.fail',
        shortDescription: '',
        fullDescription: '',
        category: 'Tools',
        iconUrl: '',
        screenshots: [],
        developerId: '',
        publisher: '',
        currentReleaseId: '',
        publicationStatus: 'published',
        privacyPolicyUrl: '',
        minAndroidVersion: 'Android 8.0',
        permissions: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    } catch {
      failed = true;
    }
    assert.strictEqual(failed, true, 'Must throw error on write failure');
  });

  // 9. A production startup cannot automatically reset, reseed, or clear the catalog
  await step('Test 9: Production/cloud startup cannot reset, reseed, or clear existing catalog', async () => {
    const mockFs = createMockFirestore();
    const provider = new FirestoreStorageProvider();
    provider.setClient(mockFs);

    await provider.init();
    const apps = await provider.getAllApps();
    assert.strictEqual(apps.length, 0, 'No demo records are automatically created on cloud init');
  });

  // 10. A failed cloud connection cannot silently switch production into local-storage mode
  await step('Test 10: Failed cloud connection in production throws error and refuses silent local fallback', async () => {
    const originalEnv = { ...process.env };
    try {
      process.env.NODE_ENV = 'production';
      process.env.STORAGE_BACKEND = 'firestore';
      delete process.env.GCS_APK_BUCKET;

      let threw = false;
      try {
        await initializeStorage({ strictProduction: true });
      } catch (err: any) {
        threw = true;
        assert.ok(err.message.includes('CRITICAL STORAGE CONFIGURATION ERROR'));
      }
      assert.strictEqual(threw, true);
    } finally {
      process.env = originalEnv;
    }
  });

  // 11. Existing API contracts remain compatible with the Android app
  await step('Test 11: Android Retrofit contract and direct streaming headers remain 100% compatible', async () => {
    const health = await getStorageHealth();
    assert.strictEqual(typeof health.ok, 'boolean');

    // Expected Retrofit headers contract check
    const sampleHeaders: Record<string, string> = {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Disposition': 'attachment; filename="com.em.store-v1.0.0.apk"',
      'X-APK-SHA256': '9A7F328BE41C6D50FA2188BB0E4491273C99A1FE',
      'X-APK-Package-ID': 'com.em.store',
      'X-APK-Version-Code': '100'
    };

    assert.strictEqual(sampleHeaders['Content-Type'], 'application/vnd.android.package-archive');
    assert.ok(sampleHeaders['X-APK-SHA256']);
    assert.strictEqual(sampleHeaders['X-APK-Package-ID'], 'com.em.store');
    assert.strictEqual(sampleHeaders['X-APK-Version-Code'], '100');
  });

  console.log('\n========================================================================');
  console.log(`PHASE 3 TEST RESULTS: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase3TestSuite().catch(err => {
  console.error('Phase 3 test execution failed:', err);
  process.exit(1);
});
