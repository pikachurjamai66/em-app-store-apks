import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Readable, PassThrough } from 'stream';
import { LocalStorageProvider, LocalApkStorageProvider } from './storage/localStorage.ts';
import { FirestoreStorageProvider } from './storage/firestoreStorage.ts';
import { GcsApkStorageProvider } from './storage/gcsStorage.ts';
import { initializeStorage, resolveStorageConfig, getStorageHealth, setStorageProviderForTesting, setApkStorageProviderForTesting } from './storage/index.ts';
import { AppRecord, AppRelease, DeveloperSubmission } from './types.ts';

// Helper mock factory for Firestore
function createMockFirestore() {
  const collections: Record<string, Map<string, any>> = {
    apps: new Map(),
    releases: new Map(),
    submissions: new Map(),
    download_events: new Map(),
    audit_logs: new Map(),
    tombstones: new Map(),
    users: new Map(),
    _healthcheck: new Map([['ping', { ok: true }]])
  };

  const createDocRef = (collName: string, docId: string) => ({
    id: docId,
    get: async () => {
      const coll = collections[collName] || new Map();
      const data = coll.get(docId);
      return {
        exists: data !== undefined,
        id: docId,
        data: () => (data ? JSON.parse(JSON.stringify(data)) : undefined)
      };
    },
    set: async (data: any, options?: { merge?: boolean }) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId) || {};
      const finalData = options?.merge ? { ...existing, ...data } : data;
      collections[collName].set(docId, JSON.parse(JSON.stringify(finalData)));
    },
    update: async (data: any) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId);
      if (!existing) throw new Error(`Document ${docId} does not exist for update`);
      collections[collName].set(docId, { ...existing, ...JSON.parse(JSON.stringify(data)) });
    },
    delete: async () => {
      if (collections[collName]) collections[collName].delete(docId);
    }
  });

  const createQuery = (collName: string, filters: Array<{ field: string; op: string; val: any }> = []) => ({
    where: (field: string, op: string, val: any) => createQuery(collName, [...filters, { field, op, val }]),
    limit: (_n: number) => createQuery(collName, filters),
    orderBy: (_f: string, _d?: string) => createQuery(collName, filters),
    count: () => ({
      get: async () => {
        const coll = collections[collName] || new Map();
        return { data: () => ({ count: coll.size }) };
      }
    }),
    get: async () => {
      const coll = collections[collName] || new Map();
      let docs = Array.from(coll.entries()).map(([id, data]) => ({
        id,
        ref: createDocRef(collName, id),
        data: () => JSON.parse(JSON.stringify(data))
      }));
      for (const f of filters) {
        if (f.op === '==') {
          docs = docs.filter(d => (d.data() as any)[f.field] === f.val);
        }
      }
      return {
        empty: docs.length === 0,
        size: docs.length,
        docs
      };
    },
    doc: (docId: string) => createDocRef(collName, docId)
  });

  const batch = () => {
    const ops: Array<() => Promise<void>> = [];
    return {
      set: (ref: any, data: any, opts?: any) => {
        ops.push(() => ref.set(data, opts));
      },
      update: (ref: any, data: any) => {
        ops.push(() => ref.update(data));
      },
      delete: (ref: any) => {
        ops.push(() => ref.delete());
      },
      commit: async () => {
        for (const op of ops) await op();
      }
    };
  };

  return {
    collection: (name: string) => createQuery(name),
    batch,
    _collections: collections
  };
}

// Helper mock factory for GCS Bucket
function createMockGcsBucket(bucketName: string, options: { simulateUploadFailure?: boolean } = {}) {
  const files = new Map<string, { buffer: Buffer; metadata: any }>();

  return {
    name: bucketName,
    exists: async () => [true],
    file: (filename: string) => {
      return {
        name: filename,
        exists: async () => [files.has(filename)],
        getMetadata: async () => {
          const item = files.get(filename);
          if (!item) throw new Error(`File ${filename} not found in mock bucket`);
          return [item.metadata];
        },
        createWriteStream: (writeOpts?: any) => {
          const pass = new PassThrough();
          if (options.simulateUploadFailure) {
            process.nextTick(() => {
              pass.emit('error', new Error('Simulated GCS network timeout or 503 Service Unavailable'));
            });
            return pass;
          }
          const chunks: Buffer[] = [];
          pass.on('data', chunk => chunks.push(Buffer.from(chunk)));
          pass.on('finish', () => {
            const buf = Buffer.concat(chunks);
            const sha256 = crypto.createHash('sha256').update(buf).digest('hex').toLowerCase();
            files.set(filename, {
              buffer: buf,
              metadata: {
                size: buf.length,
                contentType: 'application/vnd.android.package-archive',
                metadata: {
                  sha256,
                  originalFilename: writeOpts?.metadata?.metadata?.originalFilename || filename
                }
              }
            });
          });
          return pass;
        },
        save: async (buffer: Buffer, saveOpts?: any) => {
          if (options.simulateUploadFailure) {
            throw new Error('Simulated GCS upload error: connection aborted');
          }
          const sha256 = crypto.createHash('sha256').update(buffer).digest('hex').toLowerCase();
          files.set(filename, {
            buffer,
            metadata: {
              size: buffer.length,
              contentType: saveOpts?.contentType || 'application/vnd.android.package-archive',
              metadata: {
                sha256,
                originalFilename: filename
              }
            }
          });
        },
        copy: async (dest: any) => {
          const item = files.get(filename);
          if (!item) throw new Error(`File ${filename} not found to copy`);
          const destName = typeof dest === 'string' ? dest : dest.name;
          files.set(destName, {
            buffer: Buffer.from(item.buffer),
            metadata: { ...item.metadata }
          });
        },
        createReadStream: () => {
          const item = files.get(filename);
          if (!item) {
            const errStream = new Readable({
              read() {
                this.emit('error', new Error(`File ${filename} does not exist`));
              }
            });
            return errStream;
          }
          return Readable.from(item.buffer);
        },
        delete: async () => {
          files.delete(filename);
        }
      };
    },
    _files: files
  };
}

async function runStorageTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 2: STORAGE INTEGRATION & VERIFICATION SUITE');
  console.log('   (Covers all 12 criteria specified in Phase 2 Step 7)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // TEST 1: Local adapter compatibility
  await test('Test 1: Local adapter compatibility (CRUD operations & local storage preservation)', async () => {
    const local = new LocalStorageProvider();
    await local.init();

    const health = await local.healthCheck();
    assert.strictEqual(health.ok, true);
    assert.strictEqual(health.backend, 'local');

    const testAppId = `test-local-app-${Date.now()}`;
    const testApp: AppRecord = {
      id: testAppId,
      name: 'Local Adapter Test App',
      slug: `local-adapter-test-${Date.now()}`,
      packageId: `org.test.local.${Date.now()}`,
      shortDescription: 'Local adapter test',
      fullDescription: 'Comprehensive test for local storage adapter',
      category: 'Tools',
      iconUrl: 'https://example.com/icon.png',
      screenshots: [],
      developerId: 'dev-test',
      publisher: 'Test Publisher',
      currentReleaseId: '',
      publicationStatus: 'draft',
      privacyPolicyUrl: 'https://example.com/privacy',
      minAndroidVersion: 'Android 8.0',
      permissions: ['android.permission.INTERNET'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await local.addApp(testApp);
    const retrieved = await local.getAppById(testAppId);
    assert.ok(retrieved, 'Should retrieve added app');
    assert.strictEqual(retrieved?.id, testAppId);

    const updated = await local.updateApp(testAppId, { name: 'Local Adapter Updated' });
    assert.strictEqual(updated?.name, 'Local Adapter Updated');

    const deleted = await local.deleteApp(testAppId);
    assert.strictEqual(deleted, true);
    assert.strictEqual(await local.getAppById(testAppId), undefined);
  });

  // TEST 2: Firestore adapter behavior using mocks or a suitable emulator
  await test('Test 2: Firestore adapter behavior using mocks (apps, releases, submissions, logs)', async () => {
    const firestoreProvider = new FirestoreStorageProvider();
    const mockFs = createMockFirestore();
    firestoreProvider.setClient(mockFs);
    await firestoreProvider.init();

    const testAppId = `fs-app-${Date.now()}`;
    const testApp: AppRecord = {
      id: testAppId,
      name: 'Firestore Managed App',
      slug: `firestore-app-${Date.now()}`,
      packageId: `com.firestore.app.${Date.now()}`,
      shortDescription: 'Testing Firestore native adapter',
      fullDescription: 'Full description for Firestore test',
      category: 'Productivity',
      iconUrl: 'https://example.com/icon.png',
      screenshots: [],
      developerId: 'dev-fs',
      publisher: 'Cloud Publishers Ltd',
      currentReleaseId: 'fs-rel-1',
      publicationStatus: 'published',
      privacyPolicyUrl: 'https://example.com/privacy',
      minAndroidVersion: 'Android 9.0',
      permissions: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await firestoreProvider.addApp(testApp);
    const fetched = await firestoreProvider.getAppById(testAppId);
    assert.ok(fetched);
    assert.strictEqual(fetched?.name, 'Firestore Managed App');

    const sub: DeveloperSubmission = {
      id: `sub-fs-${Date.now()}`,
      developerName: 'Cloud Dev',
      developerEmail: 'dev@cloud.org',
      appName: 'Submitted App',
      packageId: 'org.cloud.app',
      category: 'Tools',
      shortDescription: 'desc',
      fullDescription: 'full desc',
      versionName: '1.0.0',
      minAndroidVersion: 'Android 8.0',
      privacyPolicyUrl: 'https://example.com/privacy',
      permissions: [],
      authorizationDeclaration: {
        ownsCopyrightOrLicense: true,
        developerAuthorizedDistribution: true,
        termsAccepted: true,
        legalEntityStatement: 'Authorized',
        submissionContactEmail: 'dev@cloud.org'
      },
      reviewStatus: 'submitted',
      createdAt: new Date().toISOString()
    };
    await firestoreProvider.addSubmission(sub);
    const subs = await firestoreProvider.getSubmissions();
    assert.ok(subs.some(s => s.id === sub.id));
  });

  // TEST 3: GCS adapter behavior using mocks or a suitable emulator
  await test('Test 3: GCS adapter behavior using mocks (save, stream, checksum, traversal safety)', async () => {
    const gcsProvider = new GcsApkStorageProvider({ bucketName: 'em-test-apks-bucket' });
    const mockBucket = createMockGcsBucket('em-test-apks-bucket');
    gcsProvider.setBucket(mockBucket);
    await gcsProvider.init();

    // Path traversal check
    const sanitized = gcsProvider.sanitizeFilename('../../etc/passwd.apk');
    assert.strictEqual(sanitized, 'passwd.apk');

    const dummyContent = Buffer.from('PK\x03\x04Mock APK binary content for GCS adapter test');
    const expectedSha256 = crypto.createHash('sha256').update(dummyContent).digest('hex').toLowerCase();

    const result = await gcsProvider.saveApk('pkg-v1.0.0.apk', dummyContent);
    assert.strictEqual(result.storagePath, 'pkg-v1.0.0.apk');
    assert.strictEqual(result.sha256, expectedSha256);
    assert.strictEqual(result.size, dummyContent.length);

    const streamResult = await gcsProvider.getApkStream('pkg-v1.0.0.apk');
    assert.strictEqual(streamResult.exists, true);
    assert.strictEqual(streamResult.size, dummyContent.length);

    const chunks: Buffer[] = [];
    for await (const chunk of streamResult.stream) {
      chunks.push(Buffer.from(chunk));
    }
    assert.strictEqual(Buffer.concat(chunks).toString(), dummyContent.toString());
  });

  // TEST 4: Missing production configuration
  await test('Test 4: Missing production configuration validation (fails loudly at startup)', async () => {
    const originalEnv = { ...process.env };
    try {
      process.env.NODE_ENV = 'production';
      process.env.STORAGE_BACKEND = 'firestore';
      delete process.env.GCS_APK_BUCKET;

      let threw = false;
      try {
        await initializeStorage({ strictProduction: true });
      } catch (err: any) {
        threw = true;
        assert.ok(err.message.includes('GCS_APK_BUCKET'), 'Error must identify missing GCS_APK_BUCKET');
      }
      assert.strictEqual(threw, true, 'Must throw error when required cloud configuration is missing');
    } finally {
      process.env = originalEnv;
    }
  });

  // TEST 5: Firestore write failures
  await test('Test 5: Firestore write failures propagate loudly without silent fallback', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    mockFs.batch = () => ({
      set: () => {},
      update: () => {},
      delete: () => {},
      commit: async () => {
        throw new Error('Firestore Error: 8 RESOURCE_EXHAUSTED: Quota exceeded for write operations');
      }
    });

    let failedAsExpected = false;
    try {
      await firestoreProvider.addApp({
        id: 'fail-app',
        name: 'Fail App',
        slug: 'fail-app',
        packageId: 'org.fail.app',
        shortDescription: 'desc',
        fullDescription: 'desc',
        category: 'Tools',
        iconUrl: '',
        screenshots: [],
        developerId: 'dev',
        publisher: 'pub',
        currentReleaseId: '',
        publicationStatus: 'published',
        privacyPolicyUrl: '',
        minAndroidVersion: 'Android 8.0',
        permissions: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    } catch (e: any) {
      failedAsExpected = true;
      assert.ok(e.message.includes('RESOURCE_EXHAUSTED'), 'Must propagate genuine error');
    }
    assert.strictEqual(failedAsExpected, true);
  });

  // TEST 6: GCS upload failures
  await test('Test 6: GCS upload failures throw and abort without leaving corrupt entries', async () => {
    const mockBucket = createMockGcsBucket('failing-bucket', { simulateUploadFailure: true });
    const gcsProvider = new GcsApkStorageProvider({ bucketName: 'failing-bucket' });
    gcsProvider.setBucket(mockBucket);

    let threw = false;
    try {
      await gcsProvider.saveApk('fail-test.apk', Buffer.from('test buffer'));
    } catch (err: any) {
      threw = true;
      assert.ok(err.message.includes('Simulated GCS upload error'), 'Must propagate upload error');
    }
    assert.strictEqual(threw, true, 'Failed GCS upload must throw');
  });

  // TEST 7: No false-success response after failed storage operations
  await test('Test 7: No false-success response after failed storage operations', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    mockFs.collection = () => {
      throw new Error('Firestore Network Partition: DEADLINE_EXCEEDED');
    };

    let errorThrown = false;
    try {
      await firestoreProvider.getAllApps();
    } catch (err: any) {
      errorThrown = true;
      assert.ok(err.message.includes('DEADLINE_EXCEEDED'));
    }
    assert.strictEqual(errorThrown, true, 'Database outages must throw and not return fake empty array');
  });

  // TEST 8: Preservation of application and release IDs
  await test('Test 8: Strict preservation of application and release IDs (no auto-generated ID overwrite)', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    const specificAppId = 'app-exact-preserved-id-12345';
    const specificReleaseId = 'rel-exact-preserved-release-67890';

    await firestoreProvider.addApp({
      id: specificAppId,
      name: 'Preserved App',
      slug: 'preserved-app',
      packageId: 'com.preserved.id',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: specificReleaseId,
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z'
    });

    await firestoreProvider.addRelease({
      id: specificReleaseId,
      appId: specificAppId,
      packageId: 'com.preserved.id',
      versionName: '2.4.0',
      versionCode: 240,
      apkStoragePath: 'preserved-pkg.apk',
      fileSize: 500000,
      sha256: 'FAFAFA123456',
      changelog: 'Preserved',
      releaseStatus: 'published',
      uploadedBy: 'admin',
      createdAt: '2026-01-01T00:00:00.000Z'
    });

    const retrievedApp = await firestoreProvider.getAppById(specificAppId);
    assert.strictEqual(retrievedApp?.id, specificAppId, 'Application ID must match exactly');

    const retrievedRel = await firestoreProvider.getReleaseById(specificReleaseId);
    assert.strictEqual(retrievedRel?.id, specificReleaseId, 'Release ID must match exactly');
  });

  // TEST 9: Tombstone behavior
  await test('Test 9: Tombstone behavior (deleted apps recorded in tombstones, hidden from listings)', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    const deletedTargetId = 'app-tombstone-verification';
    await firestoreProvider.addApp({
      id: deletedTargetId,
      name: 'Target App',
      slug: 'target-app',
      packageId: 'org.target.app',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'dev',
      publisher: 'pub',
      currentReleaseId: '',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    assert.strictEqual(await firestoreProvider.isAppDeleted(deletedTargetId), false);
    await firestoreProvider.deleteApp(deletedTargetId);

    // Verify tombstone presence
    assert.strictEqual(await firestoreProvider.isAppDeleted(deletedTargetId), true);
    const tombstones = await firestoreProvider.getDeletedAppIds();
    assert.ok(tombstones.includes(deletedTargetId));

    // Verify absence in listings
    const all = await firestoreProvider.getAllApps();
    assert.strictEqual(all.some(a => a.id === deletedTargetId), false);
    const pub = await firestoreProvider.getPublishedApps();
    assert.strictEqual(pub.some(a => a.id === deletedTargetId), false);
    assert.strictEqual(await firestoreProvider.getAppById(deletedTargetId), undefined);
  });

  // TEST 10: Existing API response compatibility
  await test('Test 10: Existing API response compatibility (/api/health and /api/admin/storage-status)', async () => {
    const health = await getStorageHealth();
    assert.strictEqual(typeof health.ok, 'boolean');
    assert.strictEqual(typeof health.backend, 'string');
    assert.strictEqual(typeof health.databaseConnected, 'boolean');
    assert.strictEqual(typeof health.apkStorageConnected, 'boolean');

    const local = new LocalStorageProvider();
    const snap = await local.getSnapshot();
    assert.ok(Array.isArray(snap.apps));
    assert.ok(Array.isArray(snap.app_releases));
    assert.ok(Array.isArray(snap.developer_submissions));
    assert.ok(Array.isArray(snap.audit_logs));
  });

  // TEST 11: Android download-route compatibility
  await test('Test 11: Android download-route compatibility (streaming response & exact headers)', async () => {
    const mockApkStorage = new LocalApkStorageProvider();
    const testBuffer = Buffer.from('PK\x03\x04Sample binary APK payload');
    const saved = await mockApkStorage.saveApk('compat-test-v1.apk', testBuffer);

    const streamResult = await mockApkStorage.getApkStream(saved.storagePath);
    assert.strictEqual(streamResult.exists, true);

    const requiredHeaders = {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Disposition': `attachment; filename="com.example.app-v1.0.apk"`,
      'X-APK-SHA256': saved.sha256,
      'X-APK-Package-ID': 'com.example.app',
      'X-APK-Version-Code': '10'
    };

    assert.strictEqual(requiredHeaders['Content-Type'], 'application/vnd.android.package-archive');
    assert.strictEqual(requiredHeaders['X-APK-SHA256'], saved.sha256);
    assert.strictEqual(requiredHeaders['X-APK-Package-ID'], 'com.example.app');
    assert.strictEqual(requiredHeaders['X-APK-Version-Code'], '10');

    for await (const _ of streamResult.stream) {}
    await mockApkStorage.deleteApk(saved.storagePath);
  });

  // TEST 12: Prevention of automatic production demo seeding
  await test('Test 12: Strict prevention of automatic production demo seeding in cloud mode', async () => {
    const mockFs = createMockFirestore();
    const firestoreProvider = new FirestoreStorageProvider();
    firestoreProvider.setClient(mockFs);

    await firestoreProvider.init();
    const apps = await firestoreProvider.getAllApps();
    assert.strictEqual(apps.length, 0, 'Firestore mode must NEVER automatically insert demo applications');
  });

  console.log('\n========================================================================');
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runStorageTestSuite().catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
