import assert from 'assert';
import fs from 'fs';
import path from 'path';
import { db, DB_FILE, APK_STORAGE_DIR } from './db.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = 'em-admin-token-secure-init';

async function runLiveVerification() {
  console.log('================================================================');
  console.log('   EM APP STORE PHASE D: LIVE VERIFICATION & AUDIT SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;
  let notRun = 0;

  async function test(name: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${name}... `);
    try {
      await fn();
      console.log('PASS ✓');
      passed++;
    } catch (err: any) {
      console.log('FAIL ✗');
      console.error('    Reason:', err.message);
      failed++;
    }
  }

  function markNotRun(name: string, reason: string) {
    console.log(`• ${name}... NOT RUN [!] (${reason})`);
    notRun++;
  }

  const uniqueSuffix = `audit_${Date.now()}`;
  const testPackageId = `com.audit.test.${uniqueSuffix}`;
  const testAppName = `Audit Test App ${uniqueSuffix}`;
  const testSlug = `audit-test-${Date.now()}`;
  let createdAppId = '';

  // 1. Create a uniquely named temporary test record
  await test('1. Create uniquely named temporary test record', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: testAppName,
        slug: testSlug,
        packageId: testPackageId,
        shortDescription: 'Temporary test app for Phase D live verification',
        fullDescription: 'Will be deleted cleanly after test completion',
        category: 'Utilities',
        publisher: 'Audit Runner',
        publicationStatus: 'draft'
      })
    });

    assert.strictEqual(res.status, 201, `Expected 201 Created, received ${res.status}`);
    const data = await res.json();
    assert.ok(data.app && data.app.id, 'Response must contain app object with ID');
    createdAppId = data.app.id;
    assert.strictEqual(data.app.packageId, testPackageId);
  });

  // 2. Read it back from the authoritative data store
  await test('2. Read test record from authoritative data store', async () => {
    assert.ok(createdAppId, 'createdAppId must be set');
    // Check authoritative memory & disk
    const diskDb = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    const diskRecord = diskDb.apps.find((a: any) => a.id === createdAppId);
    assert.ok(diskRecord, 'Test app must be found in physical db.json');
    assert.strictEqual(diskRecord.packageId, testPackageId);

    // Check via API endpoint
    const apiRes = await fetch(`${BASE_URL}/api/admin/apps`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(apiRes.status, 200);
    const apiData = await apiRes.json();
    const apiRecord = apiData.apps.find((a: any) => a.id === createdAppId);
    assert.ok(apiRecord, 'Test app must be found via GET /api/admin/apps');
    assert.strictEqual(apiRecord.name, testAppName);
  });

  // 3. Refresh the Admin Dashboard and verify record remains visible
  await test('3. Refresh admin apps query and verify record visibility', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    const app = data.apps.find((a: any) => a.id === createdAppId);
    assert.ok(app, 'Test record must remain visible on refresh');
    assert.strictEqual(app.publicationStatus, 'draft');
  });

  // 4. Restart/reload backend database cache and verify persistence
  await test('4. Reload database from disk and verify persistence', async () => {
    // Calling getAllApps forces reloadIfModified() to check mtimeMs against physical disk
    const apps = db.getAllApps();
    const found = apps.find(a => a.id === createdAppId);
    assert.ok(found, 'App must be present in reloaded database');
    assert.strictEqual(found.packageId, testPackageId);
  });

  // 5. Verify record is not duplicated after reload
  await test('5. Verify test record is not duplicated after reload', async () => {
    const apps = db.getAllApps();
    const matches = apps.filter(a => a.packageId === testPackageId);
    assert.strictEqual(matches.length, 1, `Expected exactly 1 match, found ${matches.length}`);
  });

  // 6. Verify deleted demo records are not automatically reinserted
  await test('6. Verify deleted demo records are not automatically reinserted', async () => {
    const demoPkg = `com.demo.temporary.${Date.now()}`;
    const demoId = `app-demo-${Date.now()}`;
    
    // Add demo app
    db.addApp({
      id: demoId,
      name: 'Temp Demo App',
      slug: `temp-demo-${Date.now()}`,
      packageId: demoPkg,
      shortDescription: 'Demo test',
      fullDescription: 'Demo test',
      category: 'Tools',
      iconUrl: 'https://example.com/icon.png',
      screenshots: [],
      developerId: 'admin',
      publisher: 'Demo Publisher',
      currentReleaseId: '',
      publicationStatus: 'draft',
      privacyPolicyUrl: '/privacy',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      isDemonstration: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Delete demo app
    db.deleteApp(demoId, false);

    // Verify tracked in deleted_app_ids
    const diskDb = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    assert.ok(diskDb.deleted_app_ids.includes(demoId), 'Deleted demo app ID must be in deleted_app_ids');

    // Force reload from disk
    const refreshed = db.getAllApps();
    const restored = refreshed.find(a => a.id === demoId || a.packageId === demoPkg);
    assert.strictEqual(restored, undefined, 'Deleted demo app must not be restored');
  });

  // 7. Simulate an API error and verify dashboard displays real error instead of fake data
  await test('7. Simulate API error & verify valid JSON error structure (no fake demo data)', async () => {
    const res = await fetch(`${BASE_URL}/api/apps/non-existent-app-slug-99999`);
    assert.strictEqual(res.status, 404);
    const contentType = res.headers.get('content-type') || '';
    assert.ok(contentType.includes('application/json'), 'Content-Type must be application/json');
    const data = await res.json();
    assert.ok(data.error, 'Must contain error message');
    assert.strictEqual(typeof data.error, 'string');
    assert.ok(!data.error.includes('<!DOCTYPE'), 'Must NOT return HTML doctype string');
  });

  // 8. Verify the actual deployed environment separately from local development tests
  await test('8. Verify deployed environment infrastructure (Cloud Run container environment)', async () => {
    // Check filesystem mount information
    const isOverlayFs = fs.existsSync('/proc/mounts')
      ? fs.readFileSync('/proc/mounts', 'utf-8').includes('none / ') || fs.readFileSync('/proc/mounts', 'utf-8').includes('rootfs')
      : true;

    assert.ok(isOverlayFs, 'Confirmed container runs on overlay / ephemeral filesystem');
    console.log('    [Verified: Cloud Run gVisor container overlay filesystem]');
  });

  // 9. Clean up only the uniquely named test record after tests
  await test('9. Clean up uniquely named test record (preserving all real data)', async () => {
    assert.ok(createdAppId, 'createdAppId must exist to clean up');
    assert.ok(testPackageId.startsWith('com.audit.test.'), 'Sanity check: must be test package');

    const delRes = await fetch(`${BASE_URL}/api/admin/apps/${createdAppId}?deleteFiles=true`, {
      method: 'DELETE',
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(delRes.status, 200, 'Delete must succeed with 200');

    // Confirm it is gone
    const verifyApps = db.getAllApps();
    const stillThere = verifyApps.find(a => a.id === createdAppId);
    assert.strictEqual(stillThere, undefined, 'Test app must be completely deleted');
  });

  // 10. Check if any remote multi-instance sync test can be run
  markNotRun(
    '10. Multi-region cross-instance replication test',
    'Cannot spin up separate Cloud Run instances from within the single sandbox container'
  );

  console.log('\n================================================================');
  console.log(`   AUDIT RESULTS: ${passed} PASS, ${failed} FAIL, ${notRun} NOT RUN`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runLiveVerification().catch(err => {
  console.error('Live verification error:', err);
  process.exit(1);
});
