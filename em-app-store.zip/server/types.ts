export interface User {
  id: string;
  displayName: string;
  email: string;
  role: 'admin' | 'developer' | 'user';
  accountStatus: 'active' | 'suspended';
  createdAt: string;
}

export interface AppRecord {
  id: string;
  name: string;
  slug: string;
  packageId: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  iconUrl: string;
  screenshots: string[];
  developerId: string;
  publisher: string;
  developerContact?: string;
  currentReleaseId: string;
  publicationStatus: 'draft' | 'published' | 'unlisted' | 'archived';
  privacyPolicyUrl: string;
  minAndroidVersion: string;
  targetAndroidVersion?: string;
  permissions: string[];
  isDemonstration?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AppRelease {
  id: string;
  appId: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  apkStoragePath: string;
  apkDownloadUrl?: string;
  fileSize: number; // in bytes
  sha256: string;
  changelog: string;
  releaseStatus: 'draft' | 'pending_review' | 'approved' | 'published' | 'rejected' | 'archived';
  uploadedBy: string;
  signatureCertSha256?: string;
  verificationStatus?: 'verified' | 'suspicious' | 'invalid';
  verificationSummary?: string;
  hasManifest?: boolean;
  entryCount?: number;
  createdAt: string;
  publishedAt?: string;
}

export interface AuthorizationDeclaration {
  ownsCopyrightOrLicense: boolean;
  developerAuthorizedDistribution: boolean;
  termsAccepted: boolean;
  legalEntityStatement: string;
  submissionContactEmail: string;
}

export interface DeveloperSubmission {
  id: string;
  developerName: string;
  developerEmail: string;
  appName: string;
  packageId: string;
  category: string;
  shortDescription: string;
  fullDescription: string;
  versionName: string;
  minAndroidVersion: string;
  privacyPolicyUrl: string;
  permissions: string[];
  authorizationDeclaration: AuthorizationDeclaration;
  apkFileName?: string;
  apkStoragePath?: string;
  apkFileSize?: number;
  apkSha256?: string;
  reviewStatus: 'submitted' | 'under_review' | 'approved' | 'rejected' | 'published' | 'suspended';
  reviewerId?: string;
  reviewNotes?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface DownloadEvent {
  id: string;
  appId: string;
  releaseId: string;
  packageId: string;
  clientType: 'web' | 'android_client' | 'direct_api';
  timestamp: string;
  userAgent?: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorEmail: string;
  action: string;
  targetRecordId: string;
  targetType: 'app' | 'release' | 'submission' | 'user' | 'system';
  details: Record<string, unknown>;
  timestamp: string;
  outcome: 'success' | 'failure';
}

export interface DatabaseSchema {
  users: User[];
  apps: AppRecord[];
  app_releases: AppRelease[];
  developer_submissions: DeveloperSubmission[];
  download_events: DownloadEvent[];
  audit_logs: AuditLog[];
  deleted_app_ids?: string[];
}
