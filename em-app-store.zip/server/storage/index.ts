import dotenv from 'dotenv';
import { IStorageProvider, IApkStorageProvider, StorageBackendType, ApkStorageBackendType, StorageHealthStatus, StorageConfig } from './types.ts';
import { LocalStorageProvider, LocalApkStorageProvider } from './localStorage.ts';
import { FirestoreStorageProvider } from './firestoreStorage.ts';
import { GcsApkStorageProvider } from './gcsStorage.ts';

dotenv.config();

let currentStorageProvider: IStorageProvider | null = null;
let currentApkStorageProvider: IApkStorageProvider | null = null;

export function resolveStorageConfig(): StorageConfig {
  const isProduction = process.env.NODE_ENV === 'production';
  const rawMetaEnv = process.env.METADATA_STORAGE_BACKEND;
  const rawApkEnv = process.env.APK_STORAGE_BACKEND;
  const legacyEnv = process.env.STORAGE_BACKEND;

  // Metadata backend resolution: METADATA_STORAGE_BACKEND takes precedence, falls back to STORAGE_BACKEND
  let backend: StorageBackendType = 'local';
  if (rawMetaEnv && rawMetaEnv.trim().length > 0) {
    backend = rawMetaEnv.trim().toLowerCase() === 'firestore' ? 'firestore' : 'local';
  } else if (legacyEnv && legacyEnv.trim().length > 0) {
    backend = legacyEnv.trim().toLowerCase() === 'firestore' ? 'firestore' : 'local';
  }

  // APK storage backend resolution: APK_STORAGE_BACKEND takes precedence, falls back to STORAGE_BACKEND
  let apkBackend: ApkStorageBackendType = 'local';
  if (rawApkEnv && rawApkEnv.trim().length > 0) {
    apkBackend = rawApkEnv.trim().toLowerCase() === 'gcs' ? 'gcs' : 'local';
  } else if (legacyEnv && legacyEnv.trim().length > 0) {
    apkBackend = legacyEnv.trim().toLowerCase() === 'firestore' ? 'gcs' : 'local';
  } else if (backend === 'firestore') {
    apkBackend = 'gcs';
  }

  const gcpProjectId = process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT;
  const firestoreDatabaseId = process.env.FIRESTORE_DATABASE_ID || '(default)';
  const gcsBucketName = process.env.GCS_APK_BUCKET;

  return {
    isProduction,
    backend,
    apkBackend,
    metadataBackendEnv: rawMetaEnv,
    apkBackendEnv: rawApkEnv,
    gcpProjectId,
    firestoreDatabaseId,
    gcsBucketName
  };
}

export async function initializeStorage(opts: { strictProduction?: boolean } = {}): Promise<{
  storage: IStorageProvider;
  apkStorage: IApkStorageProvider;
}> {
  const config = resolveStorageConfig();
  const strict = opts.strictProduction ?? config.isProduction;

  console.log(`[Storage] Initializing storage foundation... (metadata backend: ${config.backend}, APK backend: ${config.apkBackend}, env: ${config.isProduction ? 'production' : 'development'})`);

  // Upfront configuration validation before establishing network connections
  if (config.apkBackend === 'gcs' && !config.gcsBucketName) {
    const errorMsg = `[FATAL STORAGE CONFIGURATION ERROR] APK_STORAGE_BACKEND is set to 'gcs', but required variable GCS_APK_BUCKET is missing.`;
    console.error(errorMsg);
    if (strict) {
      throw new Error(errorMsg);
    }
  }

  let storageProvider: IStorageProvider;
  let apkStorageProvider: IApkStorageProvider;

  // 1. Initialize Metadata Storage Provider
  if (config.backend === 'firestore') {
    try {
      console.log(`[Storage] Connecting to Cloud Firestore (Database: ${config.firestoreDatabaseId}, Project: ${config.gcpProjectId || 'ADC'})...`);
      const firestoreProvider = new FirestoreStorageProvider({
        projectId: config.gcpProjectId,
        databaseId: config.firestoreDatabaseId
      });
      await firestoreProvider.init();
      storageProvider = firestoreProvider;
      console.log(`[Storage] Cloud Firestore metadata provider connected successfully.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      const fatalMsg = 
        `[FATAL STORAGE ERROR] Cloud Firestore metadata connection failure:\n${msg}\n` +
        `Automatic fallback to ephemeral local storage in production mode is strictly prohibited.`;
      console.error(fatalMsg);
      if (strict) {
        throw new Error(fatalMsg);
      }
      console.warn(`[Storage] Non-strict dev fallback: using LocalStorageProvider for metadata.`);
      const localProvider = new LocalStorageProvider();
      await localProvider.init();
      storageProvider = localProvider;
    }
  } else {
    const localProvider = new LocalStorageProvider();
    await localProvider.init();
    storageProvider = localProvider;
  }

  // 2. Initialize APK Binary Storage Provider
  if (config.apkBackend === 'gcs') {
    if (!config.gcsBucketName) {
      const errorMsg = 
        `[FATAL STORAGE CONFIGURATION ERROR] APK_STORAGE_BACKEND is set to 'gcs', but required variable GCS_APK_BUCKET is missing.`;
      console.error(errorMsg);
      if (strict) {
        throw new Error(errorMsg);
      }
    }
    try {
      console.log(`[Storage] Connecting to Google Cloud Storage bucket '${config.gcsBucketName}'...`);
      const gcsProvider = new GcsApkStorageProvider({
        bucketName: config.gcsBucketName,
        projectId: config.gcpProjectId
      });
      await gcsProvider.init();
      apkStorageProvider = gcsProvider;
      console.log(`[Storage] Google Cloud Storage APK binary provider connected successfully.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      const fatalMsg = 
        `[FATAL STORAGE ERROR] Google Cloud Storage bucket connection failure:\n${msg}\n` +
        `Automatic fallback to ephemeral local APK storage in production mode is strictly prohibited.`;
      console.error(fatalMsg);
      if (strict) {
        throw new Error(fatalMsg);
      }
      console.warn(`[Storage] Non-strict dev fallback: using LocalApkStorageProvider for APK binaries.`);
      const localApkProvider = new LocalApkStorageProvider();
      await localApkProvider.init();
      apkStorageProvider = localApkProvider;
    }
  } else {
    const localApkProvider = new LocalApkStorageProvider();
    await localApkProvider.init();
    apkStorageProvider = localApkProvider;
  }

  currentStorageProvider = storageProvider;
  currentApkStorageProvider = apkStorageProvider;

  console.log(`[Storage] Storage engines active: [Metadata: ${storageProvider.backendType}] [APK: ${apkStorageProvider.backendType}]`);
  return { storage: currentStorageProvider, apkStorage: currentApkStorageProvider };
}

export function getStorageProvider(): IStorageProvider {
  if (!currentStorageProvider) {
    currentStorageProvider = new LocalStorageProvider();
  }
  return currentStorageProvider;
}

export function getApkStorageProvider(): IApkStorageProvider {
  if (!currentApkStorageProvider) {
    currentApkStorageProvider = new LocalApkStorageProvider();
  }
  return currentApkStorageProvider;
}

export function setStorageProviderForTesting(provider: IStorageProvider): void {
  currentStorageProvider = provider;
}

export function setApkStorageProviderForTesting(provider: IApkStorageProvider): void {
  currentApkStorageProvider = provider;
}

export async function getStorageHealth(): Promise<StorageHealthStatus> {
  const storage = getStorageProvider();
  const apkStorage = getApkStorageProvider();

  const dbHealth = await storage.healthCheck();
  const apkHealth = await apkStorage.healthCheck();

  return {
    ok: dbHealth.ok && apkHealth.ok,
    backend: storage.backendType,
    apkBackend: apkStorage.backendType,
    databaseConnected: dbHealth.databaseConnected,
    apkStorageConnected: apkHealth.ok,
    details: {
      ...dbHealth.details,
      apkBucket: apkHealth.bucketName
    },
    error: dbHealth.error || apkHealth.error
  };
}
