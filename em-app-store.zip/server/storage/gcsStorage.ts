import { Storage, Bucket, File } from '@google-cloud/storage';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { IApkStorageProvider, ApkStorageBackendType, ApkStreamResult } from './types.ts';

export interface GcsConfig {
  bucketName?: string;
  projectId?: string;
  keyFilename?: string;
}

export class GcsApkStorageProvider implements IApkStorageProvider {
  public readonly backendType: ApkStorageBackendType = 'gcs';
  private storage: Storage | null = null;
  private bucket: Bucket | null = null;
  private readonly config: GcsConfig;
  private initialized = false;

  constructor(config: GcsConfig = {}) {
    this.config = {
      bucketName: config.bucketName || process.env.GCS_APK_BUCKET,
      projectId: config.projectId || process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT,
      keyFilename: config.keyFilename || process.env.GOOGLE_APPLICATION_CREDENTIALS
    };
  }

  // Allow injecting custom/mock Bucket for testing
  public setBucket(bucket: any): void {
    this.bucket = bucket;
    this.initialized = true;
  }

  private getBucket(): Bucket {
    if (this.bucket) return this.bucket;

    if (!this.config.bucketName) {
      throw new Error(
        'GCS_APK_BUCKET environment variable is not defined. Google Cloud Storage bucket name is required for durable APK binary storage.'
      );
    }

    if (!this.storage) {
      const options: Record<string, any> = {};
      if (this.config.projectId) options.projectId = this.config.projectId;
      if (this.config.keyFilename) options.keyFilename = this.config.keyFilename;
      this.storage = new Storage(options);
    }

    this.bucket = this.storage.bucket(this.config.bucketName);
    return this.bucket;
  }

  public async init(): Promise<void> {
    if (!this.config.bucketName) {
      throw new Error(
        'GCS configuration incomplete: GCS_APK_BUCKET is required for GcsApkStorageProvider.'
      );
    }

    const bucket = this.getBucket();
    try {
      const [exists] = await bucket.exists();
      if (!exists) {
        throw new Error(`Google Cloud Storage bucket '${this.config.bucketName}' does not exist.`);
      }
      this.initialized = true;
    } catch (err: unknown) {
      this.initialized = false;
      const message = err instanceof Error ? err.message : String(err);
      throw new Error(`Failed to access Google Cloud Storage bucket '${this.config.bucketName}': ${message}`);
    }
  }

  public async healthCheck(): Promise<{ ok: boolean; bucketName?: string; error?: string }> {
    try {
      if (!this.config.bucketName) {
        return { ok: false, error: 'GCS_APK_BUCKET environment variable not set' };
      }
      const bucket = this.getBucket();
      const [exists] = await bucket.exists();
      return { ok: exists, bucketName: this.config.bucketName };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return { ok: false, bucketName: this.config.bucketName, error: msg };
    }
  }

  public sanitizeFilename(filename: string): string {
    const base = path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, '_');
    if (!base.endsWith('.apk')) {
      return `${base}.apk`;
    }
    return base;
  }

  public getResolvedPath(storagePath: string): string {
    const safe = this.sanitizeFilename(storagePath);
    return `gs://${this.config.bucketName || 'unknown-bucket'}/${safe}`;
  }

  public async saveApk(
    destinationFilename: string,
    sourceFilePathOrBuffer: string | Buffer
  ): Promise<{ storagePath: string; size: number; sha256: string }> {
    const safeFilename = this.sanitizeFilename(destinationFilename);
    const bucket = this.getBucket();

    // 1. Calculate lowercase hex SHA-256 and size upfront
    let sha256 = '';
    let size = 0;
    let inputBuffer: Buffer | null = null;

    if (Buffer.isBuffer(sourceFilePathOrBuffer)) {
      inputBuffer = sourceFilePathOrBuffer;
      size = inputBuffer.length;
      sha256 = crypto.createHash('sha256').update(inputBuffer).digest('hex').toLowerCase();
    } else {
      if (!fs.existsSync(sourceFilePathOrBuffer)) {
        throw new Error(`Source APK file not found at: ${sourceFilePathOrBuffer}`);
      }
      const stat = fs.statSync(sourceFilePathOrBuffer);
      size = stat.size;
      const hash = crypto.createHash('sha256');
      const stream = fs.createReadStream(sourceFilePathOrBuffer);
      await new Promise<void>((resolve, reject) => {
        stream.on('data', chunk => hash.update(chunk));
        stream.on('end', resolve);
        stream.on('error', reject);
      });
      sha256 = hash.digest('hex').toLowerCase();
    }

    // 2. Upload to temporary staging prefix first to prevent exposing partial or corrupted uploads
    const stagingToken = `staging-${Date.now()}-${crypto.randomBytes(6).toString('hex')}.tmp.apk`;
    const stagingFile = bucket.file(`staging/${stagingToken}`);

    try {
      if (inputBuffer) {
        await stagingFile.save(inputBuffer, {
          contentType: 'application/vnd.android.package-archive',
          metadata: {
            contentType: 'application/vnd.android.package-archive',
            metadata: {
              sha256,
              originalFilename: destinationFilename
            }
          },
          resumable: false
        });
      } else {
        await new Promise<void>((resolve, reject) => {
          const readStream = fs.createReadStream(sourceFilePathOrBuffer as string);
          const writeStream = stagingFile.createWriteStream({
            contentType: 'application/vnd.android.package-archive',
            metadata: {
              metadata: {
                sha256,
                originalFilename: destinationFilename
              }
            },
            resumable: true
          });
          readStream.on('error', reject);
          writeStream.on('error', reject);
          writeStream.on('finish', resolve);
          readStream.pipe(writeStream);
        });
      }

      // 3. Confirm staging object exists
      const [stagingExists] = await stagingFile.exists();
      if (!stagingExists) {
        throw new Error(`Staging upload to GCS failed: object staging/${stagingToken} was not created.`);
      }

      // 4. Promote verified staging object to canonical destination object
      const canonicalFile = bucket.file(safeFilename);
      await stagingFile.copy(canonicalFile);

      // Verify canonical file exists
      const [canonicalExists] = await canonicalFile.exists();
      if (!canonicalExists) {
        throw new Error(`Failed to copy staging object to canonical path: ${safeFilename}`);
      }

      // 5. Clean up staging object
      try {
        await stagingFile.delete();
      } catch {
        // Non-blocking staging cleanup
      }

      return {
        storagePath: safeFilename,
        size,
        sha256
      };
    } catch (err) {
      // Attempt to clean up staging file on error
      try {
        await stagingFile.delete();
      } catch {}
      throw err;
    }
  }

  public async getApkStream(storagePath: string): Promise<ApkStreamResult> {
    if (!storagePath || !storagePath.trim()) {
      return {
        stream: null as any,
        size: 0,
        exists: false
      };
    }
    const safeFilename = this.sanitizeFilename(storagePath);
    const bucket = this.getBucket();
    const gcsFile = bucket.file(safeFilename);

    try {
      const [exists] = await gcsFile.exists();
      if (!exists) {
        return {
          stream: null as any,
          size: 0,
          exists: false
        };
      }

      const [metadata] = await gcsFile.getMetadata();
      const size = typeof metadata.size === 'string' ? parseInt(metadata.size, 10) : Number(metadata.size || 0);
      const rawSha = metadata.metadata?.sha256;
      const sha256 = typeof rawSha === 'string' ? rawSha.toLowerCase() : undefined;

      const stream = gcsFile.createReadStream();
      return {
        stream,
        size,
        sha256,
        exists: true
      };
    } catch (err) {
      console.error(`Error retrieving GCS APK stream for ${safeFilename}:`, err);
      return {
        stream: null as any,
        size: 0,
        exists: false
      };
    }
  }

  public async apkExists(storagePath: string): Promise<boolean> {
    if (!storagePath || !storagePath.trim()) return false;
    try {
      const safeFilename = this.sanitizeFilename(storagePath);
      const bucket = this.getBucket();
      const [exists] = await bucket.file(safeFilename).exists();
      return exists;
    } catch {
      return false;
    }
  }

  public async deleteApk(storagePath: string): Promise<boolean> {
    try {
      const safeFilename = this.sanitizeFilename(storagePath);
      const bucket = this.getBucket();
      const file = bucket.file(safeFilename);
      const [exists] = await file.exists();
      if (!exists) return false;
      await file.delete();
      return true;
    } catch (e) {
      console.error(`Failed to delete GCS APK ${storagePath}:`, e);
      return false;
    }
  }
}
