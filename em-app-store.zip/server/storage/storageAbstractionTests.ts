import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Readable, PassThrough } from 'stream';
import { LocalStorageProvider, LocalApkStorageProvider } from './localStorage.ts';
import { FirestoreStorageProvider } from './firestoreStorage.ts';
import { GcsApkStorageProvider } from './gcsStorage.ts';
import {
  initializeStorage,
  resolveStorageConfig,
  getStorageHealth,
  setStorageProviderForTesting,
  setApkStorageProviderForTesting
} from './index.ts';
import { AppRecord, AppRelease, DeveloperSubmission } from '../types.ts';

// ---------------------------------------------------------------------------
// Mock Firestore Factory
// ---------------------------------------------------------------------------
function createMockFirestore() {
  const collections: Record<string, Map<string, any>> = {
    apps: new Map(),
    releases: new Map(),
    submissions: new Map(),
    download_events: new Map(),
    audit_logs: new Map(),
    tombstones: new Map(),
    users: new Map(),
    _healthcheck: new Map([['ping', { ok: true }]])
  };

  const createDocRef = (collName: string, docId: string) => ({
    id: docId,
    get: async () => {
      const coll = collections[collName] || new Map();
      const data = coll.get(docId);
      return {
        exists: data !== undefined,
        id: docId,
        data: () => (data ? JSON.parse(JSON.stringify(data)) : undefined)
      };
    },
    set: async (data: any, options?: { merge?: boolean }) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId) || {};
      const finalData = options?.merge ? { ...existing, ...data } : data;
      collections[collName].set(docId, JSON.parse(JSON.stringify(finalData)));
    },
    update: async (data: any) => {
      if (!collections[collName]) collections[collName] = new Map();
      const existing = collections[collName].get(docId);
      if (!existing) throw new Error(`Document ${docId} does not exist for update`);
      collections[collName].set(docId, { ...existing, ...JSON.parse(JSON.stringify(data)) });
    },
    delete: async () => {
      if (collections[collName]) collections[collName].delete(docId);
    }
  });

  const createQuery = (collName: string, filters: Array<{ field: string; op: string; val: any }> = []) => ({
    where: (field: string, op: string, val: any) => createQuery(collName, [...filters, { field, op, val }]),
    limit: (_n: number) => createQuery(collName, filters),
    orderBy: (_f: string, _d?: string) => createQuery(collName, filters),
    count: () => ({
      get: async () => {
        const coll = collections[collName] || new Map();
        return { data: () => ({ count: coll.size }) };
      }
    }),
    get: async () => {
      const coll = collections[collName] || new Map();
      let docs = Array.from(coll.entries()).map(([id, data]) => ({
        id,
        ref: createDocRef(collName, id),
        data: () => JSON.parse(JSON.stringify(data))
      }));
      for (const f of filters) {
        if (f.op === '==') {
          docs = docs.filter(d => (d.data() as any)[f.field] === f.val);
        }
      }
      return {
        empty: docs.length === 0,
        size: docs.length,
        docs
      };
    },
    doc: (docId: string) => createDocRef(collName, docId)
  });

  const batch = () => {
    const ops: Array<() => Promise<void>> = [];
    return {
      set: (ref: any, data: any, opts?: any) => {
        ops.push(() => ref.set(data, opts));
      },
      update: (ref: any, data: any) => {
        ops.push(() => ref.update(data));
      },
      delete: (ref: any) => {
        ops.push(() => ref.delete());
      },
      commit: async () => {
        for (const op of ops) await op();
      }
    };
  };

  return {
    collection: (collName: string) => createQuery(collName),
    batch,
    runTransaction: async (updateFunction: (t: any) => Promise<any>) => {
      const transaction = {
        get: async (ref: any) => ref.get(),
        set: (ref: any, data: any, opts?: any) => ref.set(data, opts),
        update: (ref: any, data: any) => ref.update(data),
        delete: (ref: any) => ref.delete()
      };
      return await updateFunction(transaction);
    },
    _collections: collections
  };
}

// ---------------------------------------------------------------------------
// Mock GCS Bucket Factory
// ---------------------------------------------------------------------------
function createMockGcsBucket(bucketName: string, options: { simulateUploadFailure?: boolean } = {}) {
  const files = new Map<string, { buffer: Buffer; metadata: any }>();

  return {
    name: bucketName,
    exists: async () => [true],
    file: (filename: string) => {
      return {
        name: filename,
        exists: async () => [files.has(filename)],
        getMetadata: async () => {
          const item = files.get(filename);
          if (!item) throw new Error(`File ${filename} not found in mock bucket`);
          return [item.metadata];
        },
        createWriteStream: (writeOpts?: any) => {
          const pass = new PassThrough();
          if (options.simulateUploadFailure) {
            process.nextTick(() => {
              pass.emit('error', new Error('Simulated GCS network timeout or 503 Service Unavailable'));
            });
            return pass;
          }
          const chunks: Buffer[] = [];
          pass.on('data', chunk => chunks.push(Buffer.from(chunk)));
          pass.on('finish', () => {
            const buf = Buffer.concat(chunks);
            const sha256 = crypto.createHash('sha256').update(buf).digest('hex').toLowerCase();
            files.set(filename, {
              buffer: buf,
              metadata: {
                size: buf.length,
                contentType: 'application/vnd.android.package-archive',
                metadata: {
                  sha256,
                  originalFilename: writeOpts?.metadata?.metadata?.originalFilename || filename
                }
              }
            });
          });
          return pass;
        },
        save: async (buffer: Buffer, saveOpts?: any) => {
          if (options.simulateUploadFailure) {
            throw new Error('Simulated GCS upload error: connection aborted');
          }
          const sha256 = crypto.createHash('sha256').update(buffer).digest('hex').toLowerCase();
          files.set(filename, {
            buffer,
            metadata: {
              size: buffer.length,
              contentType: saveOpts?.contentType || 'application/vnd.android.package-archive',
              metadata: {
                sha256,
                originalFilename: filename
              }
            }
          });
        },
        copy: async (dest: any) => {
          const item = files.get(filename);
          if (!item) throw new Error(`File ${filename} not found to copy`);
          const destName = typeof dest === 'string' ? dest : dest.name;
          files.set(destName, {
            buffer: Buffer.from(item.buffer),
            metadata: { ...item.metadata }
          });
        },
        createReadStream: () => {
          const item = files.get(filename);
          if (!item) {
            const errStream = new Readable({
              read() {
                this.emit('error', new Error(`File ${filename} does not exist`));
              }
            });
            return errStream;
          }
          return Readable.from(item.buffer);
        },
        delete: async () => {
          files.delete(filename);
        }
      };
    },
    _files: files
  };
}

// ---------------------------------------------------------------------------
// Test Runner
// ---------------------------------------------------------------------------
async function runStorageAbstractionTests() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 10B-1: STORAGE ABSTRACTION & INTEGRATION SUITE');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${name}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error(`    Error: ${err.message}`);
      if (err.stack) console.error(`    Trace: ${err.stack.split('\n').slice(1, 4).join('\n')}`);
      failed++;
    }
  }

  // 1. Local JSON adapter compliance
  await test('1. LocalStorageProvider: full CRUD and interface compliance', async () => {
    const local = new LocalStorageProvider();
    await local.init();
    assert.strictEqual(local.backendType, 'local');

    const apps = await local.getAllApps();
    assert.ok(apps.length > 0, 'Local adapter must return baseline applications');

    // Case-insensitive package query
    const sample = apps[0];
    const byPkg = await local.getAppByPackageId(sample.packageId.toUpperCase());
    assert.ok(byPkg, 'getAppByPackageId must be case-insensitive');
    assert.strictEqual(byPkg?.id, sample.id);

    // Snapshot integrity
    const snap = await local.getSnapshot();
    assert.ok(Array.isArray(snap.apps));
    assert.ok(Array.isArray(snap.app_releases));
    assert.ok(Array.isArray(snap.developer_submissions));
    assert.ok(Array.isArray(snap.audit_logs));
  });

  // 2. Firestore adapter CRUD & queries using mock
  await test('2. FirestoreStorageProvider: CRUD, case-insensitive index, and submission deletion', async () => {
    const mockFs = createMockFirestore();
    const firestore = new FirestoreStorageProvider();
    firestore.setClient(mockFs);
    await firestore.init();
    assert.strictEqual(firestore.backendType, 'firestore');

    const testApp: AppRecord = {
      id: 'app-fs-test-1',
      name: 'Firestore Test App',
      slug: 'firestore-test-app',
      packageId: 'org.firestore.test',
      shortDescription: 'Short desc',
      fullDescription: 'Full desc',
      category: 'Productivity',
      iconUrl: 'https://example.com/icon.png',
      screenshots: [],
      developerId: 'dev@test.org',
      publisher: 'Test Publisher',
      currentReleaseId: 'rel-fs-test-1',
      publicationStatus: 'published',
      privacyPolicyUrl: 'https://example.com/privacy',
      minAndroidVersion: 'Android 8.0',
      permissions: ['INTERNET'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const testRel: AppRelease = {
      id: 'rel-fs-test-1',
      appId: 'app-fs-test-1',
      packageId: 'org.firestore.test',
      versionName: '1.0.0',
      versionCode: 1,
      apkStoragePath: 'org.firestore.test-1.apk',
      fileSize: 1048576,
      sha256: 'a1b2c3d4e5f600112233445566778899aabbccddeeff00112233445566778899',
      changelog: 'Initial release',
      releaseStatus: 'published',
      uploadedBy: 'dev@test.org',
      createdAt: new Date().toISOString()
    };

    // Atomic publish
    await firestore.publishAppWithRelease(testApp, testRel);

    const foundByPkg = await firestore.getAppByPackageId('ORG.FIRESTORE.TEST');
    assert.ok(foundByPkg, 'Firestore getAppByPackageId must match case-insensitively');
    assert.strictEqual(foundByPkg?.id, testApp.id);

    const foundRel = await firestore.getReleaseById(testRel.id);
    assert.strictEqual(foundRel?.sha256, testRel.sha256);

    // Developer submission CRUD and deletion
    const sub: DeveloperSubmission = {
      id: 'sub-test-fs',
      developerName: 'Sub Dev',
      developerEmail: 'dev@example.com',
      appName: 'Sub App',
      packageId: 'com.sub.app',
      category: 'Tools',
      shortDescription: 'short',
      fullDescription: 'full description',
      privacyPolicyUrl: 'https://example.com/privacy',
      versionName: '1.0.0',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      authorizationDeclaration: {
        ownsCopyrightOrLicense: true,
        developerAuthorizedDistribution: true,
        termsAccepted: true,
        legalEntityStatement: 'Sub Dev Inc',
        submissionContactEmail: 'dev@example.com'
      },
      reviewStatus: 'submitted',
      createdAt: new Date().toISOString()
    };

    await firestore.addSubmission(sub);
    const subsBefore = await firestore.getSubmissions();
    assert.ok(subsBefore.some(s => s.id === sub.id));

    const deleted = await firestore.deleteSubmission(sub.id);
    assert.strictEqual(deleted, true);
    const subsAfter = await firestore.getSubmissions();
    assert.strictEqual(subsAfter.some(s => s.id === sub.id), false);
  });

  // 3. GCS two-stage staging upload and lowercase sha256
  await test('3. GcsApkStorageProvider: two-stage staging upload and lowercase SHA-256', async () => {
    const mockBucket = createMockGcsBucket('test-apk-bucket');
    const gcs = new GcsApkStorageProvider({ bucketName: 'test-apk-bucket' });
    gcs.setBucket(mockBucket);
    await gcs.init();

    const sampleContent = Buffer.from('PK\x03\x04APK binary stream content');
    const expectedSha256 = crypto.createHash('sha256').update(sampleContent).digest('hex').toLowerCase();

    const saved = await gcs.saveApk('sample-v1.apk', sampleContent);
    assert.strictEqual(saved.storagePath, 'sample-v1.apk');
    assert.strictEqual(saved.sha256, expectedSha256);
    assert.strictEqual(saved.sha256, saved.sha256.toLowerCase(), 'SHA-256 must strictly be lowercase');

    // Staging file should be cleaned up
    assert.strictEqual(mockBucket._files.has(`staging/tmp-sample-v1.apk`), false);

    // File exists in canonical location
    assert.strictEqual(await gcs.apkExists('sample-v1.apk'), true);

    // Stream verification
    const streamRes = await gcs.getApkStream('sample-v1.apk');
    assert.strictEqual(streamRes.exists, true);
    assert.strictEqual(streamRes.sha256, expectedSha256);
    const chunks: Buffer[] = [];
    for await (const chunk of streamRes.stream) {
      chunks.push(Buffer.from(chunk));
    }
    assert.strictEqual(Buffer.concat(chunks).toString(), sampleContent.toString());
  });

  // 4. Audit-log credential sanitization
  await test('4. FirestoreStorageProvider: credential sanitization in audit logs', async () => {
    const mockFs = createMockFirestore();
    const firestore = new FirestoreStorageProvider();
    firestore.setClient(mockFs);
    await firestore.init();

    await firestore.addAuditLog('admin', 'admin@example.com', 'TEST_EVENT', 'entity-1', 'system', {
      userToken: 'secret-token-12345',
      access_key: 'super-secret-key-abcdef',
      apiKey: 'AIzaSyTestApiKeySecret',
      normalField: 'visible_data'
    });

    const logs = await firestore.getAuditLogs(10);
    assert.ok(logs.length > 0);
    const latest = logs[0];
    assert.strictEqual(latest.details.userToken, '[REDACTED]');
    assert.strictEqual(latest.details.access_key, '[REDACTED]');
    assert.strictEqual(latest.details.apiKey, '[REDACTED]');
    assert.strictEqual(latest.details.normalField, 'visible_data');
  });

  // 5. Tombstone protection
  await test('5. Tombstone protection prevents resurrection of deleted apps', async () => {
    const mockFs = createMockFirestore();
    const firestore = new FirestoreStorageProvider();
    firestore.setClient(mockFs);
    await firestore.init();

    const appId = 'app-deleted-permanently';
    await firestore.addApp({
      id: appId,
      name: 'To Delete',
      slug: 'to-delete',
      packageId: 'com.to.delete',
      shortDescription: 'desc',
      fullDescription: 'desc',
      category: 'Tools',
      iconUrl: '',
      screenshots: [],
      developerId: 'admin',
      publisher: 'Admin',
      currentReleaseId: '',
      publicationStatus: 'published',
      privacyPolicyUrl: '',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    assert.strictEqual(await firestore.isAppDeleted(appId), false);
    await firestore.deleteApp(appId);
    assert.strictEqual(await firestore.isAppDeleted(appId), true);

    const published = await firestore.getPublishedApps();
    assert.strictEqual(published.some(a => a.id === appId), false);

    const all = await firestore.getAllApps();
    assert.strictEqual(all.some(a => a.id === appId), false);
  });

  // 6. No silent fallback in production
  await test('6. Strict production safety: fails loudly when GCS bucket missing in production', async () => {
    const origEnv = { ...process.env };
    try {
      process.env.NODE_ENV = 'production';
      process.env.APK_STORAGE_BACKEND = 'gcs';
      delete process.env.GCS_APK_BUCKET;

      let threw = false;
      try {
        await initializeStorage({ strictProduction: true });
      } catch (err: any) {
        threw = true;
        assert.ok(err.message.includes('GCS_APK_BUCKET'));
      }
      assert.strictEqual(threw, true, 'Must fail loudly without silent fallback');
    } finally {
      process.env = origEnv;
    }
  });

  // 7. No automatic demo seeding
  await test('7. Cloud Firestore initialization never seeds demo apps', async () => {
    const mockFs = createMockFirestore();
    const firestore = new FirestoreStorageProvider();
    firestore.setClient(mockFs);
    await firestore.init();

    const apps = await firestore.getAllApps();
    assert.strictEqual(apps.length, 0, 'Clean cloud initialization must be empty of mock/demo apps');
  });

  // 8. Missing APK handling without metadata unpublishing
  await test('8. Missing APK handling: app remains published, download returns graceful error', async () => {
    const local = new LocalStorageProvider();
    await local.init();

    const published = await local.getPublishedApps();
    assert.ok(published.length > 0);

    const testApp = published[0];
    const rel = await local.getReleaseById(testApp.currentReleaseId);
    assert.ok(rel);

    // Verify non-existent APK check
    const localApk = new LocalApkStorageProvider();
    const exists = await localApk.apkExists('non-existent-ghost-file.apk');
    assert.strictEqual(exists, false);

    // App status must remain published in database
    const appStillThere = await local.getAppById(testApp.id);
    assert.strictEqual(appStillThere?.publicationStatus, 'published');
  });

  // 9. Android Retrofit contract verification
  await test('9. Android Retrofit contract verification (headers and MIME type)', async () => {
    const localApk = new LocalApkStorageProvider();
    const testContent = Buffer.from('PK\x03\x04Retrofit download validation');
    const saved = await localApk.saveApk('retrofit-contract-test.apk', testContent);

    const streamInfo = await localApk.getApkStream(saved.storagePath);
    assert.strictEqual(streamInfo.exists, true);

    const contractHeaders = {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Disposition': 'attachment; filename="test.apk"',
      'X-APK-SHA256': saved.sha256.toLowerCase(),
      'X-APK-Package-ID': 'com.em.store',
      'X-APK-Version-Code': '1'
    };

    assert.strictEqual(contractHeaders['Content-Type'], 'application/vnd.android.package-archive');
    assert.strictEqual(contractHeaders['X-APK-SHA256'], saved.sha256);
    assert.match(contractHeaders['X-APK-SHA256'], /^[0-9a-f]{64}$/);

    for await (const _ of streamInfo.stream) {}
    await localApk.deleteApk(saved.storagePath);
  });

  // 10. Baseline data preservation & Soul Connect exclusion
  await test('10. Baseline preservation & Soul Connect exclusion check', async () => {
    const dbPath = path.resolve(process.cwd(), 'data', 'db.json');
    assert.ok(fs.existsSync(dbPath), 'data/db.json must exist');
    const dbContent = fs.readFileSync(dbPath, 'utf8');

    const parsed = JSON.parse(dbContent);
    assert.strictEqual(parsed.apps.length, 14, 'Must have exactly 14 applications');
    assert.strictEqual(parsed.app_releases.length, 28, 'Must have exactly 28 releases');
    assert.strictEqual(parsed.developer_submissions.length, 2, 'Must have exactly 2 submissions');

    const publishedApps = parsed.apps.filter((a: any) => a.publicationStatus === 'published');
    assert.strictEqual(publishedApps.length, 4, 'Must have exactly 4 published applications');
    const publishedNames = publishedApps.map((a: any) => a.name).sort();
    assert.deepStrictEqual(
      publishedNames,
      ['EM Store Client', 'Orbit Lightweight Browser', 'Pulse Hi-Res Audio Player', 'Zenith Markdown Notes'].sort(),
      'Authoritative published apps must match baseline exactly'
    );

    // Verify 0 occurrences of Soul Connect
    const scOccurrences = (dbContent.match(/soul[-_ ]?connect/gi) || []).length;
    assert.strictEqual(scOccurrences, 0, 'Soul Connect must never exist in database');

    const apksDir = path.resolve(process.cwd(), 'data', 'apks');
    const apkFiles = fs.readdirSync(apksDir).filter(f => f.endsWith('.apk'));
    assert.strictEqual(apkFiles.length, 38, 'Baseline APK files count must remain exactly 38');
    for (const f of apkFiles) {
      assert.strictEqual(/soul/i.test(f), false, `APK ${f} must not be named Soul Connect`);
    }
  });

  console.log('\n========================================================================');
  console.log(`ALL TESTS COMPLETED: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runStorageAbstractionTests().catch(err => {
  console.error('Test suite failed:', err);
  process.exit(1);
});
