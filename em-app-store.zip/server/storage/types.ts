import { DatabaseSchema, AppRecord, AppRelease, DeveloperSubmission, DownloadEvent, AuditLog, User } from '../types.ts';

export type StorageBackendType = 'local' | 'firestore';
export type ApkStorageBackendType = 'local' | 'gcs';

export interface StorageConfig {
  backend: StorageBackendType;
  apkBackend: ApkStorageBackendType;
  metadataBackendEnv?: string;
  apkBackendEnv?: string;
  gcpProjectId?: string;
  firestoreDatabaseId?: string;
  gcsBucketName?: string;
  isProduction: boolean;
}

export interface StorageHealthStatus {
  ok: boolean;
  backend: StorageBackendType;
  apkBackend: ApkStorageBackendType;
  databaseConnected: boolean;
  apkStorageConnected: boolean;
  details?: Record<string, unknown>;
  error?: string;
}

export interface IStorageProvider {
  readonly backendType: StorageBackendType;

  init(): Promise<void>;
  healthCheck(): Promise<StorageHealthStatus>;

  // Applications
  getAllApps(): Promise<AppRecord[]>;
  getPublishedApps(): Promise<AppRecord[]>;
  getAppById(id: string): Promise<AppRecord | undefined>;
  getAppByIdOrSlug(idOrSlug: string): Promise<AppRecord | undefined>;
  getAppByPackageId(packageId: string): Promise<AppRecord | undefined>;
  addApp(app: AppRecord): Promise<void>;
  updateApp(id: string, updates: Partial<AppRecord>): Promise<AppRecord | undefined>;
  deleteApp(id: string, deleteApkFiles?: boolean): Promise<boolean>;
  publishAppWithRelease(app: AppRecord, release?: AppRelease): Promise<{ app: AppRecord; release?: AppRelease }>;

  // Tombstones & Deletion state
  isAppDeleted(appId: string): Promise<boolean>;
  getDeletedAppIds(): Promise<string[]>;

  // Releases
  getReleasesForApp(appId: string): Promise<AppRelease[]>;
  getReleaseById(id: string): Promise<AppRelease | undefined>;
  addRelease(release: AppRelease): Promise<void>;
  updateRelease(id: string, updates: Partial<AppRelease>): Promise<AppRelease | undefined>;
  deleteRelease(id: string, deleteApkFile?: boolean): Promise<boolean>;
  setAppCurrentRelease(appId: string, releaseId: string): Promise<void>;

  // Submissions
  getSubmissions(): Promise<DeveloperSubmission[]>;
  getSubmissionById(id: string): Promise<DeveloperSubmission | undefined>;
  addSubmission(submission: DeveloperSubmission): Promise<void>;
  updateSubmission(id: string, updates: Partial<DeveloperSubmission>): Promise<DeveloperSubmission | undefined>;
  deleteSubmission(id: string): Promise<boolean>;

  // Downloads
  recordDownload(
    appId: string,
    releaseId: string,
    packageId: string,
    clientType: 'web' | 'android_client' | 'direct_api',
    userAgent?: string
  ): Promise<DownloadEvent>;
  getDownloadCount(appId?: string): Promise<number>;

  // Audit Logs
  addAuditLog(
    actorId: string,
    actorEmail: string,
    action: string,
    targetRecordId: string,
    targetType: 'app' | 'release' | 'submission' | 'user' | 'system',
    details: Record<string, unknown>,
    outcome?: 'success' | 'failure'
  ): Promise<void>;
  getAuditLogs(limit?: number): Promise<AuditLog[]>;

  // Users
  getUserByEmail(email: string): Promise<User | undefined>;

  // Raw Snapshot (for diagnostics / migration export)
  getSnapshot(): Promise<DatabaseSchema>;
}

export interface ApkStreamResult {
  stream: NodeJS.ReadableStream;
  size: number;
  sha256?: string;
  exists: boolean;
}

export interface IApkStorageProvider {
  readonly backendType: ApkStorageBackendType;

  init(): Promise<void>;
  healthCheck(): Promise<{ ok: boolean; bucketName?: string; error?: string }>;

  saveApk(
    destinationFilename: string,
    sourceFilePathOrBuffer: string | Buffer
  ): Promise<{ storagePath: string; size: number; sha256: string }>;

  getApkStream(storagePath: string): Promise<ApkStreamResult>;
  apkExists(storagePath: string): Promise<boolean>;
  deleteApk(storagePath: string): Promise<boolean>;
  getResolvedPath(storagePath: string): string;
  sanitizeFilename(filename: string): string;
}
