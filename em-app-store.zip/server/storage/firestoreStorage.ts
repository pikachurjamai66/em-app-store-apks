import { Firestore, Timestamp } from '@google-cloud/firestore';
import {
  IStorageProvider,
  StorageBackendType,
  StorageHealthStatus
} from './types.ts';
import { AppRecord, AppRelease, DeveloperSubmission, DownloadEvent, AuditLog, User, DatabaseSchema } from '../types.ts';

export interface FirestoreConfig {
  projectId?: string;
  databaseId?: string;
  keyFilename?: string;
}

export class FirestoreStorageProvider implements IStorageProvider {
  public readonly backendType: StorageBackendType = 'firestore';
  private firestore: Firestore | null = null;
  private readonly config: FirestoreConfig;
  private initialized = false;

  constructor(config: FirestoreConfig = {}) {
    this.config = {
      projectId: config.projectId || process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT,
      databaseId: config.databaseId || process.env.FIRESTORE_DATABASE_ID || '(default)',
      keyFilename: config.keyFilename || process.env.GOOGLE_APPLICATION_CREDENTIALS
    };
  }

  private getClient(): Firestore {
    if (!this.firestore) {
      const clientOptions: Record<string, any> = {};
      if (this.config.projectId) {
        clientOptions.projectId = this.config.projectId;
      }
      if (this.config.databaseId && this.config.databaseId !== '(default)') {
        clientOptions.databaseId = this.config.databaseId;
      }
      if (this.config.keyFilename) {
        clientOptions.keyFilename = this.config.keyFilename;
      }

      this.firestore = new Firestore(clientOptions);
    }
    return this.firestore;
  }

  // Allow injecting custom/mock Firestore client for testing
  public setClient(client: any): void {
    this.firestore = client;
    this.initialized = true;
  }

  public async init(): Promise<void> {
    const client = this.getClient();
    // Test connectivity by querying collection metadata
    try {
      await client.collection('_healthcheck').doc('ping').get();
      this.initialized = true;
    } catch (err: unknown) {
      this.initialized = false;
      const message = err instanceof Error ? err.message : String(err);
      throw new Error(`Failed to connect to Cloud Firestore (Database: ${this.config.databaseId || '(default)'}, Project: ${this.config.projectId || 'auto'}): ${message}`);
    }
  }

  public async healthCheck(): Promise<StorageHealthStatus> {
    try {
      const client = this.getClient();
      await client.collection('_healthcheck').doc('ping').get();
      return {
        ok: true,
        backend: 'firestore',
        apkBackend: 'gcs',
        databaseConnected: true,
        apkStorageConnected: true,
        details: {
          databaseId: this.config.databaseId || '(default)',
          projectId: this.config.projectId || 'default-adc'
        }
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        ok: false,
        backend: 'firestore',
        apkBackend: 'gcs',
        databaseConnected: false,
        apkStorageConnected: false,
        error: msg
      };
    }
  }

  public async getDeletedAppIds(): Promise<string[]> {
    const client = this.getClient();
    const snapshot = await client.collection('tombstones').get();
    return snapshot.docs.map(doc => doc.id);
  }

  public async isAppDeleted(appId: string): Promise<boolean> {
    const client = this.getClient();
    const doc = await client.collection('tombstones').doc(appId).get();
    return doc.exists;
  }

  public async getAllApps(): Promise<AppRecord[]> {
    const client = this.getClient();
    const [appsSnapshot, tombstones] = await Promise.all([
      client.collection('apps').get(),
      this.getDeletedAppIds()
    ]);

    const tombstoneSet = new Set(tombstones);
    const apps: AppRecord[] = [];
    for (const doc of appsSnapshot.docs) {
      if (!tombstoneSet.has(doc.id)) {
        apps.push(doc.data() as AppRecord);
      }
    }
    return apps;
  }

  public async getPublishedApps(): Promise<AppRecord[]> {
    const client = this.getClient();
    const [snapshot, tombstones] = await Promise.all([
      client.collection('apps').where('publicationStatus', '==', 'published').get(),
      this.getDeletedAppIds()
    ]);

    const tombstoneSet = new Set(tombstones);
    const apps: AppRecord[] = [];
    for (const doc of snapshot.docs) {
      if (!tombstoneSet.has(doc.id)) {
        apps.push(doc.data() as AppRecord);
      }
    }
    return apps;
  }

  public async getAppById(id: string): Promise<AppRecord | undefined> {
    const isDeleted = await this.isAppDeleted(id);
    if (isDeleted) return undefined;

    const client = this.getClient();
    const doc = await client.collection('apps').doc(id).get();
    if (!doc.exists) return undefined;
    return doc.data() as AppRecord;
  }

  public async getAppByIdOrSlug(idOrSlug: string): Promise<AppRecord | undefined> {
    const byId = await this.getAppById(idOrSlug);
    if (byId) return byId;

    const client = this.getClient();
    const tombstones = await this.getDeletedAppIds();
    const tombstoneSet = new Set(tombstones);

    const snapshot = await client.collection('apps').where('slug', '==', idOrSlug).limit(1).get();
    if (snapshot.empty) return undefined;

    const doc = snapshot.docs[0];
    if (tombstoneSet.has(doc.id)) return undefined;
    return doc.data() as AppRecord;
  }

  public async getAppByPackageId(packageId: string): Promise<AppRecord | undefined> {
    if (!packageId) return undefined;
    const clean = packageId.trim().toLowerCase();
    const tombstones = await this.getDeletedAppIds();
    const tombstoneSet = new Set(tombstones);

    const client = this.getClient();
    // Query by packageIdLower first
    let snapshot = await client.collection('apps').where('packageIdLower', '==', clean).limit(1).get();
    if (snapshot.empty) {
      snapshot = await client.collection('apps').where('packageId', '==', packageId.trim()).limit(1).get();
    }
    if (snapshot.empty) return undefined;

    const doc = snapshot.docs[0];
    if (tombstoneSet.has(doc.id)) return undefined;
    return doc.data() as AppRecord;
  }

  public async addApp(app: AppRecord): Promise<void> {
    const client = this.getClient();
    // Atomic check: Ensure tombstone is removed or update is clean
    const batch = client.batch();
    const tombstoneRef = client.collection('tombstones').doc(app.id);
    batch.delete(tombstoneRef);

    const appRef = client.collection('apps').doc(app.id);
    batch.set(appRef, {
      ...app,
      packageIdLower: app.packageId ? app.packageId.toLowerCase() : undefined,
      slugLower: app.slug ? app.slug.toLowerCase() : undefined
    });
    await batch.commit();
  }

  public async publishAppWithRelease(
    app: AppRecord,
    release?: AppRelease
  ): Promise<{ app: AppRecord; release?: AppRelease }> {
    const client = this.getClient();
    const batch = client.batch();

    // Ensure tombstone is removed
    const tombstoneRef = client.collection('tombstones').doc(app.id);
    batch.delete(tombstoneRef);

    // Save app document
    const appRef = client.collection('apps').doc(app.id);
    batch.set(appRef, {
      ...app,
      packageIdLower: app.packageId ? app.packageId.toLowerCase() : undefined,
      slugLower: app.slug ? app.slug.toLowerCase() : undefined
    });

    // Save release document if provided
    if (release) {
      const releaseRef = client.collection('releases').doc(release.id);
      batch.set(releaseRef, release);
    }

    await batch.commit();
    return { app, release };
  }

  public async updateApp(id: string, updates: Partial<AppRecord>): Promise<AppRecord | undefined> {
    const client = this.getClient();
    const docRef = client.collection('apps').doc(id);
    const doc = await docRef.get();
    if (!doc.exists) return undefined;

    const current = doc.data() as AppRecord;
    const updated: AppRecord = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    await docRef.set(updated, { merge: true });
    return updated;
  }

  public async deleteApp(id: string, _deleteApkFiles = false): Promise<boolean> {
    const client = this.getClient();
    const appRef = client.collection('apps').doc(id);
    const appDoc = await appRef.get();
    if (!appDoc.exists) return false;

    // Use atomic batch to record tombstone and remove app and releases
    const batch = client.batch();
    
    // 1. Record in tombstones collection permanently
    const tombstoneRef = client.collection('tombstones').doc(id);
    batch.set(tombstoneRef, {
      id,
      deletedAt: new Date().toISOString()
    });

    // 2. Delete the application document
    batch.delete(appRef);

    // 3. Find and delete associated releases in batch
    const releasesSnapshot = await client.collection('releases').where('appId', '==', id).get();
    for (const relDoc of releasesSnapshot.docs) {
      batch.delete(relDoc.ref);
    }

    await batch.commit();
    return true;
  }

  public async getReleasesForApp(appId: string): Promise<AppRelease[]> {
    const client = this.getClient();
    const snapshot = await client.collection('releases').where('appId', '==', appId).get();
    const releases = snapshot.docs.map(doc => doc.data() as AppRelease);
    return releases.sort((a, b) => b.versionCode - a.versionCode);
  }

  public async getReleaseById(id: string): Promise<AppRelease | undefined> {
    const client = this.getClient();
    const doc = await client.collection('releases').doc(id).get();
    if (!doc.exists) return undefined;
    return doc.data() as AppRelease;
  }

  public async addRelease(release: AppRelease): Promise<void> {
    const client = this.getClient();
    await client.collection('releases').doc(release.id).set(release);
  }

  public async updateRelease(id: string, updates: Partial<AppRelease>): Promise<AppRelease | undefined> {
    const client = this.getClient();
    const ref = client.collection('releases').doc(id);
    const doc = await ref.get();
    if (!doc.exists) return undefined;

    const current = doc.data() as AppRelease;
    const updated: AppRelease = {
      ...current,
      ...updates
    };
    await ref.set(updated, { merge: true });
    return updated;
  }

  public async deleteRelease(id: string, _deleteApkFile = false): Promise<boolean> {
    const client = this.getClient();
    const ref = client.collection('releases').doc(id);
    const doc = await ref.get();
    if (!doc.exists) return false;

    const release = doc.data() as AppRelease;
    await ref.delete();

    // Check if this was the current release for its app
    const appRef = client.collection('apps').doc(release.appId);
    const appDoc = await appRef.get();
    if (appDoc.exists) {
      const app = appDoc.data() as AppRecord;
      if (app.currentReleaseId === id) {
        const remaining = await this.getReleasesForApp(release.appId);
        const nextPublished = remaining.find(r => r.releaseStatus === 'published');
        await appRef.update({
          currentReleaseId: nextPublished?.id || '',
          updatedAt: new Date().toISOString()
        });
      }
    }

    return true;
  }

  public async setAppCurrentRelease(appId: string, releaseId: string): Promise<void> {
    const client = this.getClient();
    await client.collection('apps').doc(appId).update({
      currentReleaseId: releaseId,
      updatedAt: new Date().toISOString()
    });
  }

  public async getSubmissions(): Promise<DeveloperSubmission[]> {
    const client = this.getClient();
    const snapshot = await client.collection('submissions').get();
    const subs = snapshot.docs.map(doc => doc.data() as DeveloperSubmission);
    return subs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async getSubmissionById(id: string): Promise<DeveloperSubmission | undefined> {
    const client = this.getClient();
    const doc = await client.collection('submissions').doc(id).get();
    if (!doc.exists) return undefined;
    return doc.data() as DeveloperSubmission;
  }

  public async addSubmission(submission: DeveloperSubmission): Promise<void> {
    const client = this.getClient();
    await client.collection('submissions').doc(submission.id).set(submission);
  }

  public async updateSubmission(id: string, updates: Partial<DeveloperSubmission>): Promise<DeveloperSubmission | undefined> {
    const client = this.getClient();
    const ref = client.collection('submissions').doc(id);
    const doc = await ref.get();
    if (!doc.exists) return undefined;

    const current = doc.data() as DeveloperSubmission;
    const updated: DeveloperSubmission = {
      ...current,
      ...updates,
      reviewedAt: new Date().toISOString()
    };
    await ref.set(updated, { merge: true });
    return updated;
  }

  public async deleteSubmission(id: string): Promise<boolean> {
    const client = this.getClient();
    const ref = client.collection('submissions').doc(id);
    const doc = await ref.get();
    if (!doc.exists) return false;
    await ref.delete();
    return true;
  }

  public async recordDownload(
    appId: string,
    releaseId: string,
    packageId: string,
    clientType: 'web' | 'android_client' | 'direct_api',
    userAgent?: string
  ): Promise<DownloadEvent> {
    const client = this.getClient();
    const event: DownloadEvent = {
      id: `dl-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      appId,
      releaseId,
      packageId,
      clientType,
      timestamp: new Date().toISOString(),
      userAgent
    };
    await client.collection('download_events').doc(event.id).set(event);
    return event;
  }

  public async getDownloadCount(appId?: string): Promise<number> {
    const client = this.getClient();
    if (appId) {
      const snapshot = await client.collection('download_events').where('appId', '==', appId).count().get();
      return snapshot.data().count;
    }
    const snapshot = await client.collection('download_events').count().get();
    return snapshot.data().count;
  }

  private sanitizeAuditDetails(details: Record<string, unknown>): Record<string, unknown> {
    if (!details || typeof details !== 'object') return {};
    const sensitiveKeys = ['password', 'key', 'token', 'secret', 'authorization', 'cookie', 'credential', 'adminsecret', 'admintoken'];
    const sanitized: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(details)) {
      if (sensitiveKeys.some(sk => k.toLowerCase().includes(sk))) {
        sanitized[k] = '[REDACTED]';
      } else if (v && typeof v === 'object' && !Array.isArray(v)) {
        sanitized[k] = this.sanitizeAuditDetails(v as Record<string, unknown>);
      } else {
        sanitized[k] = v;
      }
    }
    return sanitized;
  }

  public async addAuditLog(
    actorId: string,
    actorEmail: string,
    action: string,
    targetRecordId: string,
    targetType: 'app' | 'release' | 'submission' | 'user' | 'system',
    details: Record<string, unknown>,
    outcome: 'success' | 'failure' = 'success'
  ): Promise<void> {
    const client = this.getClient();
    const log: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      actorId,
      actorEmail,
      action,
      targetRecordId,
      targetType,
      details: this.sanitizeAuditDetails(details),
      timestamp: new Date().toISOString(),
      outcome
    };
    await client.collection('audit_logs').doc(log.id).set(log);
  }

  public async getAuditLogs(limit = 100): Promise<AuditLog[]> {
    const client = this.getClient();
    const snapshot = await client.collection('audit_logs').orderBy('timestamp', 'desc').limit(limit).get();
    return snapshot.docs.map(doc => doc.data() as AuditLog);
  }

  public async getUserByEmail(email: string): Promise<User | undefined> {
    const client = this.getClient();
    const snapshot = await client.collection('users').where('email', '==', email.toLowerCase()).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as User;
  }

  public async getSnapshot(): Promise<DatabaseSchema> {
    const [apps, tombstones, releasesSnapshot, subsSnapshot, dlSnapshot, auditSnapshot, usersSnapshot] = await Promise.all([
      this.getAllApps(),
      this.getDeletedAppIds(),
      this.getClient().collection('releases').get(),
      this.getClient().collection('submissions').get(),
      this.getClient().collection('download_events').get(),
      this.getClient().collection('audit_logs').get(),
      this.getClient().collection('users').get()
    ]);

    return {
      users: usersSnapshot.docs.map(d => d.data() as User),
      apps,
      app_releases: releasesSnapshot.docs.map(d => d.data() as AppRelease),
      developer_submissions: subsSnapshot.docs.map(d => d.data() as DeveloperSubmission),
      download_events: dlSnapshot.docs.map(d => d.data() as DownloadEvent),
      audit_logs: auditSnapshot.docs.map(d => d.data() as AuditLog),
      deleted_app_ids: tombstones
    };
  }
}
