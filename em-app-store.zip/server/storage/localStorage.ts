import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  IStorageProvider,
  IApkStorageProvider,
  StorageBackendType,
  ApkStorageBackendType,
  StorageHealthStatus,
  ApkStreamResult
} from './types.ts';
import { db, DB_FILE, APK_STORAGE_DIR, BACKUP_DIR } from '../db.ts';
import { AppRecord, AppRelease, DeveloperSubmission, DownloadEvent, AuditLog, User, DatabaseSchema } from '../types.ts';

export class LocalStorageProvider implements IStorageProvider {
  public readonly backendType: StorageBackendType = 'local';

  public async init(): Promise<void> {
    // Ensure data, backup, and apks directories exist
    if (!fs.existsSync(APK_STORAGE_DIR)) {
      fs.mkdirSync(APK_STORAGE_DIR, { recursive: true });
    }
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }
    // Verify db is readable
    db.getAllApps();
  }

  public async healthCheck(): Promise<StorageHealthStatus> {
    try {
      const exists = fs.existsSync(DB_FILE);
      const stats = exists ? fs.statSync(DB_FILE) : null;
      const apps = db.getAllApps();
      const releases = db.getData().app_releases;

      return {
        ok: exists,
        backend: 'local',
        apkBackend: 'local',
        databaseConnected: exists,
        apkStorageConnected: fs.existsSync(APK_STORAGE_DIR),
        details: {
          dbFilePath: DB_FILE,
          dbFileSize: stats?.size ?? 0,
          appsCount: apps.length,
          releasesCount: releases.length,
          tombstoneCount: (db.getData().deleted_app_ids || []).length
        }
      };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      return {
        ok: false,
        backend: 'local',
        apkBackend: 'local',
        databaseConnected: false,
        apkStorageConnected: false,
        error: message
      };
    }
  }

  public async getAllApps(): Promise<AppRecord[]> {
    return db.getAllApps();
  }

  public async getPublishedApps(): Promise<AppRecord[]> {
    return db.getPublishedApps();
  }

  public async getAppById(id: string): Promise<AppRecord | undefined> {
    return db.getAppById(id);
  }

  public async getAppByIdOrSlug(idOrSlug: string): Promise<AppRecord | undefined> {
    return db.getAppByIdOrSlug(idOrSlug);
  }

  public async getAppByPackageId(packageId: string): Promise<AppRecord | undefined> {
    if (!packageId) return undefined;
    const clean = packageId.trim().toLowerCase();
    return db.getAllApps().find(a => a.packageId.toLowerCase() === clean);
  }

  public async addApp(app: AppRecord): Promise<void> {
    db.addApp(app);
  }

  public async updateApp(id: string, updates: Partial<AppRecord>): Promise<AppRecord | undefined> {
    return db.updateApp(id, updates);
  }

  public async deleteApp(id: string, deleteApkFiles = false): Promise<boolean> {
    return db.deleteApp(id, deleteApkFiles);
  }

  public async publishAppWithRelease(app: AppRecord, release?: AppRelease): Promise<{ app: AppRecord; release?: AppRelease }> {
    db.addApp(app);
    if (release) {
      db.addRelease(release);
    }
    return { app, release };
  }

  public async isAppDeleted(appId: string): Promise<boolean> {
    return db.isAppDeleted(appId);
  }

  public async getDeletedAppIds(): Promise<string[]> {
    return db.getData().deleted_app_ids || [];
  }

  public async getReleasesForApp(appId: string): Promise<AppRelease[]> {
    return db.getReleasesForApp(appId);
  }

  public async getReleaseById(id: string): Promise<AppRelease | undefined> {
    return db.getReleaseById(id);
  }

  public async addRelease(release: AppRelease): Promise<void> {
    db.addRelease(release);
  }

  public async updateRelease(id: string, updates: Partial<AppRelease>): Promise<AppRelease | undefined> {
    return db.updateRelease(id, updates);
  }

  public async deleteRelease(id: string, deleteApkFile = false): Promise<boolean> {
    return db.deleteRelease(id, deleteApkFile);
  }

  public async setAppCurrentRelease(appId: string, releaseId: string): Promise<void> {
    db.setAppCurrentRelease(appId, releaseId);
  }

  public async getSubmissions(): Promise<DeveloperSubmission[]> {
    return db.getSubmissions();
  }

  public async getSubmissionById(id: string): Promise<DeveloperSubmission | undefined> {
    return db.getSubmissions().find(s => s.id === id);
  }

  public async addSubmission(submission: DeveloperSubmission): Promise<void> {
    db.addSubmission(submission);
  }

  public async updateSubmission(id: string, updates: Partial<DeveloperSubmission>): Promise<DeveloperSubmission | undefined> {
    return db.updateSubmission(id, updates);
  }

  public async deleteSubmission(id: string): Promise<boolean> {
    return db.deleteSubmission(id);
  }

  public async recordDownload(
    appId: string,
    releaseId: string,
    packageId: string,
    clientType: 'web' | 'android_client' | 'direct_api',
    userAgent?: string
  ): Promise<DownloadEvent> {
    return db.recordDownload(appId, releaseId, packageId, clientType, userAgent);
  }

  public async getDownloadCount(appId?: string): Promise<number> {
    return db.getDownloadCount(appId);
  }

  public async addAuditLog(
    actorId: string,
    actorEmail: string,
    action: string,
    targetRecordId: string,
    targetType: 'app' | 'release' | 'submission' | 'user' | 'system',
    details: Record<string, unknown>,
    outcome: 'success' | 'failure' = 'success'
  ): Promise<void> {
    db.addAuditLog(actorId, actorEmail, action, targetRecordId, targetType, details, outcome);
  }

  public async getAuditLogs(limit = 100): Promise<AuditLog[]> {
    return db.getAuditLogs(limit);
  }

  public async getUserByEmail(email: string): Promise<User | undefined> {
    return db.getData().users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public async getSnapshot(): Promise<DatabaseSchema> {
    return JSON.parse(JSON.stringify(db.getData()));
  }
}

export class LocalApkStorageProvider implements IApkStorageProvider {
  public readonly backendType: ApkStorageBackendType = 'local';
  private readonly storageDir: string;

  constructor(storageDir: string = APK_STORAGE_DIR) {
    this.storageDir = path.resolve(storageDir);
    if (!fs.existsSync(this.storageDir)) {
      fs.mkdirSync(this.storageDir, { recursive: true });
    }
  }

  public async init(): Promise<void> {
    if (!fs.existsSync(this.storageDir)) {
      fs.mkdirSync(this.storageDir, { recursive: true });
    }
  }

  public async healthCheck(): Promise<{ ok: boolean; bucketName?: string; error?: string }> {
    try {
      const exists = fs.existsSync(this.storageDir);
      return { ok: exists };
    } catch (err: unknown) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) };
    }
  }

  public sanitizeFilename(filename: string): string {
    const base = path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, '_');
    return base.endsWith('.apk') ? base : `${base}.apk`;
  }

  public getResolvedPath(storagePath: string): string {
    if (!storagePath || !storagePath.trim()) {
      throw new Error('Empty storage path provided.');
    }
    const safeName = path.basename(storagePath.trim());
    if (!safeName || safeName === '.' || safeName === '/') {
      throw new Error(`Invalid storage path: ${storagePath}`);
    }
    const resolved = path.resolve(this.storageDir, safeName);
    if (!resolved.startsWith(this.storageDir) || resolved === this.storageDir) {
      throw new Error(`Path traversal violation detected: ${storagePath}`);
    }
    return resolved;
  }

  public async saveApk(
    destinationFilename: string,
    sourceFilePathOrBuffer: string | Buffer
  ): Promise<{ storagePath: string; size: number; sha256: string }> {
    const safeFilename = this.sanitizeFilename(destinationFilename);
    const targetPath = this.getResolvedPath(safeFilename);

    let sha256 = '';
    let size = 0;

    if (Buffer.isBuffer(sourceFilePathOrBuffer)) {
      size = sourceFilePathOrBuffer.length;
      sha256 = crypto.createHash('sha256').update(sourceFilePathOrBuffer).digest('hex').toLowerCase();
      fs.writeFileSync(targetPath, sourceFilePathOrBuffer);
    } else {
      if (!fs.existsSync(sourceFilePathOrBuffer)) {
        throw new Error(`Source APK file not found at: ${sourceFilePathOrBuffer}`);
      }
      // Calculate hash
      const hash = crypto.createHash('sha256');
      const input = fs.readFileSync(sourceFilePathOrBuffer);
      hash.update(input);
      sha256 = hash.digest('hex').toLowerCase();
      size = input.length;

      // Copy atomically to target
      if (sourceFilePathOrBuffer !== targetPath) {
        fs.copyFileSync(sourceFilePathOrBuffer, targetPath);
      }
    }

    return {
      storagePath: safeFilename,
      size,
      sha256
    };
  }

  public async getApkStream(storagePath: string): Promise<ApkStreamResult> {
    if (!storagePath || !storagePath.trim()) {
      return {
        stream: null as any,
        size: 0,
        exists: false
      };
    }
    try {
      const resolved = this.getResolvedPath(storagePath);
      if (!fs.existsSync(resolved) || fs.statSync(resolved).isDirectory()) {
        return {
          stream: null as any,
          size: 0,
          exists: false
        };
      }

      const stat = fs.statSync(resolved);
      const stream = fs.createReadStream(resolved);
      return {
        stream,
        size: stat.size,
        exists: true
      };
    } catch {
      return {
        stream: null as any,
        size: 0,
        exists: false
      };
    }
  }

  public async apkExists(storagePath: string): Promise<boolean> {
    if (!storagePath || !storagePath.trim()) return false;
    try {
      const resolved = this.getResolvedPath(storagePath);
      return fs.existsSync(resolved) && !fs.statSync(resolved).isDirectory();
    } catch {
      return false;
    }
  }

  public async deleteApk(storagePath: string): Promise<boolean> {
    try {
      const resolved = this.getResolvedPath(storagePath);
      if (fs.existsSync(resolved)) {
        fs.unlinkSync(resolved);
        return true;
      }
      return false;
    } catch (e) {
      console.error(`Failed to delete local APK ${storagePath}:`, e);
      return false;
    }
  }
}
