import assert from 'assert';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db, APK_STORAGE_DIR } from './db.ts';
import { DEFAULT_DEV_ADMIN_TOKEN } from './security/authManager.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = DEFAULT_DEV_ADMIN_TOKEN;

async function runPhase8WorkflowTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 8: DEVELOPER MANAGEMENT, SUBMISSIONS & WORKFLOWS');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // Record baseline numbers
  const baselineData = db.getData();
  const baselineAppsCount = baselineData.apps.length;
  const baselineReleasesCount = baselineData.app_releases.length;
  const baselinePublishedCount = db.getPublishedApps().length;
  const baselineSubmissionsCount = baselineData.developer_submissions.length;

  const testSubmissionsToClean: string[] = [];
  const testAppsToClean: string[] = [];
  const testReleasesToClean: string[] = [];

  // Helper using native FormData
  function makeFormData(fields: Record<string, string>, fileBuffer?: Buffer, fileName?: string): FormData {
    const fd = new FormData();
    for (const [k, v] of Object.entries(fields)) {
      fd.append(k, v);
    }
    if (fileBuffer && fileName) {
      const blob = new Blob([fileBuffer as any], { type: 'application/vnd.android.package-archive' });
      fd.append('apkFile', blob, fileName);
    }
    return fd;
  }

  // 1. Developer submission validation
  await step('Test 1: Submission validation rejects missing required fields and legal declarations', async () => {
    // 1a. Missing legal confirmation
    const fd1 = makeFormData({
      appName: 'Test App',
      packageId: 'com.test.invalid',
      developerName: 'Dev Name',
      developerEmail: 'dev@test.com',
      ownsCopyrightOrLicense: 'false'
    });
    const res1 = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd1
    });
    assert.strictEqual(res1.status, 400, 'Must reject if ownsCopyrightOrLicense is not true');
    const data1 = await res1.json();
    assert.ok(data1.error.includes('legal ownership'), 'Must mention legal ownership error');

    // 1b. Missing app name or packageId
    const fd2 = makeFormData({
      developerName: 'Dev Name',
      developerEmail: 'dev@test.com',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    });
    const res2 = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd2
    });
    assert.strictEqual(res2.status, 400, 'Must reject when required fields are missing');

    // 1c. Invalid Android package identifier format
    const fd3 = makeFormData({
      appName: 'Invalid Pkg',
      packageId: 'not_a_valid_package_name',
      developerName: 'Dev Name',
      developerEmail: 'dev@test.com',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    });
    const res3 = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd3
    });
    assert.strictEqual(res3.status, 400, 'Must reject invalid package identifier format');
  });

  // 2. Duplicate submission prevention (409 Conflict)
  let createdSubmissionId: string = '';
  const testPkg = `com.test.phase8.${Date.now()}`;
  const testDevEmail = 'phase8dev@testlabs.io';

  await step('Test 2: Duplicate submission prevention blocks duplicate submissions with HTTP 409', async () => {
    // Submit first valid submission
    const fd1 = makeFormData({
      appName: 'Phase 8 Tracker',
      packageId: testPkg,
      developerName: 'Phase 8 Dev',
      developerEmail: testDevEmail,
      versionName: '1.0.0',
      category: 'Productivity',
      shortDescription: 'Reliable task tracker for Phase 8 test suite',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    });
    const res1 = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd1
    });
    assert.strictEqual(res1.status, 201, 'First submission must succeed with HTTP 201');
    const data1 = await res1.json();
    assert.ok(data1.submissionId, 'Must return submissionId');
    createdSubmissionId = data1.submissionId;
    testSubmissionsToClean.push(createdSubmissionId);

    // Attempt second submission with exact same developerEmail, packageId, versionName immediately
    const fd2 = makeFormData({
      appName: 'Phase 8 Tracker',
      packageId: testPkg,
      developerName: 'Phase 8 Dev',
      developerEmail: testDevEmail,
      versionName: '1.0.0',
      category: 'Productivity',
      shortDescription: 'Duplicate attempt',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    });
    const res2 = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd2
    });
    assert.strictEqual(res2.status, 409, 'Duplicate submission must be rejected with HTTP 409 Conflict');
    const data2 = await res2.json();
    assert.strictEqual(data2.code, 'DUPLICATE_SUBMISSION', 'Error code must be DUPLICATE_SUBMISSION');
    assert.strictEqual(data2.existingSubmissionId, createdSubmissionId, 'Must reference existing submission ID');
  });

  // 3. Cross-developer ownership protection
  await step('Test 3: Cross-developer package takeover protection rejects unauthorized developer submissions with HTTP 403', async () => {
    // Zenith Markdown Notes is owned by 'dev-zenith-labs' / package 'org.zenith.notes'
    const fd = makeFormData({
      appName: 'Zenith Notes Hijack',
      packageId: 'org.zenith.notes',
      developerName: 'Malicious Actor',
      developerEmail: `hacker-${Date.now()}@unauthorized.com`,
      versionName: '9.9.9',
      category: 'Productivity',
      shortDescription: 'Attempt to overwrite existing developer application',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    });

    const res = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: fd
    });

    assert.strictEqual(res.status, 403, 'Must reject submission for package owned by another developer with HTTP 403');
    const data = await res.json();
    assert.strictEqual(data.code, 'UNAUTHORIZED_DEVELOPER', 'Must return UNAUTHORIZED_DEVELOPER error code');
  });

  // 4. Developer submission status lookup
  await step('Test 4: Developer submission status endpoints enforce developer isolation', async () => {
    // 4a. Query single submission with owner email
    const res1 = await fetch(`${BASE_URL}/api/submissions/${createdSubmissionId}?email=${encodeURIComponent(testDevEmail)}`);
    assert.strictEqual(res1.status, 200, 'Owner must be able to view their submission status');
    const data1 = await res1.json();
    assert.strictEqual(data1.submission.id, createdSubmissionId);
    assert.strictEqual(data1.submission.packageId, testPkg);
    assert.strictEqual(data1.submission.reviewStatus, 'submitted');

    // 4b. Query single submission with mismatched email
    const res2 = await fetch(`${BASE_URL}/api/submissions/${createdSubmissionId}?email=stranger@example.com`);
    assert.strictEqual(res2.status, 403, 'Mismatched developer email must be forbidden with HTTP 403');

    // 4c. Query list of developer submissions
    const res3 = await fetch(`${BASE_URL}/api/developer/submissions?email=${encodeURIComponent(testDevEmail)}`);
    assert.strictEqual(res3.status, 200, 'Must list developer submissions');
    const data3 = await res3.json();
    assert.ok(Array.isArray(data3.submissions), 'Must return submissions array');
    const found = data3.submissions.find((s: any) => s.id === createdSubmissionId);
    assert.ok(found, 'Created submission must be present in developer list');

    // 4d. Missing email query
    const res4 = await fetch(`${BASE_URL}/api/developer/submissions`);
    assert.strictEqual(res4.status, 400, 'Must require email parameter with HTTP 400');
  });

  // 5. Admin review workflow & rejection safety
  await step('Test 5: Admin review workflow requires authentication, validates status, and safely logs review actions', async () => {
    // 5a. Unauthorized review action rejected
    const unauthRes = await fetch(`${BASE_URL}/api/admin/submissions/${createdSubmissionId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reviewStatus: 'under_review' })
    });
    assert.strictEqual(unauthRes.status, 401, 'Unauthenticated review attempt must return HTTP 401');

    // 5b. Invalid review status rejected
    const invalidStatusRes = await fetch(`${BASE_URL}/api/admin/submissions/${createdSubmissionId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      },
      body: JSON.stringify({ reviewStatus: 'invalid_status_foo' })
    });
    assert.strictEqual(invalidStatusRes.status, 400, 'Invalid status must return HTTP 400');

    // 5c. Admin moves to under_review
    const reviewRes = await fetch(`${BASE_URL}/api/admin/submissions/${createdSubmissionId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      },
      body: JSON.stringify({
        reviewStatus: 'under_review',
        reviewNotes: 'Reviewing package security and declarations'
      })
    });
    assert.strictEqual(reviewRes.status, 200, 'Admin can transition status to under_review');
    const reviewData = await reviewRes.json();
    assert.strictEqual(reviewData.submission.reviewStatus, 'under_review');

    // 5d. Admin rejects a test submission to verify that published catalog is UNTOUCHED
    const rejectRes = await fetch(`${BASE_URL}/api/admin/submissions/${createdSubmissionId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      },
      body: JSON.stringify({
        reviewStatus: 'rejected',
        reviewNotes: 'Missing APK binary artifact in submission'
      })
    });
    assert.strictEqual(rejectRes.status, 200, 'Admin can reject submission');
    const rejectData = await rejectRes.json();
    assert.strictEqual(rejectData.submission.reviewStatus, 'rejected');

    // Verify published apps catalog was NOT touched or mutated by rejection
    const currentPublished = db.getPublishedApps();
    assert.strictEqual(
      currentPublished.length,
      baselinePublishedCount,
      'Rejection of a submission MUST NEVER alter or unpublish existing published apps'
    );
  });

  // 6. Publishing workflow & release integrity
  await step('Test 6: Publishing workflow requires approval, verified APK in storage, and assigns higher version codes', async () => {
    // 6a. Attempt to publish a rejected submission
    const pubRejectedRes = await fetch(`${BASE_URL}/api/admin/submissions/${createdSubmissionId}/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      }
    });
    assert.strictEqual(pubRejectedRes.status, 400, 'Publishing non-approved submission must return HTTP 400');
    const pubRejData = await pubRejectedRes.json();
    assert.strictEqual(pubRejData.code, 'NOT_APPROVED');

    // 6b. Create a new approved submission with a real APK from storage
    const sampleApkName = fs.readdirSync(APK_STORAGE_DIR).find(f => f.endsWith('.apk'));
    assert.ok(sampleApkName, 'Sample APK must exist in storage');
    const sampleApkPath = path.join(APK_STORAGE_DIR, sampleApkName);
    const sampleApkBytes = fs.readFileSync(sampleApkPath);

    const publishTestPkg = `com.test.publishable.${Date.now()}`;
    const pubFd = makeFormData({
      appName: 'Publishable Test App',
      packageId: publishTestPkg,
      developerName: 'Approved Dev',
      developerEmail: 'approved@dev.org',
      versionName: '1.2.0',
      category: 'Utilities',
      shortDescription: 'App created to test safe publishing pipeline',
      ownsCopyrightOrLicense: 'true',
      developerAuthorizedDistribution: 'true',
      termsAccepted: 'true'
    }, sampleApkBytes, 'publishable-test.apk');

    const subRes = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      body: pubFd
    });
    assert.strictEqual(subRes.status, 201, 'Submission with APK must succeed');
    const subData = await subRes.json();
    const approvedSubId = subData.submissionId;
    testSubmissionsToClean.push(approvedSubId);

    // Approve the submission
    const approveRes = await fetch(`${BASE_URL}/api/admin/submissions/${approvedSubId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      },
      body: JSON.stringify({ reviewStatus: 'approved', reviewNotes: 'Verified clean APK' })
    });
    assert.strictEqual(approveRes.status, 200, 'Must approve submission');

    // 6c. Publish approved submission
    const pubRes = await fetch(`${BASE_URL}/api/admin/submissions/${approvedSubId}/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      }
    });
    assert.strictEqual(pubRes.status, 200, 'Publishing approved submission with valid APK must succeed');
    const pubData = await pubRes.json();
    assert.ok(pubData.app, 'Must return published app record');
    assert.ok(pubData.release, 'Must return created release record');
    assert.strictEqual(pubData.app.publicationStatus, 'published');
    assert.strictEqual(pubData.release.releaseStatus, 'published');
    assert.strictEqual(pubData.release.versionCode, 1);

    testAppsToClean.push(pubData.app.id);
    testReleasesToClean.push(pubData.release.id);

    // Verify submission record was NOT deleted, but transitioned to 'published'
    const subCheck = db.getSubmissions().find(s => s.id === approvedSubId);
    assert.ok(subCheck, 'Submission record must be preserved after publication');
    assert.strictEqual(subCheck.reviewStatus, 'published', 'Submission reviewStatus must be published');
  });

  // 7. Metadata editing isolation & status protection
  await step('Test 7: Metadata updates cannot accidentally alter publicationStatus', async () => {
    // Find an existing published app
    const publishedApp = db.getPublishedApps()[0];
    assert.ok(publishedApp, 'Must have at least one published app');
    const originalStatus = publishedApp.publicationStatus;
    assert.strictEqual(originalStatus, 'published');

    // Update metadata without specifying publicationStatus
    const updateRes = await fetch(`${BASE_URL}/api/admin/apps/${publishedApp.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': ADMIN_TOKEN
      },
      body: JSON.stringify({
        shortDescription: `${publishedApp.shortDescription} (verified)`
      })
    });
    assert.strictEqual(updateRes.status, 200, 'App metadata update must succeed');
    const updateData = await updateRes.json();
    assert.strictEqual(
      updateData.app.publicationStatus,
      'published',
      'Updating description must NEVER revert or alter publicationStatus'
    );

    // Verify in db
    const freshApp = db.getAllApps().find(a => a.id === publishedApp.id);
    assert.strictEqual(freshApp?.publicationStatus, 'published');
  });

  // 8. Durable audit logging with sensitive credential redaction
  await step('Test 8: Audit logs recursively redact sensitive credentials and are durably persisted', async () => {
    // Add an audit log with sensitive details
    db.addAuditLog(
      'admin',
      'admin@test.local',
      'TEST_CREDENTIAL_CHECK',
      'test-entity-1',
      'system',
      {
        action: 'credentials_rotation',
        password: 'SUPER_SECRET_PASSWORD',
        apiKey: 'SECRET_API_KEY_12345',
        nested: {
          adminToken: 'SECRET_ADMIN_TOKEN_9999',
          safeField: 'visible_data'
        }
      }
    );

    const logs = db.getData().audit_logs;
    const testLog = logs.find(l => l.action === 'TEST_CREDENTIAL_CHECK');
    assert.ok(testLog, 'Audit log entry must be present');
    assert.strictEqual(testLog.details.password, '[REDACTED]', 'password must be redacted');
    assert.strictEqual(testLog.details.apiKey, '[REDACTED]', 'apiKey must be redacted');
    assert.strictEqual((testLog.details.nested as any).adminToken, '[REDACTED]', 'nested adminToken must be redacted');
    assert.strictEqual((testLog.details.nested as any).safeField, 'visible_data', 'safe fields must remain intact');
  });

  // 9. Comprehensive data retention & cleanup
  await step('Test 9: Baseline data preservation and safe test artifact cleanup', async () => {
    // Clean up temporary test apps and releases created during Test 6
    for (const appId of testAppsToClean) {
      db.deleteApp(appId, false);
    }
    for (const relId of testReleasesToClean) {
      db.deleteRelease(relId, false);
    }
    // Clean up temporary submissions created during tests (keep original baseline submissions)
    for (const subId of testSubmissionsToClean) {
      db.deleteSubmission(subId);
    }

    // Clean up the test audit log by filtering and persisting via dummy update
    const logs = db.getData().audit_logs.filter(l => l.action !== 'TEST_CREDENTIAL_CHECK');
    db.getData().audit_logs = logs;

    // Verify baseline invariants
    const finalData = db.getData();
    assert.strictEqual(db.getPublishedApps().length, baselinePublishedCount, 'Published apps count must match baseline exactly');
    assert.strictEqual(finalData.developer_submissions.length, baselineSubmissionsCount, 'Original developer submissions must be intact');
    assert.strictEqual(finalData.app_releases.length, baselineReleasesCount, 'Original releases count must match baseline exactly');

    // Confirm Soul Connect was never created
    const soulConnect = finalData.apps.find((a: any) =>
      a.name.toLowerCase().includes('soul connect') ||
      a.packageId.toLowerCase().includes('soulconnect')
    );
    assert.strictEqual(soulConnect, undefined, 'No fake Soul Connect record should exist');
  });

  console.log('\n========================================================================');
  console.log(`   PHASE 8 TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase8WorkflowTestSuite().catch(err => {
  console.error('Test suite runner crashed:', err);
  process.exit(1);
});
