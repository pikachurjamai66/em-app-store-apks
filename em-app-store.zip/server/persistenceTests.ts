import assert from 'assert';
import fs from 'fs';
import path from 'path';
import { db, DB_FILE, BACKUP_DIR, APK_STORAGE_DIR } from './db.ts';

const BASE_URL = 'http://localhost:3000';
const ADMIN_TOKEN = 'em-admin-token-secure-init';

async function runPersistenceTests() {
  console.log('=====================================================');
  console.log('   EM APP STORE PHASE 7: DATA PERSISTENCE TEST SUITE');
  console.log('=====================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(name: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${name}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      failed++;
    }
  }

  let testAppId = '';
  const testPackageId = `com.test.persistence.${Date.now()}`;
  const testAppName = `Persistence Test ${Date.now()}`;
  const testSlug = `persistence-test-${Date.now()}`;

  // Test A: Create a test app and verify it exists in the authoritative database
  await step('Test A: Create a test app and verify it exists in the authoritative database', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: testAppName,
        slug: testSlug,
        packageId: testPackageId,
        shortDescription: 'Verifying atomic disk persistence',
        fullDescription: 'Comprehensive test record for storage verification',
        category: 'Tools',
        publisher: 'Persistence Test Suite',
        publicationStatus: 'draft'
      })
    });

    assert.strictEqual(res.status, 201, `App creation must return 201 Created (got ${res.status})`);
    const data = await res.json();
    assert.ok(data.app && data.app.id, 'Response must include created app with ID');
    testAppId = data.app.id;

    // Direct filesystem authoritative verification
    assert.ok(fs.existsSync(DB_FILE), 'Primary db.json must exist');
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const diskDb = JSON.parse(raw);
    const foundOnDisk = diskDb.apps.find((a: any) => a.id === testAppId);
    assert.ok(foundOnDisk, 'Newly created app must exist in db.json on physical disk');
    assert.strictEqual(foundOnDisk.packageId, testPackageId);
  });

  // Test B: Refresh the dashboard and confirm the test app still exists
  await step('Test B: Refresh the dashboard (GET /api/admin/apps) and confirm test app exists', async () => {
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    const foundInList = data.apps.find((a: any) => a.id === testAppId);
    assert.ok(foundInList, 'Test app must remain present after reloading admin apps list');
    assert.strictEqual(foundInList.name, testAppName);
  });

  // Test C: Restart / re-read backend and confirm test app still exists
  await step('Test C: Verify persistence across fresh database read without cache', async () => {
    // Check that reading directly from the database engine returns the persisted test app
    const freshApps = db.getAllApps();
    const foundFresh = freshApps.find(a => a.id === testAppId);
    assert.ok(foundFresh, 'Test app must persist across database re-read operations');

    // Also verify rolling backup contains the app
    const backupFile = path.join(BACKUP_DIR, 'latest-valid-db.json');
    assert.ok(fs.existsSync(backupFile), 'Rolling backup latest-valid-db.json must exist');
    const backupRaw = fs.readFileSync(backupFile, 'utf-8');
    const backupDb = JSON.parse(backupRaw);
    const foundInBackup = backupDb.apps.find((a: any) => a.id === testAppId);
    assert.ok(foundInBackup, 'Test app must be synced into latest-valid-db.json backup');
  });

  // Test D: Perform a normal build and confirm test app still exists
  await step('Test D: Build verification & confirm app data remains intact', async () => {
    const rawBefore = fs.readFileSync(DB_FILE, 'utf-8');
    const beforeCount = JSON.parse(rawBefore).apps.length;

    // Query admin endpoint after build check
    const res = await fetch(`${BASE_URL}/api/admin/apps`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.apps.length, beforeCount, 'Application count must not change after build');
    const found = data.apps.find((a: any) => a.id === testAppId);
    assert.ok(found, 'Test app must still exist');
  });

  // Test E: Delete the test app explicitly, refresh, and confirm it does not reappear
  await step('Test E: Delete test app explicitly, refresh, and confirm it does not reappear', async () => {
    const delRes = await fetch(`${BASE_URL}/api/admin/apps/${testAppId}?deleteFiles=true`, {
      method: 'DELETE',
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    assert.strictEqual(delRes.status, 200, 'Delete app must return 200');

    // Verify removed from API
    const listRes = await fetch(`${BASE_URL}/api/admin/apps`, {
      headers: { 'x-admin-token': ADMIN_TOKEN }
    });
    const listData = await listRes.json();
    const foundInList = listData.apps.find((a: any) => a.id === testAppId);
    assert.strictEqual(foundInList, undefined, 'App must be removed from admin list');

    // Verify added to deleted_app_ids on disk
    const diskDb = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    assert.ok(diskDb.deleted_app_ids?.includes(testAppId), 'App ID must be recorded in deleted_app_ids ledger');
    assert.strictEqual(diskDb.apps.find((a: any) => a.id === testAppId), undefined, 'Must not exist in db.json apps');
  });

  // Test F: Confirm demo apps do not reappear automatically
  await step('Test F: Confirm deleted demo records do not reappear on restart/reload', async () => {
    // Delete a controlled temporary test demo record
    const tempDemoId = `app-demo-test-${Date.now()}`;
    db.addApp({
      id: tempDemoId,
      name: 'Temp Demo App',
      slug: `temp-demo-${Date.now()}`,
      packageId: `com.temp.demo.${Date.now()}`,
      shortDescription: 'Demo test',
      fullDescription: 'Demo test description',
      category: 'Tools',
      iconUrl: 'https://example.com/icon.png',
      screenshots: [],
      developerId: 'admin',
      publisher: 'Demo Publisher',
      currentReleaseId: '',
      publicationStatus: 'draft',
      privacyPolicyUrl: '/privacy',
      minAndroidVersion: 'Android 8.0',
      permissions: [],
      isDemonstration: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Delete it
    db.deleteApp(tempDemoId, false);
    assert.strictEqual(db.isAppDeleted(tempDemoId), true, 'Demo app must be marked as deleted');

    // Force reload from disk
    const reloadedApps = db.getAllApps();
    const found = reloadedApps.find(a => a.id === tempDemoId);
    assert.strictEqual(found, undefined, 'Deleted demo app must NEVER reappear after reload');
  });

  // Test G: Simulate an API/database failure and confirm response is valid JSON error
  await step('Test G: Simulate error & confirm API returns valid JSON error (not HTML)', async () => {
    // Calling invalid API endpoint
    const res = await fetch(`${BASE_URL}/api/admin/non-existent-route-for-test`);
    assert.strictEqual(res.status, 404);
    const contentType = res.headers.get('content-type') || '';
    assert.ok(contentType.includes('application/json'), `Must return application/json (got ${contentType})`);
    const data = await res.json();
    assert.ok(data.error, 'Must contain error property');
    assert.ok(!data.error.includes('<!DOCTYPE'), 'Must NOT return HTML doctype string');
  });

  // Test H: Verify that an app cannot disappear merely because a request failed
  await step('Test H: Verify app does not disappear when an invalid update request fails', async () => {
    // Pick the first existing app
    const allApps = db.getAllApps();
    assert.ok(allApps.length > 0, 'Must have at least one app');
    const targetApp = allApps[0];

    // Send an invalid publish request (e.g. invalid status or body)
    const failRes = await fetch(`${BASE_URL}/api/admin/apps/non-existent-app-99999`, {
      method: 'PUT',
      headers: {
        'x-admin-token': ADMIN_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ publicationStatus: 'invalid_status' })
    });
    assert.strictEqual(failRes.status, 404);

    // Verify existing target app is completely unharmed
    const verifyApp = db.getAppByIdOrSlug(targetApp.id);
    assert.ok(verifyApp, 'Target app must remain intact after failed request');
    assert.strictEqual(verifyApp.id, targetApp.id);
  });

  // Test I: Confirm the Soul Connect record is not duplicated
  await step('Test I: Confirm Soul Connect record is not duplicated or fabricated', async () => {
    const allApps = db.getAllApps();
    const soulConnectApps = allApps.filter(
      a => a.packageId === 'com.soulconnect.app' || a.name.toLowerCase().includes('soul connect')
    );
    assert.ok(
      soulConnectApps.length <= 1,
      `Soul Connect must not have duplicate records (found ${soulConnectApps.length})`
    );
    // Since Soul Connect failed before save, it should be 0 or 1 legitimate record
    console.log(`    (Current count of Soul Connect in authoritative database: ${soulConnectApps.length})`);
  });

  console.log(`\n=====================================================`);
  console.log(`   TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log(`=====================================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runPersistenceTests().catch(err => {
  console.error('Fatal persistence test execution error:', err);
  process.exit(1);
});
