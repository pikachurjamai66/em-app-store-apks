import assert from 'assert';
import crypto from 'crypto';
import {
  verifyAdminSessionToken,
  createAdminSessionToken,
  revokeAdminSession,
  recordFailedLoginAttempt,
  clearLoginRateLimit,
  SESSION_TTL_MS,
  getAdminSecret,
  DEFAULT_DEV_ADMIN_TOKEN
} from './security/authManager.ts';
import { db } from './db.ts';

const BASE_URL = 'http://localhost:3000';
const VALID_DEV_ADMIN_TOKEN = DEFAULT_DEV_ADMIN_TOKEN;

async function runPhase4SecurityTestSuite() {
  console.log('========================================================================');
  console.log('   EM APP STORE PHASE 4: SECURITY, AUTHORIZATION & AUDIT SUITE');
  console.log('   (Covers all 11 criteria specified in Phase 4 Step 8)');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  async function step(title: string, fn: () => Promise<void>) {
    process.stdout.write(`• ${title}... `);
    try {
      await fn();
      console.log('PASSED ✓');
      passed++;
    } catch (err: any) {
      console.log('FAILED ✗');
      console.error('    Error:', err.message);
      if (err.stack) {
        console.error('    Trace:', err.stack.split('\n').slice(1, 4).join('\n'));
      }
      failed++;
    }
  }

  // 1. Unauthenticated requests cannot perform administrative operations
  await step('Test 1: Unauthenticated requests to administrative endpoints are rejected (401)', async () => {
    const endpoints = [
      { method: 'GET', url: `${BASE_URL}/api/admin/apps` },
      { method: 'POST', url: `${BASE_URL}/api/admin/apps`, body: JSON.stringify({ name: 'Hacker App' }) },
      { method: 'DELETE', url: `${BASE_URL}/api/admin/apps/fake-id` },
      { method: 'GET', url: `${BASE_URL}/api/admin/audit-logs` },
      { method: 'GET', url: `${BASE_URL}/api/admin/data-integrity` },
      { method: 'GET', url: `${BASE_URL}/api/admin/migration/dry-run` }
    ];

    for (const ep of endpoints) {
      const res = await fetch(ep.url, {
        method: ep.method,
        headers: { 'Content-Type': 'application/json' },
        body: ep.body
      });
      assert.strictEqual(
        res.status,
        401,
        `Endpoint ${ep.method} ${ep.url} must return 401 Unauthorized without admin token (got ${res.status})`
      );
      const data = await res.json();
      assert.strictEqual(data.code, 'AUTH_REQUIRED');
    }
  });

  // 2. Invalid, expired, or tampered sessions are rejected
  await step('Test 2: Invalid, expired, or tampered session tokens are rejected', async () => {
    // 2a. Random garbage token
    assert.strictEqual(verifyAdminSessionToken('fake-token-12345'), false);

    // 2b. Tampered signature on valid-format token
    const tamperedToken = `em-admin-session-${Date.now()}-ffffffffffffffffffffffffffffffff`;
    assert.strictEqual(verifyAdminSessionToken(tamperedToken), false);

    // 2c. Expired token (created 25 hours ago)
    const expiredTimestamp = (Date.now() - (SESSION_TTL_MS + 3600000)).toString();
    const secretForHmac = getAdminSecret() || 'test-secret';
    const expiredSignature = crypto
      .createHmac('sha256', secretForHmac)
      .update(expiredTimestamp)
      .digest('hex')
      .substring(0, 32);
    const expiredToken = `em-admin-session-${expiredTimestamp}-${expiredSignature}`;
    assert.strictEqual(verifyAdminSessionToken(expiredToken), false, 'Session older than 24h must be rejected as expired');

    // 2d. Future timestamp spoofing (created 10 minutes in the future)
    const futureTimestamp = (Date.now() + 600000).toString();
    const futureSignature = crypto
      .createHmac('sha256', secretForHmac)
      .update(futureTimestamp)
      .digest('hex')
      .substring(0, 32);
    const futureToken = `em-admin-session-${futureTimestamp}-${futureSignature}`;
    assert.strictEqual(verifyAdminSessionToken(futureToken), false, 'Future-dated session must be rejected');

    // 2e. Valid session is accepted
    const validSession = createAdminSessionToken('test-admin@em.local');
    assert.strictEqual(verifyAdminSessionToken(validSession), true);

    // 2f. Revoked session is rejected
    revokeAdminSession(validSession);
    assert.strictEqual(verifyAdminSessionToken(validSession), false, 'Revoked session must be rejected');
  });

  // 3. Public app listing and download routes still work as intended
  await step('Test 3: Public catalog and download endpoints remain fully accessible without auth', async () => {
    // Public apps list
    const appsRes = await fetch(`${BASE_URL}/api/apps`);
    assert.strictEqual(appsRes.status, 200);
    const appsData = await appsRes.json();
    assert.ok(Array.isArray(appsData.apps));
    assert.ok(appsData.apps.length > 0);

    // Public categories
    const catRes = await fetch(`${BASE_URL}/api/categories`);
    assert.strictEqual(catRes.status, 200);

    // Public stats
    const statsRes = await fetch(`${BASE_URL}/api/stats`);
    assert.strictEqual(statsRes.status, 200);

    // Public health
    const healthRes = await fetch(`${BASE_URL}/api/health`);
    assert.strictEqual(healthRes.status, 200);
  });

  // 4. Admin login rate limiting works
  await step('Test 4: Admin login rate limiting locks out after 5 consecutive failures', async () => {
    const testIp = `192.0.2.${Math.floor(Math.random() * 200) + 10}`;

    // Clear any prior rate limit for test IP
    clearLoginRateLimit(testIp);

    // Simulate 4 failed attempts
    for (let i = 1; i <= 4; i++) {
      const result = recordFailedLoginAttempt(testIp);
      assert.strictEqual(result.isLocked, false);
      assert.strictEqual(result.remainingAttempts, 5 - i);
    }

    // 5th failed attempt triggers lock
    const lockedResult = recordFailedLoginAttempt(testIp);
    assert.strictEqual(lockedResult.isLocked, true);
    assert.strictEqual(lockedResult.remainingAttempts, 0);

    // Clean up
    clearLoginRateLimit(testIp);
  });

  // 5. Malformed requests and unsafe upload filenames are rejected
  await step('Test 5: Path traversal filenames and invalid extensions are strictly rejected', async () => {
    // Malformed submission package ID
    const badSubmission = await fetch(`${BASE_URL}/api/submissions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        developerName: 'Attacker',
        developerEmail: 'attack@test.com',
        appName: 'Path Attack',
        packageId: '../../etc/passwd',
        ownsCopyrightOrLicense: true,
        developerAuthorizedDistribution: true,
        termsAccepted: true
      })
    });
    assert.strictEqual(badSubmission.status, 400);
    const data = await badSubmission.json();
    assert.ok(data.error.includes('Invalid Android package identifier'));
  });

  // 6. Secrets are not returned in API responses
  await step('Test 6: Authentication secrets and environment keys are never leaked in API responses', async () => {
    const adminSecret = getAdminSecret() || 'admin-bootstrap';

    // Check /api/health
    const healthRes = await fetch(`${BASE_URL}/api/health`);
    const healthText = await healthRes.text();
    assert.ok(!healthText.includes(adminSecret), 'Health endpoint must not leak admin secret');

    // Check /api/stats
    const statsRes = await fetch(`${BASE_URL}/api/stats`);
    const statsText = await statsRes.text();
    assert.ok(!statsText.includes(adminSecret), 'Stats endpoint must not leak admin secret');

    // Check /api/admin/storage-status
    const storageRes = await fetch(`${BASE_URL}/api/admin/storage-status`, {
      headers: { 'x-admin-token': VALID_DEV_ADMIN_TOKEN }
    });
    const storageText = await storageRes.text();
    assert.ok(!storageText.includes(adminSecret), 'Storage status endpoint must not leak admin secret');
  });

  // 7. Failed authorization cannot modify app data
  await step('Test 7: Failed authorization attempts cannot mutate application records', async () => {
    const allBefore = db.getAllApps();
    const targetApp = allBefore[0];
    assert.ok(targetApp);

    // Attempt unauthorized DELETE
    const delRes = await fetch(`${BASE_URL}/api/admin/apps/${targetApp.id}`, {
      method: 'DELETE',
      headers: { 'x-admin-token': 'invalid-hacker-token' }
    });
    assert.strictEqual(delRes.status, 401);

    // Attempt unauthorized PUT
    const putRes = await fetch(`${BASE_URL}/api/admin/apps/${targetApp.id}`, {
      method: 'PUT',
      headers: {
        'x-admin-token': 'invalid-hacker-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: 'Hacked Name' })
    });
    assert.strictEqual(putRes.status, 401);

    // Verify app remains completely unchanged
    const allAfter = db.getAllApps();
    const verified = allAfter.find(a => a.id === targetApp.id);
    assert.strictEqual(verified?.name, targetApp.name);
  });

  // 8. Failed security checks do not delete or unpublish apps
  await step('Test 8: Failed security or auth checks never delete or unpublish applications', async () => {
    const publishedBefore = db.getPublishedApps();
    assert.ok(publishedBefore.length > 0);

    // Send series of bad requests with wrong tokens and payloads
    await fetch(`${BASE_URL}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: 'wrong-key-attempt' })
    });

    await fetch(`${BASE_URL}/api/admin/apps`, {
      method: 'POST',
      headers: { 'x-admin-token': 'bad-token' },
      body: JSON.stringify({})
    });

    const publishedAfter = db.getPublishedApps();
    assert.strictEqual(
      publishedAfter.length,
      publishedBefore.length,
      'Count of published applications must remain identical after failed auth attempts'
    );
  });

  // 9. Existing published apps remain published after server restart and authentication failures
  await step('Test 9: Published apps retain published status across session lifecycle', async () => {
    const apps = db.getPublishedApps();
    for (const app of apps) {
      assert.strictEqual(app.publicationStatus, 'published');
      assert.ok(app.id);
    }
  });

  // 10. Existing audit logs remain intact
  await step('Test 10: Security audit logs are appended without erasing historical records', async () => {
    const logs = db.getAuditLogs(50);
    assert.ok(Array.isArray(logs));
    assert.ok(logs.length > 0);

    // Verify recent security audit events exist
    const hasSecurityLog = logs.some(l =>
      l.action === 'ADMIN_LOGIN_SUCCESS' ||
      l.action === 'ADMIN_LOGIN_FAILED' ||
      l.action === 'ADMIN_LOGIN' ||
      l.action === 'ADMIN_LOGIN_ATTEMPT'
    );
    assert.ok(hasSecurityLog, 'Audit logs must capture administrative authentication events');
  });

  // 11. Existing API contracts remain compatible with the web frontend and Android app
  await step('Test 11: Web and Android Retrofit API contracts remain 100% compatible', async () => {
    // Test admin login endpoint shape expected by AdminDashboard.tsx and Android EmStoreApiService.kt
    const loginRes = await fetch(`${BASE_URL}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: VALID_DEV_ADMIN_TOKEN })
    });

    assert.strictEqual(loginRes.status, 200);
    const loginData = await loginRes.json();
    assert.strictEqual(loginData.success, true);
    assert.ok(loginData.token);
    assert.ok(loginData.user && loginData.user.email);

    // Test session verification endpoint (/api/admin/me)
    const meRes = await fetch(`${BASE_URL}/api/admin/me`, {
      headers: { 'x-admin-token': loginData.token }
    });
    assert.strictEqual(meRes.status, 200);
    const meData = await meRes.json();
    assert.strictEqual(meData.authenticated, true);
  });

  console.log('\n========================================================================');
  console.log(`PHASE 4 TEST RESULTS: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log('========================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase4SecurityTestSuite().catch(err => {
  console.error('Phase 4 security test execution failed:', err);
  process.exit(1);
});
