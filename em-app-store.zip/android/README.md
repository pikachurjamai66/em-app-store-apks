# EM Store — Official Android Client Application

This directory contains the complete native Android project structure for **EM Store** (`com.em.store`), the companion mobile client for **EM App Store**.

## Architecture & Platform Compliance

- **Language & UI**: Kotlin 1.9+ with Jetpack Compose & Material 3.
- **Minimum Android SDK**: Android 8.0 Oreo (API level 26).
- **Target SDK**: Android 14 (API level 34).
- **Networking**: OkHttp 4 / Retrofit 2 with TLS 1.3 encryption, consuming the live backend REST endpoints.
- **Native Admin Management**: Built-in administrator console with secret key authentication against `POST /api/admin/login`, live catalog viewing, and status toggling (`PUT /api/admin/apps/{id}`).
- **Integrity**: On-device SHA-256 calculation prior to package installer invocation (`ApkInstaller.verifySha256`).
- **Package Installation**: Complies with Android platform security standards:
  1. Requests `android.permission.REQUEST_INSTALL_PACKAGES` permission via explicit user navigation to system settings (`ACTION_MANAGE_UNKNOWN_APP_SOURCES`).
  2. Uses `androidx.core.content.FileProvider` to yield content URIs (`content://com.em.store.fileprovider/...`) with temporary read permissions.
  3. Hands off installation to the official Android system `PackageInstaller` (`Intent.ACTION_VIEW`). Does not attempt silent or unauthorized sideloading.

## Prerequisites

1. Android Studio Hedgehog (2023.1.1) or newer.
2. JDK 17 (Java Development Kit).
3. Android SDK platform 34 and build-tools 34.0.0.

## Project Structure

```
android/
├── gradlew, gradlew.bat, gradle/
│   ├── libs.versions.toml             # Gradle 8.4+ dependency version catalog
│   └── wrapper/
│       └── gradle-wrapper.properties  # Gradle 8.4 distribution
├── build.gradle.kts                   # Root build script
├── settings.gradle.kts                # Plugin management & repositories
└── app/
    ├── build.gradle.kts               # Compose, Retrofit, Coil, Security dependencies
    ├── proguard-rules.pro             # ProGuard optimization and serialization rules
    └── src/main/
        ├── AndroidManifest.xml        # Package permissions & FileProvider registration
        ├── res/
        │   ├── values/themes.xml      # Theme.EMStore definition
        │   ├── values/colors.xml      # Palette tokens
        │   ├── values/strings.xml     # App and notification channel strings
        │   ├── xml/file_paths.xml     # Secure FileProvider paths
        │   └── mipmap-anydpi-v26/     # Adaptive launcher icon drawables
        └── java/com/em/store/
            ├── MainActivity.kt        # Compose activity & navigation routes
            ├── installer/
            │   └── ApkInstaller.kt    # Checksum calculation & PackageInstaller handoff
            ├── data/
            │   ├── model/AppModels.kt # DTOs matching backend JSON schema
            │   └── api/
            │       └── EmStoreApiService.kt # Retrofit interface & configurable baseURL
            └── ui/screens/
                └── StoreScreens.kt    # Catalog, App Details, Config, and Admin Screen
```

## Backend Configuration

The API base URL is configurable at runtime within the app's **Config** screen or programmatically via `NetworkClient.setBaseUrl(url)`.

Default production URL:
```kotlin
https://ais-dev-yqn6wqabjls4wa6z3cctov-648031685497.asia-southeast1.run.app/
```

## Building and Assembling

### Command Line (Gradle Wrapper)

```bash
# 1. Navigate to android directory
cd android

# 2. Build release APK
./gradlew assembleRelease

# The generated unsigned APK will be located at:
# app/build/outputs/apk/release/app-release-unsigned.apk
```

### Automated Release Signing via Environment Variables

To have Gradle automatically sign the release APK during `./gradlew assembleRelease`:

```bash
export ANDROID_KEYSTORE_PATH="/path/to/em-store-release.jks"
export ANDROID_KEYSTORE_PASSWORD="your-keystore-password"
export ANDROID_KEY_ALIAS="em-store"
export ANDROID_KEY_PASSWORD="your-key-password"

cd android
./gradlew assembleRelease

# The generated signed release APK will be located at:
# app/build/outputs/apk/release/app-release.apk
```

If these environment variables are omitted, Gradle generates an unsigned release APK:
`app/build/outputs/apk/release/app-release-unsigned.apk`.

### Manual Keystore Generation & Post-Build Signing

```bash
# 1. Generate release keystore (once)
keytool -genkey -v -keystore em-store-release.jks \
  -alias em-store \
  -keyalg RSA -keysize 2048 -validity 10000

# 2. Align and sign the unsigned APK with apksigner (from Android SDK build-tools)
zipalign -v -p 4 app/build/outputs/apk/release/app-release-unsigned.apk app-release-aligned.apk

apksigner sign --ks em-store-release.jks \
  --ks-key-alias em-store \
  --out em-store-v1.0.0.apk app-release-aligned.apk

# 3. Verify signature and SHA-256
apksigner verify --verbose em-store-v1.0.0.apk
sha256sum em-store-v1.0.0.apk
```

## Android Platform Restrictions & Security Notes

- **Package Visibility (`<queries>`)**: Android 11+ restricts applications from querying arbitrary installed packages on user devices. The EM Store client adheres to user privacy and only tracks applications explicitly downloaded and installed through EM Store or manually queried by the user.
- **In-Place Updates**: Android OS strictly enforces signature matching during updates. An existing installed application can only be updated in-place if the replacement APK is signed with the exact same certificate and contains a higher `versionCode`.
