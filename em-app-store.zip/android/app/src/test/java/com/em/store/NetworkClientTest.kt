package com.em.store

import com.em.store.data.api.NetworkClient
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class NetworkClientTest {

    @Before
    fun setUp() {
        NetworkClient.resetToDefaultUrl()
    }

    @Test
    fun testDefaultBaseUrl_isSetCorrectly() {
        assertEquals(NetworkClient.DEFAULT_BASE_URL, NetworkClient.getBaseUrl())
        assertTrue(NetworkClient.getBaseUrl().endsWith("/"))
    }

    @Test
    fun testNormalizeUrl_addsTrailingSlash() {
        val normalized = NetworkClient.normalizeUrl("https://api.emstore.example.com")
        assertEquals("https://api.emstore.example.com/", normalized)
    }

    @Test
    fun testNormalizeUrl_preservesExistingTrailingSlash() {
        val normalized = NetworkClient.normalizeUrl("https://api.emstore.example.com/")
        assertEquals("https://api.emstore.example.com/", normalized)
    }

    @Test
    fun testNormalizeUrl_prependsHttpsIfMissingScheme() {
        val normalized = NetworkClient.normalizeUrl("api.emstore.example.com")
        assertEquals("https://api.emstore.example.com/", normalized)
    }

    @Test
    fun testNormalizeUrl_preservesHttpForLocalDevelopment() {
        val normalized = NetworkClient.normalizeUrl("http://10.0.2.2:3000")
        assertEquals("http://10.0.2.2:3000/", normalized)
    }

    @Test
    fun testNormalizeUrl_emptyStringFallsBackToDefault() {
        val normalized = NetworkClient.normalizeUrl("   ")
        assertEquals(NetworkClient.DEFAULT_BASE_URL, normalized)
    }

    @Test
    fun testSetBaseUrl_updatesActiveUrl() {
        NetworkClient.setBaseUrl("http://10.0.2.2:3000")
        assertEquals("http://10.0.2.2:3000/", NetworkClient.getBaseUrl())

        NetworkClient.resetToDefaultUrl()
        assertEquals(NetworkClient.DEFAULT_BASE_URL, NetworkClient.getBaseUrl())
    }
}
