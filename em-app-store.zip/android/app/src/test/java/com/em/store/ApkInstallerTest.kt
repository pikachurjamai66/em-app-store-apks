package com.em.store

import com.em.store.installer.ApkInstaller
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.security.MessageDigest

class ApkInstallerTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun testComputeSha256_computesAccurateHash() {
        val testFile = tempFolder.newFile("sample.apk")
        val sampleBytes = "Android Package Content Simulation 12345".toByteArray(Charsets.UTF_8)
        testFile.writeBytes(sampleBytes)

        val digest = MessageDigest.getInstance("SHA-256")
        val expectedSha = digest.digest(sampleBytes).joinToString("") { "%02x".format(it) }

        val computedSha = ApkInstaller.computeSha256(testFile)
        assertEquals(expectedSha, computedSha)
    }

    @Test
    fun testComputeSha256_nonExistentFile_returnsEmpty() {
        val ghostFile = File(tempFolder.root, "does_not_exist.apk")
        val computed = ApkInstaller.computeSha256(ghostFile)
        assertEquals("", computed)
    }

    @Test
    fun testVerifySha256_matchingChecksum_returnsTrue() {
        val testFile = tempFolder.newFile("verified.apk")
        val sampleBytes = "Genuine APK bytes from trusted developer".toByteArray(Charsets.UTF_8)
        testFile.writeBytes(sampleBytes)

        val digest = MessageDigest.getInstance("SHA-256")
        val expectedSha = digest.digest(sampleBytes).joinToString("") { "%02x".format(it) }

        assertTrue(ApkInstaller.verifySha256(testFile, expectedSha))
        assertTrue(ApkInstaller.verifySha256(testFile, expectedSha.uppercase()))
    }

    @Test
    fun testVerifySha256_corruptedBytes_returnsFalse() {
        val testFile = tempFolder.newFile("tampered.apk")
        testFile.writeBytes("Legitimate bytes".toByteArray(Charsets.UTF_8))

        val digest = MessageDigest.getInstance("SHA-256")
        val originalSha = digest.digest("Legitimate bytes".toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

        // Corrupt file by appending tampered bytes
        testFile.appendBytes("TAMPERED_INJECTION".toByteArray(Charsets.UTF_8))

        assertFalse(ApkInstaller.verifySha256(testFile, originalSha))
    }

    @Test
    fun testVerifySha256_blankHashOrMissingFile_returnsFalse() {
        val testFile = tempFolder.newFile("empty_hash.apk")
        testFile.writeBytes("some bytes".toByteArray(Charsets.UTF_8))

        assertFalse(ApkInstaller.verifySha256(testFile, ""))
        assertFalse(ApkInstaller.verifySha256(testFile, "   "))

        val missing = File(tempFolder.root, "missing.apk")
        assertFalse(ApkInstaller.verifySha256(missing, "somehash123"))
    }
}
