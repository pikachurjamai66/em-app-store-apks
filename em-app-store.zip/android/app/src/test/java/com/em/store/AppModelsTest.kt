package com.em.store

import com.em.store.data.model.*
import com.google.gson.Gson
import org.junit.Assert.*
import org.junit.Test

class AppModelsTest {

    private val gson = Gson()

    @Test
    fun testAppListResponse_deserialization() {
        val json = """
        {
            "apps": [
                {
                    "id": "app-101",
                    "name": "Nova Note Pro",
                    "slug": "nova-note-pro",
                    "packageId": "com.novanote.pro",
                    "shortDescription": "Sleek and secure note taking.",
                    "fullDescription": "Detailed description of Nova Note Pro.",
                    "category": "Productivity",
                    "iconUrl": "https://example.com/icon.png",
                    "screenshots": ["https://example.com/s1.png"],
                    "publisher": "Nova Team",
                    "currentReleaseId": "rel-201",
                    "publicationStatus": "published",
                    "downloads": 42,
                    "currentRelease": {
                        "id": "rel-201",
                        "versionName": "2.1.0",
                        "versionCode": 21,
                        "fileSize": 15420000,
                        "sha256": "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
                        "changelog": "Added dark mode.",
                        "publishedAt": "2026-10-20T10:00:00.000Z",
                        "verificationStatus": "verified"
                    }
                }
            ],
            "total": 1
        }
        """.trimIndent()

        val parsed = gson.fromJson(json, AppListResponse::class.java)
        assertNotNull(parsed)
        assertEquals(1, parsed.total)
        assertEquals(1, parsed.apps.size)

        val app = parsed.apps[0]
        assertEquals("app-101", app.id)
        assertEquals("Nova Note Pro", app.name)
        assertEquals("com.novanote.pro", app.packageId)
        assertEquals(42, app.downloads)
        assertNotNull(app.currentRelease)
        assertEquals("2.1.0", app.currentRelease?.versionName)
        assertEquals(21, app.currentRelease?.versionCode)
        assertEquals("verified", app.currentRelease?.verificationStatus)
    }

    @Test
    fun testAppDetailsResponse_deserializationWithReleases() {
        val json = """
        {
            "app": {
                "id": "app-101",
                "name": "Nova Note Pro",
                "slug": "nova-note-pro",
                "packageId": "com.novanote.pro",
                "shortDescription": "Sleek and secure note taking.",
                "category": "Productivity",
                "iconUrl": "https://example.com/icon.png",
                "publisher": "Nova Team",
                "publicationStatus": "published",
                "downloads": 100
            },
            "releases": [
                {
                    "id": "rel-201",
                    "versionName": "2.1.0",
                    "versionCode": 21,
                    "fileSize": 15420000,
                    "sha256": "hash21",
                    "changelog": "Newest release"
                },
                {
                    "id": "rel-200",
                    "versionName": "2.0.0",
                    "versionCode": 20,
                    "fileSize": 14000000,
                    "sha256": "hash20",
                    "changelog": "Initial 2.0 release"
                }
            ],
            "downloads": 100,
            "currentRelease": {
                "id": "rel-201",
                "versionName": "2.1.0",
                "versionCode": 21,
                "fileSize": 15420000,
                "sha256": "hash21"
            }
        }
        """.trimIndent()

        val parsed = gson.fromJson(json, AppDetailsResponse::class.java)
        assertNotNull(parsed)
        assertEquals("app-101", parsed.app.id)
        assertEquals(2, parsed.releases.size)
        assertEquals("2.1.0", parsed.releases[0].versionName)
        assertEquals(100, parsed.downloads)
        assertEquals("rel-201", parsed.currentRelease?.id)
    }

    @Test
    fun testCategoriesResponse_deserialization() {
        val json = """
        {
            "categories": [
                {"name": "Productivity", "count": 12},
                {"name": "Tools", "count": 8},
                {"name": "Games", "count": 5}
            ]
        }
        """.trimIndent()

        val parsed = gson.fromJson(json, CategoriesResponse::class.java)
        assertNotNull(parsed)
        assertEquals(3, parsed.categories.size)
        assertEquals("Productivity", parsed.categories[0].name)
        assertEquals(12, parsed.categories[0].count)
    }

    @Test
    fun testPlatformStatsDto_deserialization() {
        val json = """
        {
            "publishedAppsCount": 14,
            "totalDownloadsRecorded": 1500,
            "publishedReleasesCount": 28,
            "lastUpdated": "2026-10-24T18:30:00.000Z"
        }
        """.trimIndent()

        val parsed = gson.fromJson(json, PlatformStatsDto::class.java)
        assertNotNull(parsed)
        assertEquals(14, parsed.publishedAppsCount)
        assertEquals(1500, parsed.totalDownloadsRecorded)
        assertEquals(28, parsed.publishedReleasesCount)
        assertEquals("2026-10-24T18:30:00.000Z", parsed.lastUpdated)
    }

    @Test
    fun testAppItemDto_resilientWithNullOptionals() {
        val json = """
        {
            "id": "app-sparse",
            "name": "Sparse App",
            "slug": "sparse-app",
            "packageId": "com.sparse.app",
            "shortDescription": "Minimal fields provided",
            "category": "Tools",
            "iconUrl": "https://example.com/icon.png",
            "publisher": "Minimalist Dev",
            "publicationStatus": "published",
            "downloads": 0
        }
        """.trimIndent()

        val parsed = gson.fromJson(json, AppItemDto::class.java)
        assertNotNull(parsed)
        assertEquals("app-sparse", parsed.id)
        assertNull(parsed.fullDescription)
        assertNull(parsed.screenshots)
        assertNull(parsed.currentRelease)
        assertNull(parsed.currentReleaseId)
    }
}
