package com.em.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.em.store.data.model.AppItemDto
import com.em.store.ui.screens.AdminScreen
import com.em.store.ui.screens.AppDetailsScreen
import com.em.store.ui.screens.CatalogScreen
import com.em.store.ui.screens.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val darkColors = darkColorScheme(
                primary = Color(0xFF3B82F6),
                secondary = Color(0xFF10B981),
                background = Color(0xFF0B1120),
                surface = Color(0xFF0F172A),
                surfaceVariant = Color(0xFF1E293B)
            )

            MaterialTheme(colorScheme = darkColors) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentScreen by remember { mutableStateOf<String>("catalog") }
                    var selectedApp by remember { mutableStateOf<AppItemDto?>(null) }

                    when (currentScreen) {
                        "catalog" -> {
                            CatalogScreen(
                                onSelectApp = { app ->
                                    selectedApp = app
                                    currentScreen = "details"
                                },
                                onNavigateAdmin = {
                                    currentScreen = "admin"
                                },
                                onNavigateSettings = {
                                    currentScreen = "settings"
                                }
                            )
                        }
                        "details" -> {
                            selectedApp?.let { app ->
                                AppDetailsScreen(
                                    app = app,
                                    context = this@MainActivity,
                                    onBack = { currentScreen = "catalog" }
                                )
                            } ?: run {
                                currentScreen = "catalog"
                            }
                        }
                        "admin" -> {
                            AdminScreen(
                                onBack = { currentScreen = "catalog" }
                            )
                        }
                        "settings" -> {
                            SettingsScreen(
                                onBack = { currentScreen = "catalog" }
                            )
                        }
                    }
                }
            }
        }
    }
}
