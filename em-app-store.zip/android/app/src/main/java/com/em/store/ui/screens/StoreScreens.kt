package com.em.store.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.em.store.data.api.NetworkClient
import com.em.store.data.model.AppItemDto
import com.em.store.data.model.AdminLoginRequest
import com.em.store.installer.ApkInstaller
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(
    onSelectApp: (AppItemDto) -> Unit,
    onNavigateAdmin: () -> Unit,
    onNavigateSettings: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItemDto>>(emptyList()) }
    var categories by remember { mutableStateOf<List<String>>(listOf("All", "Tools", "Productivity", "Communication", "Entertainment", "Games")) }
    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun loadApps() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            try {
                val catParam = if (selectedCategory == "All") null else selectedCategory
                val queryParam = if (searchQuery.isBlank()) null else searchQuery.trim()
                val response = withContext(Dispatchers.IO) {
                    NetworkClient.apiService.getPublishedApps(category = catParam, query = queryParam)
                }
                if (response.isSuccessful && response.body() != null) {
                    apps = response.body()!!.apps
                } else {
                    errorMessage = "Server returned ${response.code()}: ${response.message()}"
                }
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Failed to connect to EM App Store server."
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        try {
            val catRes = withContext(Dispatchers.IO) {
                NetworkClient.apiService.getCategories()
            }
            if (catRes.isSuccessful && catRes.body() != null) {
                val serverCats = listOf("All") + catRes.body()!!.categories.map { it.name }
                categories = serverCats.distinct()
            }
        } catch (_: Exception) {
            // Retain default categories if categories endpoint is temporarily unreachable
        }
    }

    LaunchedEffect(selectedCategory) {
        loadApps()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("EM", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("EM Store", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                actions = {
                    TextButton(onClick = onNavigateAdmin) {
                        Text("Admin", fontSize = 12.sp)
                    }
                    TextButton(onClick = onNavigateSettings) {
                        Text("Config", fontSize = 12.sp)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                },
                placeholder = { Text("Search apps, packages...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                trailingIcon = {
                    TextButton(onClick = { loadApps() }) {
                        Text("Go")
                    }
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Categories Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage != null) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { loadApps() }) {
                        Text("Retry")
                    }
                }
            } else if (apps.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("No Applications Found", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        if (searchQuery.isNotBlank()) "No applications match \"$searchQuery\"." else "No published applications in the \"$selectedCategory\" category.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = {
                        searchQuery = ""
                        selectedCategory = "All"
                        loadApps()
                    }) {
                        Text("Show All Applications")
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(apps) { app ->
                        AppRowItem(app = app, onClick = { onSelectApp(app) })
                    }
                }
            }
        }
    }
}

@Composable
fun AppRowItem(app: AppItemDto, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = app.iconUrl,
                contentDescription = app.name,
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.DarkGray)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("by ${app.publisher}", color = Color.Gray, fontSize = 11.sp)
                Text(
                    text = "v${app.currentRelease?.versionName ?: "1.0.0"} • ${app.category}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Button(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("GET", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailsScreen(
    app: AppItemDto,
    context: Context,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var downloadProgress by remember { mutableStateOf(0f) }
    var isDownloading by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf<String?>(null) }
    var downloadedApkFile by remember { mutableStateOf<File?>(null) }

    var needsInstallPermission by remember { mutableStateOf(false) }

    fun launchInstaller(file: File) {
        if (!ApkInstaller.canRequestPackageInstalls(context)) {
            needsInstallPermission = true
            statusText = "Permission required: Please enable 'Install unknown apps' for EM Store, then return to complete installation."
            val settingsIntent = ApkInstaller.createUnknownSourcesSettingsIntent(context)
            if (settingsIntent != null) {
                context.startActivity(settingsIntent)
            }
        } else {
            needsInstallPermission = false
            statusText = "Package verified. Launching Android Package Installer..."
            val installIntent = ApkInstaller.installApk(context, file)
            context.startActivity(installIntent)
        }
    }

    fun startDownloadAndInstall() {
        val release = app.currentRelease ?: return
        val releaseId = release.id ?: app.currentReleaseId ?: return

        coroutineScope.launch {
            isDownloading = true
            downloadProgress = 0.01f
            statusText = "Connecting to repository..."
            needsInstallPermission = false

            val targetDir = File(context.cacheDir, "apks").apply { mkdirs() }
            val safeVersionName = (release.versionName ?: "1.0.0").replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val safePackageId = app.packageId.replace(Regex("[^a-zA-Z0-9._]"), "_")
            val targetFile = File(targetDir, "$safePackageId-v$safeVersionName.apk")
            val tempFile = File(targetDir, ".tmp_${safePackageId}_${release.versionCode}_${System.currentTimeMillis()}.apk.tmp")

            try {
                // If the target verified file already exists, check if its SHA-256 matches
                if (targetFile.exists() && targetFile.length() > 0L) {
                    val expectedSha256 = release.sha256?.trim() ?: ""
                    val cachedMatches = withContext(Dispatchers.IO) {
                        if (expectedSha256.isNotBlank()) ApkInstaller.verifySha256(targetFile, expectedSha256) else true
                    }
                    if (cachedMatches) {
                        downloadedApkFile = targetFile
                        launchInstaller(targetFile)
                        isDownloading = false
                        return@launch
                    }
                }

                val response = withContext(Dispatchers.IO) {
                    NetworkClient.apiService.downloadApk(releaseId)
                }

                if (!response.isSuccessful || response.body() == null) {
                    statusText = "Download failed: Server returned ${response.code()} ${response.message()}"
                    isDownloading = false
                    return@launch
                }

                val body = response.body()!!
                val contentLength = body.contentLength()
                var bytesReadTotal = 0L
                val buffer = ByteArray(32768)

                statusText = "Streaming package binary..."

                withContext(Dispatchers.IO) {
                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output ->
                            var bytesRead: Int
                            while (input.read(buffer).also { bytesRead = it } != -1) {
                                output.write(buffer, 0, bytesRead)
                                bytesReadTotal += bytesRead
                                if (contentLength > 0L) {
                                    val progressFraction = (bytesReadTotal.toFloat() / contentLength.toFloat()).coerceIn(0f, 1f)
                                    withContext(Dispatchers.Main) {
                                        downloadProgress = progressFraction
                                        val mbRead = bytesReadTotal / (1024 * 1024f)
                                        val mbTotal = contentLength / (1024 * 1024f)
                                        statusText = "Downloading: %.1f MB / %.1f MB (%d%%)".format(mbRead, mbTotal, (progressFraction * 100).toInt())
                                    }
                                } else {
                                    withContext(Dispatchers.Main) {
                                        val mbRead = bytesReadTotal / (1024 * 1024f)
                                        statusText = "Downloading: %.1f MB transferred".format(mbRead)
                                    }
                                }
                            }
                            output.flush()
                        }
                    }
                }

                if (contentLength > 0L && bytesReadTotal != contentLength) {
                    if (tempFile.exists()) tempFile.delete()
                    statusText = "Download error: Incomplete transfer (received $bytesReadTotal of $contentLength bytes)."
                    isDownloading = false
                    return@launch
                }

                if (!tempFile.exists() || tempFile.length() == 0L) {
                    if (tempFile.exists()) tempFile.delete()
                    statusText = "Download error: Received empty file from server."
                    isDownloading = false
                    return@launch
                }

                downloadProgress = 1f
                statusText = "Verifying cryptographic SHA-256..."

                val expectedSha256 = release.sha256?.trim() ?: ""
                val hashMatches = withContext(Dispatchers.IO) {
                    if (expectedSha256.isNotBlank()) {
                        ApkInstaller.verifySha256(tempFile, expectedSha256)
                    } else {
                        true
                    }
                }

                if (!hashMatches) {
                    val computed = withContext(Dispatchers.IO) { ApkInstaller.computeSha256(tempFile) }
                    if (tempFile.exists()) tempFile.delete()
                    statusText = "Security Check Failure: SHA-256 mismatch (Expected: $expectedSha256, got: $computed). Installation halted."
                    isDownloading = false
                    return@launch
                }

                // Promote temp file to final destination atomically
                if (targetFile.exists()) {
                    targetFile.delete()
                }
                val renamed = tempFile.renameTo(targetFile)
                if (!renamed) {
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }

                downloadedApkFile = targetFile
                launchInstaller(targetFile)
            } catch (e: Exception) {
                if (tempFile.exists()) {
                    try { tempFile.delete() } catch (_: Exception) {}
                }
                statusText = "Download error: ${e.localizedMessage ?: "Unexpected error"}"
            } finally {
                isDownloading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(app.name, fontSize = 16.sp) },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("← Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = app.iconUrl,
                    contentDescription = "",
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.DarkGray)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(app.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Publisher: ${app.publisher}", color = Color.Gray, fontSize = 12.sp)
                    Text("Package: ${app.packageId}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            // Description
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("About", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        app.fullDescription ?: app.shortDescription,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = Color.LightGray
                    )
                }
            }

            // Release Metadata
            app.currentRelease?.let { rel ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Version Details", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Version: v${rel.versionName} (Code: ${rel.versionCode})", fontSize = 12.sp)
                        Text("Size: ${(rel.fileSize / (1024 * 1024)).toInt()} MB", fontSize = 12.sp)
                        Text("SHA-256: ${rel.sha256}", fontSize = 10.sp, color = Color.Gray)
                        rel.changelog?.let {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Changelog: $it", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }

            if (isDownloading) {
                LinearProgressIndicator(
                    progress = { downloadProgress },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            statusText?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }

            if (needsInstallPermission) {
                Button(
                    onClick = {
                        val settingsIntent = ApkInstaller.createUnknownSourcesSettingsIntent(context)
                        if (settingsIntent != null) context.startActivity(settingsIntent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Open Settings to Allow Unknown Apps", fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (downloadedApkFile != null && downloadedApkFile!!.exists() && !isDownloading) {
                Button(
                    onClick = { launchInstaller(downloadedApkFile!!) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Install Verified APK", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = { startDownloadAndInstall() },
                    enabled = !isDownloading && app.currentRelease != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        if (isDownloading) "Downloading..." else "Download & Install APK",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var serverUrl by remember { mutableStateOf(NetworkClient.getBaseUrl()) }
    var savedMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("EM Store Configuration") },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("API Endpoint Configuration", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "Configure the EM App Store server backend address. Both the web store and this Android client communicate with this server.",
                fontSize = 12.sp,
                color = Color.Gray
            )

            OutlinedTextField(
                value = serverUrl,
                onValueChange = { serverUrl = it },
                label = { Text("Base URL") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = {
                    NetworkClient.setBaseUrl(serverUrl)
                    savedMessage = "Base URL updated to: $serverUrl"
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Configuration")
            }

            savedMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(onBack: () -> Unit) {
    val coroutineScope = rememberCoroutineScope()
    var adminToken by remember { mutableStateOf<String?>(null) }
    var secretKey by remember { mutableStateOf("") }
    var isAuthenticating by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf<String?>(null) }
    var adminApps by remember { mutableStateOf<List<AppItemDto>>(emptyList()) }
    var isLoadingApps by remember { mutableStateOf(false) }
    var actionStatusMessage by remember { mutableStateOf<String?>(null) }

    fun fetchAdminCatalog(token: String) {
        coroutineScope.launch {
            isLoadingApps = true
            actionStatusMessage = null
            try {
                val response = withContext(Dispatchers.IO) {
                    NetworkClient.apiService.getAdminApps(token)
                }
                if (response.isSuccessful && response.body() != null) {
                    adminApps = response.body()!!.apps
                } else {
                    actionStatusMessage = "Failed to load apps: ${response.code()}"
                }
            } catch (e: Exception) {
                actionStatusMessage = "Network error: ${e.localizedMessage}"
            } finally {
                isLoadingApps = false
            }
        }
    }

    fun handleLogin() {
        if (secretKey.isBlank()) {
            loginError = "Please enter the admin key."
            return
        }
        coroutineScope.launch {
            isAuthenticating = true
            loginError = null
            try {
                val response = withContext(Dispatchers.IO) {
                    NetworkClient.apiService.adminLogin(AdminLoginRequest(secretKey.trim()))
                }
                val body = response.body()
                if (response.isSuccessful && body != null && body.success && body.token != null) {
                    adminToken = body.token
                    fetchAdminCatalog(body.token)
                } else {
                    loginError = body?.error ?: "Invalid administrator credentials (${response.code()})"
                }
            } catch (e: Exception) {
                loginError = "Connection error: ${e.localizedMessage}"
            } finally {
                isAuthenticating = false
            }
        }
    }

    fun toggleAppStatus(app: AppItemDto) {
        val token = adminToken ?: return
        val newStatus = if (app.publicationStatus == "published") "draft" else "published"
        coroutineScope.launch {
            actionStatusMessage = "Updating ${app.name} to $newStatus..."
            try {
                val response = withContext(Dispatchers.IO) {
                    NetworkClient.apiService.updateAppStatus(token, app.id, mapOf("publicationStatus" to newStatus))
                }
                if (response.isSuccessful) {
                    actionStatusMessage = "Status for ${app.name} changed to $newStatus."
                    fetchAdminCatalog(token)
                } else {
                    actionStatusMessage = "Update failed: ${response.code()}"
                }
            } catch (e: Exception) {
                actionStatusMessage = "Error updating status: ${e.localizedMessage}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (adminToken != null) "EM Store Admin" else "Administrator Login") },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Back") } },
                actions = {
                    if (adminToken != null) {
                        TextButton(onClick = {
                            adminToken = null
                            secretKey = ""
                            adminApps = emptyList()
                        }) {
                            Text("Sign Out", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (adminToken == null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("EM Store Administrator Access", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            "Authenticate using the unified EM App Store secret key. This session uses the identical backend authorization endpoint as the web admin dashboard.",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )

                        OutlinedTextField(
                            value = secretKey,
                            onValueChange = {
                                secretKey = it
                                loginError = null
                            },
                            label = { Text("Admin Secret Key") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )

                        loginError?.let {
                            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { handleLogin() },
                            enabled = !isAuthenticating,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (isAuthenticating) "Verifying Credentials..." else "Sign In as Admin")
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Catalog Management", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Unified Server Catalog (${adminApps.size} apps)", fontSize = 12.sp, color = Color.Gray)
                    }
                    Button(
                        onClick = { fetchAdminCatalog(adminToken!!) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Refresh", fontSize = 12.sp)
                    }
                }

                actionStatusMessage?.let {
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                    }
                }

                if (isLoadingApps) {
                    Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(adminApps) { app ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(app.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(app.packageId, fontSize = 11.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Surface(
                                            color = if (app.publicationStatus == "published") Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFFF59E0B).copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                app.publicationStatus.uppercase(),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (app.publicationStatus == "published") Color(0xFF10B981) else Color(0xFFF59E0B),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { toggleAppStatus(app) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            if (app.publicationStatus == "published") "Unpublish" else "Publish",
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
