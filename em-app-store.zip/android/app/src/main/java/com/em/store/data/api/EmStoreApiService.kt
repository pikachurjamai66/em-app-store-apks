package com.em.store.data.api

import com.em.store.data.model.*
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface EmStoreApiService {

    @GET("api/apps")
    suspend fun getPublishedApps(
        @Query("category") category: String? = null,
        @Query("q") query: String? = null,
        @Query("sort") sort: String? = "latest"
    ): Response<AppListResponse>

    @GET("api/apps/{slugOrId}")
    suspend fun getAppDetails(
        @Path("slugOrId") slugOrId: String
    ): Response<AppDetailsResponse>

    @GET("api/categories")
    suspend fun getCategories(): Response<CategoriesResponse>

    @GET("api/stats")
    suspend fun getStats(): Response<PlatformStatsDto>

    @Streaming
    @GET("api/download/{releaseId}")
    suspend fun downloadApk(
        @Path("releaseId") releaseId: String,
        @Query("client") client: String = "android_client"
    ): Response<ResponseBody>

    @POST("api/admin/login")
    suspend fun adminLogin(
        @Body request: AdminLoginRequest
    ): Response<AdminLoginResponse>

    @GET("api/admin/apps")
    suspend fun getAdminApps(
        @Header("x-admin-token") token: String
    ): Response<AppListResponse>

    @PUT("api/admin/apps/{id}")
    suspend fun updateAppStatus(
        @Header("x-admin-token") token: String,
        @Path("id") appId: String,
        @Body body: Map<String, String>
    ): Response<Map<String, Any>>
}

object NetworkClient {
    const val DEFAULT_BASE_URL: String = "https://ais-dev-yqn6wqabjls4wa6z3cctov-648031685497.asia-southeast1.run.app/"

    private var baseUrl: String = DEFAULT_BASE_URL

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private var retrofit: Retrofit = buildRetrofit(baseUrl)

    fun normalizeUrl(rawUrl: String): String {
        var clean = rawUrl.trim()
        if (clean.isEmpty()) return DEFAULT_BASE_URL
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            clean = "https://$clean"
        }
        return if (clean.endsWith("/")) clean else "$clean/"
    }

    private fun buildRetrofit(url: String): Retrofit {
        val safeUrl = normalizeUrl(url)
        return Retrofit.Builder()
            .baseUrl(safeUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun setBaseUrl(newUrl: String) {
        val normalized = normalizeUrl(newUrl)
        baseUrl = normalized
        retrofit = buildRetrofit(normalized)
    }

    fun resetToDefaultUrl() {
        setBaseUrl(DEFAULT_BASE_URL)
    }

    fun getBaseUrl(): String = baseUrl

    val apiService: EmStoreApiService
        get() = retrofit.create(EmStoreApiService::class.java)
}
