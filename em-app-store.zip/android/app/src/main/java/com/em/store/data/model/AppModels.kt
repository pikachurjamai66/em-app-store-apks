package com.em.store.data.model

import com.google.gson.annotations.SerializedName

data class AppListResponse(
    @SerializedName("apps") val apps: List<AppItemDto>,
    @SerializedName("total") val total: Int
)

data class AppItemDto(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String,
    @SerializedName("packageId") val packageId: String,
    @SerializedName("shortDescription") val shortDescription: String,
    @SerializedName("fullDescription") val fullDescription: String?,
    @SerializedName("category") val category: String,
    @SerializedName("iconUrl") val iconUrl: String,
    @SerializedName("screenshots") val screenshots: List<String>?,
    @SerializedName("publisher") val publisher: String,
    @SerializedName("currentReleaseId") val currentReleaseId: String?,
    @SerializedName("publicationStatus") val publicationStatus: String,
    @SerializedName("privacyPolicyUrl") val privacyPolicyUrl: String?,
    @SerializedName("minAndroidVersion") val minAndroidVersion: String?,
    @SerializedName("targetAndroidVersion") val targetAndroidVersion: String?,
    @SerializedName("permissions") val permissions: List<String>?,
    @SerializedName("isDemonstration") val isDemonstration: Boolean?,
    @SerializedName("downloads") val downloads: Int,
    @SerializedName("currentRelease") val currentRelease: ReleaseItemDto?
)

data class ReleaseItemDto(
    @SerializedName("id") val id: String?,
    @SerializedName("versionName") val versionName: String = "1.0.0",
    @SerializedName("versionCode") val versionCode: Int = 1,
    @SerializedName("fileSize") val fileSize: Long = 0L,
    @SerializedName("sha256") val sha256: String = "",
    @SerializedName("changelog") val changelog: String? = null,
    @SerializedName("publishedAt") val publishedAt: String? = null,
    @SerializedName("verificationStatus") val verificationStatus: String? = null,
    @SerializedName("verificationSummary") val verificationSummary: String? = null
)

data class AppDetailsResponse(
    @SerializedName("app") val app: AppItemDto,
    @SerializedName("releases") val releases: List<ReleaseItemDto>,
    @SerializedName("downloads") val downloads: Int,
    @SerializedName("currentRelease") val currentRelease: ReleaseItemDto?
)

data class CategoriesResponse(
    @SerializedName("categories") val categories: List<CategoryDto>
)

data class CategoryDto(
    @SerializedName("name") val name: String,
    @SerializedName("count") val count: Int
)

data class PlatformStatsDto(
    @SerializedName("publishedAppsCount") val publishedAppsCount: Int,
    @SerializedName("totalDownloadsRecorded") val totalDownloadsRecorded: Int,
    @SerializedName("publishedReleasesCount") val publishedReleasesCount: Int,
    @SerializedName("lastUpdated") val lastUpdated: String?
)

data class AdminLoginRequest(
    @SerializedName("key") val key: String
)

data class AdminLoginResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("token") val token: String?,
    @SerializedName("error") val error: String?
)
