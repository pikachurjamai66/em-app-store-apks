# Proguard configuration for EM Store native client

# Keep Retrofit interface and methods
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepclassmembers,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# Keep Gson serialization models
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.em.store.data.model.** { *; }

# Keep Coil ImageLoader components
-keep class coil.** { *; }

# Keep AndroidX Security Crypto
-keep class androidx.security.crypto.** { *; }
