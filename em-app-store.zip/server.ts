import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import dotenv from 'dotenv';
import { APK_STORAGE_DIR } from './server/db.ts';
import { AppRecord, AppRelease, DeveloperSubmission } from './server/types.ts';
import { inspectApkFile } from './server/apkInspector.ts';
import {
  initializeStorage,
  getStorageProvider,
  getApkStorageProvider,
  getStorageHealth,
  resolveStorageConfig
} from './server/storage/index.ts';
import { validateDatabaseIntegrity } from './server/migration/integrityValidator.ts';
import { generateMigrationPlan } from './server/migration/migrateToCloud.ts';
import { checkCloudReadiness } from './server/migration/cloudReadiness.ts';
import {
  verifyAdminSessionToken,
  createAdminSessionToken,
  revokeAdminSession,
  adminLoginRateLimiter,
  recordFailedLoginAttempt,
  clearLoginRateLimit,
  getClientIp,
  sanitizeErrorMessage,
  getAdminSecret,
  getAdminSecretStatus,
  isDefaultBootstrapKeyInUse,
  DEFAULT_DEV_ADMIN_TOKEN
} from './server/security/authManager.ts';

dotenv.config();

const app = express();

function resolveServerPort(): number {
  // 1. Check CLI argument --port <port> (e.g. from tsx server.ts --port 3000 --host 0.0.0.0)
  const portArgIndex = process.argv.indexOf('--port');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const parsed = parseInt(process.argv[portArgIndex + 1], 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }

  // 2. Check DEFAULT_APP_PORT from container environment (typically 3000)
  if (process.env.DEFAULT_APP_PORT) {
    const defaultAppPort = parseInt(process.env.DEFAULT_APP_PORT, 10);
    if (!isNaN(defaultAppPort) && defaultAppPort > 0) return defaultAppPort;
  }

  // 3. In development mode, the dev server must always run on port 3000 behind reverse proxy
  if (process.env.NODE_ENV !== 'production') {
    return 3000;
  }

  // 4. In production standalone container, respect process.env.PORT
  return process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
}

const PORT = resolveServerPort();

// Download event deduplication map (IP:releaseId -> timestamp) to mitigate rapid re-download inflation
const recentDownloadsMap = new Map<string, number>();

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Multer upload configuration for APK files
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, APK_STORAGE_DIR);
  },
  filename: (_req, file, cb) => {
    // Generate secure random filename to prevent path traversal or arbitrary overwrite
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ext === '.apk' ? '.apk' : '.apk';
    const uniqueToken = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}`;
    cb(null, `pkg-${uniqueToken}${safeExt}`);
  }
});

const uploadApk = multer({
  storage,
  limits: {
    fileSize: parseInt(process.env.MAX_UPLOAD_MB || '150', 10) * 1024 * 1024
  },
  fileFilter: (_req, file, cb) => {
    const filename = (file.originalname || '').trim();
    if (!filename.toLowerCase().endsWith('.apk')) {
      return cb(new Error('Only files with .apk extension are permitted.'));
    }
    cb(null, true);
  }
});

// Safe Multer upload middleware wrapper that intercepts errors and guarantees JSON responses
const handleApkUpload = (req: Request, res: Response, next: NextFunction) => {
  uploadApk.single('apkFile')(req, res, (err: any) => {
    if (err) {
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          const maxMb = process.env.MAX_UPLOAD_MB || '150';
          return res.status(413).json({
            error: `APK package file size exceeds the allowed limit of ${maxMb}MB. Please compress or optimize the APK.`,
            code: 'LIMIT_FILE_SIZE'
          });
        }
        return res.status(400).json({
          error: `APK upload rejected (${err.code}): ${err.message}`,
          code: err.code
        });
      }
      return res.status(400).json({
        error: err.message || 'APK file upload failed.',
        code: 'UPLOAD_ERROR'
      });
    }
    next();
  });
};

function verifyAdminToken(token: string): boolean {
  return verifyAdminSessionToken(token);
}

// Admin Authorization Middleware
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const adminTokenHeader = req.headers['x-admin-token'] as string;
  let token = '';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else if (adminTokenHeader) {
    token = adminTokenHeader;
  }

  if (!verifyAdminToken(token)) {
    return res.status(401).json({
      error: 'Unauthorized: Valid administrator authorization token required.',
      code: 'AUTH_REQUIRED'
    });
  }

  next();
}

function isAdmin(req: Request): boolean {
  const authHeader = req.headers.authorization;
  const adminTokenHeader = req.headers['x-admin-token'] as string;
  let token = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else if (adminTokenHeader) {
    token = adminTokenHeader;
  }
  return verifyAdminToken(token);
}

// -------------------------------------------------------------
// PUBLIC API ENDPOINTS
// -------------------------------------------------------------

// System Health Check endpoint
app.get('/api/health', async (_req: Request, res: Response) => {
  try {
    const health = await getStorageHealth();
    const statusCode = health.ok ? 200 : 503;
    res.status(statusCode).json({
      status: health.ok ? 'ok' : 'degraded',
      backend: health.backend,
      apkBackend: health.apkBackend,
      databaseConnected: health.databaseConnected,
      apkStorageConnected: health.apkStorageConnected,
      details: health.details,
      error: health.error,
      timestamp: new Date().toISOString()
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({
      status: 'error',
      error: message,
      timestamp: new Date().toISOString()
    });
  }
});

// 1. List published apps with filtering, searching, sorting, and pagination
app.get('/api/apps', async (req: Request, res: Response) => {
  try {
    const query = ((req.query.q as string) || '').toLowerCase().trim();
    const category = (req.query.category as string) || '';
    const sort = (req.query.sort as string) || 'latest'; // latest | updated | popular | name

    const storage = getStorageProvider();
    let apps = await storage.getPublishedApps();
    const storageConfig = resolveStorageConfig();
    console.log(`[Diagnostic] Public catalog query: ${JSON.stringify({
      publishedCount: apps.length,
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);

    if (category && category !== 'All') {
      apps = apps.filter(a => (a.category || '').toLowerCase() === category.toLowerCase());
    }

    if (query) {
      apps = apps.filter(a =>
        (a.name || '').toLowerCase().includes(query) ||
        (a.shortDescription || '').toLowerCase().includes(query) ||
        (a.packageId || '').toLowerCase().includes(query) ||
        (a.publisher || '').toLowerCase().includes(query)
      );
    }

    // Attach real download counts and sanitized current release details
    const result = await Promise.all(apps.map(async app => {
      const allReleases = await storage.getReleasesForApp(app.id);
      const releases = allReleases.filter(r => r.releaseStatus === 'published');
      const currentRelease = releases.find(r => r.id === app.currentReleaseId) || releases[0];
      const downloads = await storage.getDownloadCount(app.id);

      return {
        id: app.id,
        name: app.name,
        slug: app.slug || app.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, ''),
        packageId: app.packageId,
        shortDescription: app.shortDescription || '',
        fullDescription: app.fullDescription || app.shortDescription || '',
        category: app.category || 'Tools',
        iconUrl: app.iconUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80',
        screenshots: Array.isArray(app.screenshots) ? app.screenshots : [],
        developerId: app.developerId || 'admin',
        publisher: app.publisher || 'Unknown Publisher',
        developerContact: app.developerContact,
        currentReleaseId: app.currentReleaseId || (currentRelease ? currentRelease.id : ''),
        publicationStatus: app.publicationStatus,
        privacyPolicyUrl: app.privacyPolicyUrl || '/privacy',
        minAndroidVersion: app.minAndroidVersion || 'Android 8.0 (API 26)',
        targetAndroidVersion: app.targetAndroidVersion || 'Android 14 (API 34)',
        permissions: Array.isArray(app.permissions) ? app.permissions : [],
        isDemonstration: Boolean(app.isDemonstration),
        createdAt: app.createdAt,
        updatedAt: app.updatedAt,
        downloads,
        currentRelease: currentRelease ? {
          id: currentRelease.id,
          versionName: currentRelease.versionName,
          versionCode: currentRelease.versionCode,
          fileSize: currentRelease.fileSize,
          sha256: currentRelease.sha256,
          changelog: currentRelease.changelog,
          publishedAt: currentRelease.publishedAt || currentRelease.createdAt,
          verificationStatus: currentRelease.verificationStatus,
          verificationSummary: currentRelease.verificationSummary
        } : null
      };
    }));

    if (sort === 'popular') {
      result.sort((a, b) => b.downloads - a.downloads);
    } else if (sort === 'updated') {
      result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    } else if (sort === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    const total = result.length;
    let paginated = result;
    if (req.query.limit) {
      const page = Math.max(1, parseInt(req.query.page as string, 10) || 1);
      const limit = Math.max(1, parseInt(req.query.limit as string, 10));
      const startIndex = (page - 1) * limit;
      paginated = result.slice(startIndex, startIndex + limit);
    }

    res.json({ apps: paginated, total });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to retrieve applications', details: message });
  }
});

// 2. Get single app details by id, slug, or packageId
app.get('/api/apps/:slugOrId', async (req: Request, res: Response) => {
  try {
    const { slugOrId } = req.params;
    const storage = getStorageProvider();
    const app = await storage.getAppByIdOrSlug(slugOrId);
    const adminMode = isAdmin(req);

    if (!app || (app.publicationStatus !== 'published' && !adminMode)) {
      return res.status(404).json({ error: 'Application not found or is currently not published.' });
    }

    const allReleases = await storage.getReleasesForApp(app.id);
    const visibleReleases = adminMode
      ? allReleases
      : allReleases.filter(r => r.releaseStatus === 'published');

    const downloads = await storage.getDownloadCount(app.id);
    const currentRelease = visibleReleases.find(r => r.id === app.currentReleaseId) || visibleReleases[0] || null;

    // Sanitize releases so internal storage paths are never leaked
    const sanitizedReleases = visibleReleases.map(r => ({
      id: r.id,
      appId: r.appId,
      packageId: r.packageId,
      versionName: r.versionName,
      versionCode: r.versionCode,
      fileSize: r.fileSize,
      sha256: r.sha256,
      changelog: r.changelog,
      releaseStatus: r.releaseStatus,
      signatureCertSha256: r.signatureCertSha256,
      verificationStatus: r.verificationStatus,
      verificationSummary: r.verificationSummary,
      hasManifest: r.hasManifest,
      createdAt: r.createdAt,
      publishedAt: r.publishedAt
    }));

    res.json({
      app: {
        ...app,
        downloads
      },
      releases: sanitizedReleases,
      downloads,
      currentRelease: currentRelease ? {
        id: currentRelease.id,
        versionName: currentRelease.versionName,
        versionCode: currentRelease.versionCode,
        fileSize: currentRelease.fileSize,
        sha256: currentRelease.sha256,
        changelog: currentRelease.changelog,
        publishedAt: currentRelease.publishedAt || currentRelease.createdAt,
        verificationStatus: currentRelease.verificationStatus,
        verificationSummary: currentRelease.verificationSummary
      } : null
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to retrieve application details', details: message });
  }
});

// 3. Categories with counts
app.get('/api/categories', async (_req: Request, res: Response) => {
  try {
    const storage = getStorageProvider();
    const apps = await storage.getPublishedApps();
    const categoriesMap: Record<string, number> = {
      'Tools': 0,
      'Productivity': 0,
      'Communication': 0,
      'Entertainment': 0,
      'Games': 0,
      'Education': 0,
      'Social': 0,
      'Utilities': 0
    };

    apps.forEach(a => {
      if (categoriesMap[a.category] !== undefined) {
        categoriesMap[a.category]++;
      } else {
        categoriesMap[a.category] = 1;
      }
    });

    const list = Object.entries(categoriesMap).map(([name, count]) => ({ name, count }));
    res.json({ categories: list });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to fetch categories', details: message });
  }
});

// 4. Real statistics
app.get('/api/stats', async (_req: Request, res: Response) => {
  try {
    const storage = getStorageProvider();
    const publishedApps = await storage.getPublishedApps();
    const totalDownloads = await storage.getDownloadCount();
    const allReleasesNested = await Promise.all(publishedApps.map(a => storage.getReleasesForApp(a.id)));
    const publishedReleases = allReleasesNested.flat().filter(r => r.releaseStatus === 'published');

    res.json({
      publishedAppsCount: publishedApps.length,
      totalDownloadsRecorded: totalDownloads,
      publishedReleasesCount: publishedReleases.length,
      lastUpdated: publishedApps.length > 0
        ? publishedApps.map(a => a.updatedAt).sort().reverse()[0]
        : null
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to fetch platform statistics', details: message });
  }
});

// 5. Authorized APK download endpoint with integrity and path traversal protection
app.get('/api/download/:releaseId', async (req: Request, res: Response) => {
  try {
    const { releaseId } = req.params;
    const clientType = (req.query.client as 'web' | 'android_client' | 'direct_api') || 'web';
    const adminMode = isAdmin(req);

    if (!releaseId || releaseId.trim().length === 0) {
      return res.status(400).json({ error: 'Invalid or missing release identifier.' });
    }

    const storage = getStorageProvider();
    const release = await storage.getReleaseById(releaseId);
    if (!release) {
      return res.status(404).json({ error: 'Release package record not found.' });
    }

    const app = await storage.getAppById(release.appId);
    if (!app) {
      return res.status(404).json({ error: 'Associated application not found.' });
    }

    // Check application publication status
    if (app.publicationStatus !== 'published' && !adminMode) {
      return res.status(403).json({ error: 'The application containing this release is not currently published.' });
    }

    // Check release publication status
    if (release.releaseStatus !== 'published' && !adminMode) {
      return res.status(403).json({ error: 'This release has not been published for distribution.' });
    }

    const apkStorage = getApkStorageProvider();
    const streamResult = await apkStorage.getApkStream(release.apkStoragePath);
    if (!streamResult.exists) {
      return res.status(404).json({
        error: 'APK package binary file is not currently present in storage.'
      });
    }

    // Record authentic download event with rapid retry deduplication (5 seconds)
    const clientIp = getClientIp(req);
    const dedupeKey = `${clientIp}:${release.id}`;
    const now = Date.now();
    const lastDownloadedAt = recentDownloadsMap.get(dedupeKey) || 0;
    if (now - lastDownloadedAt > 5000) {
      await storage.recordDownload(
        app.id,
        release.id,
        release.packageId,
        clientType,
        req.headers['user-agent']
      );
      recentDownloadsMap.set(dedupeKey, now);
      if (recentDownloadsMap.size > 2000) {
        for (const [k, v] of recentDownloadsMap.entries()) {
          if (now - v > 60000) recentDownloadsMap.delete(k);
        }
      }
    }

    const filename = `${release.packageId}-v${release.versionName}.apk`;
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('X-APK-SHA256', release.sha256);
    res.setHeader('X-APK-Package-ID', release.packageId);
    res.setHeader('X-APK-Version-Code', release.versionCode.toString());
    if (streamResult.size && streamResult.size > 0) {
      res.setHeader('Content-Length', streamResult.size.toString());
    }

    streamResult.stream.on('error', (err) => {
      console.error('File stream error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Error streaming package file' });
      } else {
        res.end();
      }
    });
    streamResult.stream.pipe(res);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Download failed', details: message });
  }
});

// 6. Developer Submissions endpoint
app.post('/api/submissions', handleApkUpload, async (req: Request, res: Response) => {
  try {
    const {
      developerName,
      developerEmail,
      appName,
      packageId,
      category,
      shortDescription,
      fullDescription,
      versionName,
      minAndroidVersion,
      privacyPolicyUrl,
      permissions,
      ownsCopyrightOrLicense,
      developerAuthorizedDistribution,
      termsAccepted,
      legalEntityStatement
    } = req.body;

    if (ownsCopyrightOrLicense !== 'true' && ownsCopyrightOrLicense !== true) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'You must confirm legal ownership or valid distribution license for this software.'
      });
    }

    if (developerAuthorizedDistribution !== 'true' && developerAuthorizedDistribution !== true) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'You must explicitly authorize EM App Store to distribute this application.'
      });
    }

    if (termsAccepted !== 'true' && termsAccepted !== true) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'You must agree to the EM App Store Developer Distribution Terms.'
      });
    }

    if (!appName || !packageId || !developerEmail || !developerName) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'Missing required fields: Application name, package identifier, developer name, and email are required.'
      });
    }

    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i;
    if (!packageRegex.test(packageId.trim())) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'Invalid Android package identifier. Must follow standard reverse-DNS format (e.g., com.company.app).'
      });
    }

    const storageProvider = getStorageProvider();

    // 1. Duplicate submission prevention: Check if identical submission is already pending review
    const allSubmissions = await storageProvider.getSubmissions();
    const recentDuplicate = allSubmissions.find(s =>
      s.developerEmail.toLowerCase() === developerEmail.trim().toLowerCase() &&
      s.packageId.toLowerCase() === packageId.trim().toLowerCase() &&
      s.versionName.trim() === (versionName || '1.0.0').trim() &&
      (s.reviewStatus === 'submitted' || s.reviewStatus === 'under_review') &&
      (Date.now() - new Date(s.createdAt).getTime() < 300000)
    );
    if (recentDuplicate) {
      if (req.file && fs.existsSync(req.file.path)) {
        try { fs.unlinkSync(req.file.path); } catch {}
      }
      return res.status(409).json({
        error: `A submission for package "${packageId}" version "${versionName || '1.0.0'}" is already pending review (ID: ${recentDuplicate.id}). Please wait for administrator review.`,
        code: 'DUPLICATE_SUBMISSION',
        existingSubmissionId: recentDuplicate.id
      });
    }

    // 2. Developer ownership verification: Prevent one developer from overwriting another developer's app
    const existingApp = await storageProvider.getAppByPackageId(packageId.trim());
    if (existingApp && existingApp.developerId && existingApp.developerId !== 'admin') {
      const isAuthorizedDeveloper =
        existingApp.developerId.toLowerCase() === developerEmail.trim().toLowerCase() ||
        (existingApp.developerContact && existingApp.developerContact.toLowerCase() === developerEmail.trim().toLowerCase());

      if (!isAuthorizedDeveloper) {
        if (req.file && fs.existsSync(req.file.path)) {
          try { fs.unlinkSync(req.file.path); } catch {}
        }
        return res.status(403).json({
          error: `Package identifier "${packageId.trim()}" is already registered to another developer. You cannot submit updates for an application you do not own.`,
          code: 'UNAUTHORIZED_DEVELOPER'
        });
      }
    }

    let parsedPermissions: string[] = [];
    if (typeof permissions === 'string') {
      try {
        parsedPermissions = JSON.parse(permissions);
      } catch {
        parsedPermissions = permissions.split(',').map(s => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(permissions)) {
      parsedPermissions = permissions;
    }

    let apkStoragePath: string | undefined = undefined;
    let apkFileSize: number | undefined = undefined;
    let apkSha256: string | undefined = undefined;

    if (req.file) {
      try {
        const inspection = inspectApkFile(req.file.path);
        if (!inspection.isValidZip || !inspection.hasManifest) {
          fs.unlinkSync(req.file.path);
          return res.status(400).json({
            error: inspection.inspectionSummary || 'Uploaded file is not a valid Android APK package.'
          });
        }
        const saved = await getApkStorageProvider().saveApk(path.basename(req.file.path), req.file.path);
        apkStoragePath = saved.storagePath;
        apkFileSize = inspection.fileSize;
        apkSha256 = inspection.sha256;
      } catch (e) {
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: 'Failed to inspect uploaded APK package binary.' });
      }
    }

    const submission: DeveloperSubmission = {
      id: `sub-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      developerName: developerName.trim(),
      developerEmail: developerEmail.trim(),
      appName: appName.trim(),
      packageId: packageId.trim(),
      category: category || 'Tools',
      shortDescription: shortDescription || '',
      fullDescription: fullDescription || '',
      versionName: versionName || '1.0.0',
      minAndroidVersion: minAndroidVersion || 'Android 8.0 (API 26)',
      privacyPolicyUrl: privacyPolicyUrl || '',
      permissions: parsedPermissions,
      authorizationDeclaration: {
        ownsCopyrightOrLicense: true,
        developerAuthorizedDistribution: true,
        termsAccepted: true,
        legalEntityStatement: legalEntityStatement || `Authorized submission by ${developerName}`,
        submissionContactEmail: developerEmail.trim()
      },
      apkFileName: req.file ? req.file.originalname : undefined,
      apkStoragePath,
      apkFileSize,
      apkSha256,
      reviewStatus: 'submitted',
      createdAt: new Date().toISOString()
    };

    const storage = getStorageProvider();
    await storage.addSubmission(submission);
    await storage.addAuditLog(
      'developer',
      developerEmail,
      'SUBMISSION_CREATED',
      submission.id,
      'submission',
      { appName: submission.appName, packageId: submission.packageId }
    );

    res.status(201).json({
      success: true,
      message: 'Developer application submitted successfully. It will be reviewed by an administrator before publication.',
      submissionId: submission.id
    });
  } catch (err: unknown) {
    if (req.file && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch {}
    }
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to process submission', details: message });
  }
});

// Developer submission status lookup (allows developers to verify review status safely)
app.get('/api/submissions/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const storage = getStorageProvider();
    const sub = await storage.getSubmissionById(id);
    if (!sub) {
      return res.status(404).json({ error: 'Submission not found', code: 'SUBMISSION_NOT_FOUND' });
    }
    const emailHeader = (req.headers['x-developer-email'] as string) || (req.query.email as string);
    if (emailHeader && emailHeader.trim().toLowerCase() !== sub.developerEmail.toLowerCase()) {
      return res.status(403).json({ error: 'Unauthorized to view this submission', code: 'FORBIDDEN' });
    }
    res.json({
      submission: {
        id: sub.id,
        appName: sub.appName,
        packageId: sub.packageId,
        category: sub.category,
        versionName: sub.versionName,
        reviewStatus: sub.reviewStatus,
        reviewNotes: sub.reviewNotes,
        hasApk: Boolean(sub.apkStoragePath),
        createdAt: sub.createdAt,
        reviewedAt: sub.reviewedAt
      }
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to retrieve submission', details: message });
  }
});

// Developer submissions list by authenticated email
app.get('/api/developer/submissions', async (req: Request, res: Response) => {
  try {
    const email = (req.query.email as string) || (req.headers['x-developer-email'] as string);
    if (!email || !email.trim()) {
      return res.status(400).json({ error: 'Developer email parameter is required to view submissions.', code: 'EMAIL_REQUIRED' });
    }
    const cleanEmail = email.trim().toLowerCase();
    const storage = getStorageProvider();
    const allSubs = await storage.getSubmissions();
    const subs = allSubs.filter(s => s.developerEmail.toLowerCase() === cleanEmail);
    const sanitized = subs.map(s => ({
      id: s.id,
      appName: s.appName,
      packageId: s.packageId,
      category: s.category,
      versionName: s.versionName,
      reviewStatus: s.reviewStatus,
      reviewNotes: s.reviewNotes,
      hasApk: Boolean(s.apkStoragePath),
      createdAt: s.createdAt,
      reviewedAt: s.reviewedAt
    }));
    res.json({ submissions: sanitized });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to retrieve developer submissions', details: message });
  }
});

// -------------------------------------------------------------
// SECURE ADMINISTRATOR ENDPOINTS
// -------------------------------------------------------------

// Admin login / session creation with rate limiting
app.post('/api/admin/login', adminLoginRateLimiter, async (req: Request, res: Response) => {
  try {
    const { key } = req.body;
    const ip = getClientIp(req);
    const secretStatus = getAdminSecretStatus();
    const isProd = process.env.NODE_ENV === 'production';

    // Strict Fail-Closed in Production: Block login if secret is missing or set to default bootstrap key
    if (isProd && !secretStatus.isValidForAuth) {
      await getStorageProvider().addAuditLog(
        'anonymous',
        ip,
        'ADMIN_LOGIN_CONFIGURATION_BLOCKED',
        'auth',
        'system',
        {
          ipAddress: ip,
          reason: secretStatus.failureReason || 'Production admin authentication is not securely configured.'
        },
        'failure'
      );

      return res.status(503).json({
        error: 'Administrator authentication is temporarily unavailable due to server security configuration. A secure custom ADMIN_INIT_KEY environment variable is required in production.',
        code: 'AUTH_CONFIG_REQUIRED'
      });
    }

    const adminSecret = getAdminSecret();
    const isValidDevToken = !isProd && key === DEFAULT_DEV_ADMIN_TOKEN;
    const isValidKey = Boolean(adminSecret && key === adminSecret);

    if (!key || (!isValidKey && !isValidDevToken)) {
      const rateLimitResult = recordFailedLoginAttempt(ip);
      await getStorageProvider().addAuditLog('anonymous', ip, 'ADMIN_LOGIN_FAILED', 'auth', 'system', {
        keyProvided: Boolean(key),
        ipAddress: ip,
        remainingAttempts: rateLimitResult.remainingAttempts,
        isLocked: rateLimitResult.isLocked
      }, 'failure');

      return res.status(401).json({
        error: rateLimitResult.isLocked
          ? 'Too many failed login attempts. Access temporarily locked for 15 minutes.'
          : 'Invalid administrator access key.',
        code: 'INVALID_CREDENTIALS',
        remainingAttempts: rateLimitResult.remainingAttempts
      });
    }

    clearLoginRateLimit(ip);
    const token = createAdminSessionToken('admin@emappstore.local');

    await getStorageProvider().addAuditLog('admin', 'admin@emappstore.local', 'ADMIN_LOGIN_SUCCESS', 'session', 'system', {
      ipAddress: ip,
      sessionCreated: true
    });

    res.json({
      success: true,
      token,
      user: {
        displayName: 'EM Store Administrator',
        email: 'admin@emappstore.local',
        role: 'admin'
      }
    });
  } catch (err: unknown) {
    const message = sanitizeErrorMessage(err);
    res.status(500).json({ error: 'Authentication failed', details: message });
  }
});

// Admin logout / session invalidation endpoint
app.post('/api/admin/logout', requireAdmin, async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    const adminTokenHeader = req.headers['x-admin-token'] as string;
    let token = '';
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    } else if (adminTokenHeader) {
      token = adminTokenHeader;
    }

    if (token) {
      revokeAdminSession(token);
      await getStorageProvider().addAuditLog('admin', 'admin@emappstore.local', 'ADMIN_LOGOUT', 'session', 'system', {
        sessionRevoked: true
      });
    }

    res.json({ success: true, message: 'Administrator session revoked successfully.' });
  } catch (err: unknown) {
    const message = sanitizeErrorMessage(err);
    res.status(500).json({ error: 'Logout failed', details: message });
  }
});

// Verify admin session
app.get('/api/admin/me', requireAdmin, (_req: Request, res: Response) => {
  res.json({
    authenticated: true,
    user: {
      displayName: 'EM Store Administrator',
      email: 'admin@emappstore.local',
      role: 'admin'
    }
  });
});

// Admin stats
app.get('/api/admin/stats', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storage = getStorageProvider();
    const apps = await storage.getAllApps();
    const publishedApps = apps.filter(a => a.publicationStatus === 'published');
    const draftApps = apps.filter(a => a.publicationStatus === 'draft');
    const submissions = await storage.getSubmissions();
    const pendingSubmissions = submissions.filter(s => s.reviewStatus === 'submitted' || s.reviewStatus === 'under_review');
    const totalDownloads = await storage.getDownloadCount();
    const allReleasesNested = await Promise.all(apps.map(a => storage.getReleasesForApp(a.id)));
    const totalReleases = allReleasesNested.flat().length;
    const recentAuditLogs = await storage.getAuditLogs(10);

    res.json({
      totalApps: apps.length,
      publishedApps: publishedApps.length,
      draftApps: draftApps.length,
      pendingSubmissions: pendingSubmissions.length,
      totalDownloads,
      totalReleases,
      recentAuditLogs
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to retrieve admin statistics', details: message });
  }
});

// Admin get all apps (with releases)
app.get('/api/admin/apps', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storage = getStorageProvider();
    const apps = await storage.getAllApps();
    const result = await Promise.all(apps.map(async app => {
      const releases = await storage.getReleasesForApp(app.id);
      const downloads = await storage.getDownloadCount(app.id);
      return {
        ...app,
        releases,
        downloads
      };
    }));
    res.json({ apps: result });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to get apps', details: message });
  }
});

// Admin create new app (with optional initial APK upload)
app.post('/api/admin/apps', requireAdmin, handleApkUpload, async (req: Request, res: Response) => {
  try {
    const {
      name,
      slug: inputSlug,
      packageId,
      shortDescription,
      fullDescription,
      category,
      iconUrl,
      screenshots,
      publisher,
      developerContact,
      minAndroidVersion,
      targetAndroidVersion,
      permissions,
      privacyPolicyUrl,
      publicationStatus,
      versionName,
      versionCode,
      changelog
    } = req.body;

    const storageConfig = resolveStorageConfig();
    console.log(`[Diagnostic] Admin create/publish request received: ${JSON.stringify({
      name: (name || '').trim(),
      packageId: (packageId || '').trim(),
      requestedStatus: publicationStatus || 'draft',
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);

    if (!name || !packageId || !shortDescription || !publisher) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'Missing required metadata: Application name, package identifier, short description, and publisher are required.'
      });
    }

    // Android package identifier format validation
    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i;
    if (!packageRegex.test(packageId.trim())) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'Invalid Android package identifier format. Example: com.company.app'
      });
    }

    // Slug validation and normalization
    const cleanSlug = (inputSlug || name)
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');

    if (!cleanSlug) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Invalid URL slug provided.' });
    }

    const storageProvider = getStorageProvider();

    // Check for package ID or slug uniqueness
    const existingPackage = await storageProvider.getAppByPackageId(packageId.trim());
    if (existingPackage) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: `An application with package identifier "${packageId}" already exists.` });
    }

    const existingSlug = await storageProvider.getAppByIdOrSlug(cleanSlug);
    if (existingSlug) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: `An application with URL slug "${cleanSlug}" already exists.` });
    }

    const isPublished = publicationStatus === 'published';

    // If attempting to publish directly, ensure APK is uploaded
    if (isPublished && !req.file) {
      return res.status(400).json({
        error: 'An APK package file must be uploaded to submit an application directly as Published. You may choose Save Draft to save metadata first.'
      });
    }

    let parsedScreenshots: string[] = [];
    if (typeof screenshots === 'string') {
      try {
        parsedScreenshots = JSON.parse(screenshots);
      } catch {
        parsedScreenshots = screenshots.split(',').map(s => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(screenshots)) {
      parsedScreenshots = screenshots;
    }

    let parsedPermissions: string[] = [];
    if (typeof permissions === 'string') {
      try {
        parsedPermissions = JSON.parse(permissions);
      } catch {
        parsedPermissions = permissions.split(',').map(s => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(permissions)) {
      parsedPermissions = permissions;
    }

    const appId = `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    let initialRelease: AppRelease | null = null;

    if (req.file) {
      try {
        const inspection = inspectApkFile(req.file.path);
        if (!inspection.isValidZip || !inspection.hasManifest) {
          fs.unlinkSync(req.file.path);
          return res.status(400).json({
            error: inspection.inspectionSummary || 'Uploaded file is not a valid Android APK package.'
          });
        }

        const saved = await getApkStorageProvider().saveApk(path.basename(req.file.path), req.file.path);
        const exists = await getApkStorageProvider().apkExists(saved.storagePath);
        if (!exists) {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(500).json({ error: 'Failed to verify saved APK in storage backend.' });
        }

        const releaseId = `rel-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        initialRelease = {
          id: releaseId,
          appId,
          packageId: packageId.trim(),
          versionName: (versionName || '1.0.0').trim(),
          versionCode: parseInt(versionCode, 10) || 1,
          apkStoragePath: saved.storagePath,
          fileSize: inspection.fileSize,
          sha256: inspection.sha256,
          changelog: (changelog || 'Initial release').trim(),
          releaseStatus: isPublished ? 'published' : 'draft',
          uploadedBy: 'admin',
          verificationStatus: inspection.verificationStatus,
          verificationSummary: inspection.inspectionSummary,
          hasManifest: inspection.hasManifest,
          entryCount: inspection.entryCount,
          createdAt: new Date().toISOString(),
          publishedAt: isPublished ? new Date().toISOString() : undefined
        };
      } catch (err) {
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: 'Failed to inspect uploaded APK package binary.' });
      }
    }

    const newApp: AppRecord = {
      id: appId,
      name: name.trim(),
      slug: cleanSlug,
      packageId: packageId.trim(),
      shortDescription: shortDescription.trim(),
      fullDescription: (fullDescription || shortDescription).trim(),
      category: category || 'Tools',
      iconUrl: iconUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80',
      screenshots: parsedScreenshots,
      developerId: 'admin',
      publisher: publisher.trim(),
      developerContact: developerContact ? developerContact.trim() : undefined,
      currentReleaseId: initialRelease ? initialRelease.id : '',
      publicationStatus: isPublished ? 'published' : 'draft',
      privacyPolicyUrl: privacyPolicyUrl || '/privacy',
      minAndroidVersion: minAndroidVersion || 'Android 8.0 (API 26)',
      targetAndroidVersion: targetAndroidVersion || 'Android 14 (API 34)',
      permissions: parsedPermissions,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await storageProvider.publishAppWithRelease(newApp, initialRelease || undefined);

    console.log(`[Diagnostic] Admin create/publish authoritative write completed: ${JSON.stringify({
      appId: newApp.id,
      packageId: newApp.packageId,
      publicationStatus: newApp.publicationStatus,
      hasInitialRelease: Boolean(initialRelease),
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);

    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'APP_CREATED', newApp.id, 'app', {
      name: newApp.name,
      packageId: newApp.packageId,
      publicationStatus: newApp.publicationStatus,
      hasInitialRelease: Boolean(initialRelease)
    });

    res.status(201).json({
      success: true,
      app: newApp,
      release: initialRelease
    });
  } catch (err: unknown) {
    if (req.file && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch {}
    }
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to create application', details: message });
  }
});

// Admin update app metadata or publication status
app.put('/api/admin/apps/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const storageProvider = getStorageProvider();
    const existing = await storageProvider.getAppById(id);
    if (!existing) {
      return res.status(404).json({ error: 'Application not found', code: 'APP_NOT_FOUND' });
    }

    const storageConfig = resolveStorageConfig();
    console.log(`[Diagnostic] Admin update app request received: ${JSON.stringify({
      appId: id,
      previousStatus: existing.publicationStatus,
      requestedStatus: req.body.publicationStatus !== undefined ? req.body.publicationStatus : '(unchanged)',
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);

    const {
      name,
      slug,
      shortDescription,
      fullDescription,
      category,
      iconUrl,
      screenshots,
      publisher,
      developerContact,
      privacyPolicyUrl,
      minAndroidVersion,
      targetAndroidVersion,
      permissions,
      publicationStatus
    } = req.body;

    const updates: Partial<AppRecord> = {};

    if (name !== undefined) updates.name = String(name).trim();
    if (slug !== undefined) updates.slug = String(slug).trim().toLowerCase();
    if (shortDescription !== undefined) updates.shortDescription = String(shortDescription).trim();
    if (fullDescription !== undefined) updates.fullDescription = String(fullDescription).trim();
    if (category !== undefined) updates.category = String(category).trim();
    if (iconUrl !== undefined) updates.iconUrl = String(iconUrl).trim();
    if (screenshots !== undefined) updates.screenshots = Array.isArray(screenshots) ? screenshots : [];
    if (publisher !== undefined) updates.publisher = String(publisher).trim();
    if (developerContact !== undefined) updates.developerContact = String(developerContact).trim();
    if (privacyPolicyUrl !== undefined) updates.privacyPolicyUrl = String(privacyPolicyUrl).trim();
    if (minAndroidVersion !== undefined) updates.minAndroidVersion = String(minAndroidVersion).trim();
    if (targetAndroidVersion !== undefined) updates.targetAndroidVersion = String(targetAndroidVersion).trim();
    if (permissions !== undefined) updates.permissions = Array.isArray(permissions) ? permissions : [];

    // CRITICAL: Do not change publication status as a side effect of metadata edits
    if (publicationStatus !== undefined && publicationStatus !== null && String(publicationStatus).trim() !== '') {
      const validStatuses = ['published', 'draft', 'archived', 'unlisted'];
      const cleanStatus = String(publicationStatus).trim().toLowerCase() as 'published' | 'draft' | 'archived' | 'unlisted';
      if (!validStatuses.includes(cleanStatus)) {
        return res.status(400).json({
          error: `Invalid publicationStatus. Allowed values: ${validStatuses.join(', ')}`,
          code: 'INVALID_STATUS'
        });
      }
      if (cleanStatus === 'published') {
        const releases = await storageProvider.getReleasesForApp(id);
        const hasValidRelease = releases.some(r => r.releaseStatus === 'published' || r.releaseStatus === 'approved');
        if (!hasValidRelease) {
          return res.status(400).json({
            error: 'Cannot publish an application that does not have an uploaded, verified APK release package.'
          });
        }
      }
      updates.publicationStatus = cleanStatus;
    } else {
      // Retain current publication status explicitly
      updates.publicationStatus = existing.publicationStatus;
    }

    const updated = await storageProvider.updateApp(id, updates);
    console.log(`[Diagnostic] Admin update app authoritative write completed: ${JSON.stringify({
      appId: id,
      newStatus: updated?.publicationStatus,
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'APP_UPDATED', id, 'app', updates, 'success');
    res.json({ success: true, app: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to update application', details: message });
  }
});

// Admin delete app
app.delete('/api/admin/apps/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const deleteFiles = req.query.deleteFiles === 'true';
    const storageProvider = getStorageProvider();

    const existing = await storageProvider.getAppById(id);
    if (!existing) {
      return res.status(404).json({ error: 'Application not found' });
    }

    if (deleteFiles) {
      const releases = await storageProvider.getReleasesForApp(id);
      for (const rel of releases) {
        try {
          await getApkStorageProvider().deleteApk(rel.apkStoragePath);
        } catch (e) {
          console.error(`Failed to delete APK file for release ${rel.id}:`, e);
        }
      }
    }

    await storageProvider.deleteApp(id, deleteFiles);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'APP_DELETED', id, 'app', { deleteFiles });
    res.json({ success: true, message: `Application ${existing.name} removed successfully.` });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to delete application', details: message });
  }
});

// Admin get releases for an application
app.get('/api/admin/apps/:id/releases', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const storageProvider = getStorageProvider();
    const app = await storageProvider.getAppById(id);
    if (!app) {
      return res.status(404).json({ error: 'Application not found' });
    }

    const releases = await storageProvider.getReleasesForApp(id);
    res.json({ releases, currentReleaseId: app.currentReleaseId });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to get releases', details: message });
  }
});

// Admin upload new release APK for an application
app.post('/api/admin/apps/:id/releases', requireAdmin, handleApkUpload, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { versionName, versionCode, changelog, releaseStatus, signatureCertSha256 } = req.body;
    const storageProvider = getStorageProvider();

    const app = await storageProvider.getAppById(id);
    if (!app) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(404).json({ error: 'Application not found' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'An APK file must be uploaded.' });
    }

    // Deep structural inspection
    let inspection;
    try {
      inspection = inspectApkFile(req.file.path);
    } catch (e) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Failed to inspect APK binary container structure.' });
    }

    if (!inspection.isValidZip || !inspection.hasManifest) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: inspection.inspectionSummary || 'Uploaded file failed APK manifest verification.'
      });
    }

    const existingReleases = await storageProvider.getReleasesForApp(app.id);
    const highestCode = existingReleases.length > 0 ? Math.max(...existingReleases.map(r => r.versionCode)) : 0;

    let parsedVersionCode: number;
    if (versionCode !== undefined && versionCode !== null && String(versionCode).trim() !== '') {
      const parsed = parseInt(String(versionCode), 10);
      if (isNaN(parsed) || parsed <= 0) {
        if (req.file) fs.unlinkSync(req.file.path);
        return res.status(400).json({
          error: 'Invalid versionCode. Version code must be a positive integer greater than 0.'
        });
      }
      parsedVersionCode = parsed;
    } else {
      parsedVersionCode = highestCode + 1;
    }

    if (existingReleases.some(r => r.versionCode === parsedVersionCode)) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: `A release with versionCode ${parsedVersionCode} already exists for this application. Version codes must be strictly unique.`
      });
    }

    const saved = await getApkStorageProvider().saveApk(path.basename(req.file.path), req.file.path);
    const exists = await getApkStorageProvider().apkExists(saved.storagePath);
    if (!exists) {
      if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      return res.status(500).json({ error: 'Failed to verify saved APK in storage backend.' });
    }

    const isPublished = releaseStatus === 'published';

    const release: AppRelease = {
      id: `rel-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      appId: app.id,
      packageId: app.packageId,
      versionName: (versionName || '1.0.0').trim(),
      versionCode: parsedVersionCode,
      apkStoragePath: saved.storagePath,
      fileSize: inspection.fileSize,
      sha256: inspection.sha256,
      changelog: (changelog || 'Performance improvements and bug fixes.').trim(),
      releaseStatus: isPublished ? 'published' : 'approved',
      uploadedBy: 'admin',
      signatureCertSha256: signatureCertSha256 || undefined,
      verificationStatus: inspection.verificationStatus,
      verificationSummary: inspection.inspectionSummary,
      hasManifest: inspection.hasManifest,
      entryCount: inspection.entryCount,
      createdAt: new Date().toISOString(),
      publishedAt: isPublished ? new Date().toISOString() : undefined
    };

    await storageProvider.addRelease(release);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'RELEASE_UPLOADED', release.id, 'release', {
      appId: app.id,
      versionName: release.versionName,
      versionCode: release.versionCode,
      sha256: release.sha256,
      releaseStatus: release.releaseStatus
    });

    res.status(201).json({
      success: true,
      release,
      compatibilityWarning: parsedVersionCode <= highestCode
        ? `Warning: Version code (${parsedVersionCode}) is not higher than existing highest release (${highestCode}). Android devices will reject in-place updates unless version code increases.`
        : null
    });
  } catch (err: unknown) {
    if (req.file && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch {}
    }
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to upload release', details: message });
  }
});

// Admin update release status or set as current release
app.put('/api/admin/apps/:id/releases/:releaseId', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id, releaseId } = req.params;
    const { releaseStatus, setCurrent } = req.body;
    const storageProvider = getStorageProvider();

    const release = await storageProvider.getReleaseById(releaseId);
    if (!release || release.appId !== id) {
      return res.status(404).json({ error: 'Release not found for this application' });
    }

    if (releaseStatus) {
      await storageProvider.updateRelease(releaseId, {
        releaseStatus,
        publishedAt: releaseStatus === 'published' ? (release.publishedAt || new Date().toISOString()) : release.publishedAt
      });
    }

    if (setCurrent === true || setCurrent === 'true') {
      const targetStatus = releaseStatus || release.releaseStatus;
      if (targetStatus !== 'published') {
        return res.status(400).json({
          error: 'Cannot set an unpublished release as the current active release. The release must be in published status.'
        });
      }
      await storageProvider.setAppCurrentRelease(id, releaseId);
    }

    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'RELEASE_UPDATED', releaseId, 'release', {
      releaseStatus,
      setCurrent
    });

    res.json({ success: true, release: await storageProvider.getReleaseById(releaseId) });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to update release', details: message });
  }
});

// Admin delete release
app.delete('/api/admin/apps/:id/releases/:releaseId', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id, releaseId } = req.params;
    const deleteFile = req.query.deleteFile === 'true';
    const storageProvider = getStorageProvider();

    const release = await storageProvider.getReleaseById(releaseId);
    if (!release || release.appId !== id) {
      return res.status(404).json({ error: 'Release not found for this application' });
    }

    if (deleteFile) {
      try {
        await getApkStorageProvider().deleteApk(release.apkStoragePath);
      } catch (e) {
        console.error(`Failed to delete APK file for release ${release.id}:`, e);
      }
    }

    await storageProvider.deleteRelease(releaseId, deleteFile);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'RELEASE_DELETED', releaseId, 'release', { deleteFile });
    res.json({ success: true, message: 'Release deleted successfully.' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to delete release', details: message });
  }
});

// Admin storage status and diagnostics endpoint
app.get('/api/admin/storage-status', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const health = await getStorageHealth();
    const storage = getStorageProvider();
    const apkStorage = getApkStorageProvider();
    const apps = await storage.getAllApps();
    const tombstones = await storage.getDeletedAppIds();
    const auditLogs = await storage.getAuditLogs(10);

    res.json({
      health,
      backend: storage.backendType,
      apkBackend: apkStorage.backendType,
      stats: {
        totalApps: apps.length,
        tombstonedDeletedApps: tombstones.length,
        tombstoneIds: tombstones,
        recentAuditCount: auditLogs.length
      },
      environment: {
        nodeEnv: process.env.NODE_ENV || 'development',
        storageBackend: process.env.STORAGE_BACKEND || 'local',
        gcsBucketConfigured: Boolean(process.env.GCS_APK_BUCKET),
        gcsBucketName: process.env.GCS_APK_BUCKET || null,
        gcpProjectConfigured: Boolean(process.env.GCP_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT),
        firestoreDatabaseId: process.env.FIRESTORE_DATABASE_ID || '(default)'
      }
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: 'Failed to retrieve storage status', details: message });
  }
});

// Admin data integrity check endpoint
app.get('/api/admin/data-integrity', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storageProvider = getStorageProvider();
    const snapshot = await storageProvider.getSnapshot();
    const report = validateDatabaseIntegrity(snapshot);
    res.json(report);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: 'Failed to run data integrity audit', details: message });
  }
});

// Admin migration plan and dry-run endpoint
app.get('/api/admin/migration/dry-run', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storageProvider = getStorageProvider();
    const snapshot = await storageProvider.getSnapshot();
    const plan = generateMigrationPlan(snapshot);
    res.json(plan);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: 'Failed to generate migration plan', details: message });
  }
});

// Admin live cloud readiness evaluation
app.get('/api/admin/cloud-readiness', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const readiness = await checkCloudReadiness();
    res.json(readiness);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: 'Failed to evaluate cloud readiness', details: message });
  }
});

// Admin developer submissions review
app.get('/api/admin/submissions', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storageProvider = getStorageProvider();
    const submissions = await storageProvider.getSubmissions();
    res.json({ submissions });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to get submissions', details: message });
  }
});

// Admin review action (approve / reject / request changes)
app.put('/api/admin/submissions/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reviewStatus, reviewNotes } = req.body;
    const storageProvider = getStorageProvider();

    const allowedStatuses = ['submitted', 'under_review', 'approved', 'rejected', 'published', 'suspended'];
    if (!reviewStatus || !allowedStatuses.includes(reviewStatus)) {
      return res.status(400).json({
        error: `Invalid reviewStatus. Allowed values: ${allowedStatuses.join(', ')}`,
        code: 'INVALID_STATUS'
      });
    }

    const sub = await storageProvider.getSubmissionById(id);
    if (!sub) {
      return res.status(404).json({ error: 'Submission not found', code: 'SUBMISSION_NOT_FOUND' });
    }

    const previousStatus = sub.reviewStatus;
    const updated = await storageProvider.updateSubmission(id, {
      reviewStatus,
      reviewNotes: reviewNotes !== undefined ? reviewNotes : sub.reviewNotes,
      reviewerId: 'admin'
    });

    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', `SUBMISSION_${reviewStatus.toUpperCase()}`, id, 'submission', {
      previousStatus,
      newStatus: reviewStatus,
      reviewNotes
    }, 'success');

    res.json({ success: true, submission: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to update submission review status', details: message });
  }
});

// Admin delete submission
app.delete('/api/admin/submissions/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const storageProvider = getStorageProvider();
    const sub = await storageProvider.getSubmissionById(id);
    if (!sub) {
      return res.status(404).json({ error: 'Submission not found', code: 'SUBMISSION_NOT_FOUND' });
    }

    await storageProvider.deleteSubmission(id);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'SUBMISSION_DELETED', id, 'submission', {
      appName: sub.appName,
      packageId: sub.packageId
    }, 'success');

    res.json({ success: true, message: `Submission ${id} deleted successfully.` });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to delete submission', details: message });
  }
});

// Admin convert approved submission into published public App
app.post('/api/admin/submissions/:id/publish', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { overrideOwnership } = req.body;
    const storageProvider = getStorageProvider();

    const sub = await storageProvider.getSubmissionById(id);
    if (!sub) {
      return res.status(404).json({ error: 'Submission not found', code: 'SUBMISSION_NOT_FOUND' });
    }

    const storageConfig = resolveStorageConfig();
    console.log(`[Diagnostic] Admin publish submission request received: ${JSON.stringify({
      submissionId: id,
      packageId: sub.packageId,
      appName: sub.appName,
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);

    if (sub.reviewStatus !== 'approved') {
      return res.status(400).json({
        error: 'Only submissions marked as approved can be published to the catalog.',
        code: 'NOT_APPROVED'
      });
    }

    // Verify APK binary is strictly present in storage backend
    if (!sub.apkStoragePath) {
      return res.status(400).json({
        error: 'Cannot publish submission without an uploaded APK package file.',
        code: 'MISSING_APK_PATH'
      });
    }

    const apkStorage = getApkStorageProvider();
    const exists = await apkStorage.apkExists(sub.apkStoragePath);
    if (!exists) {
      return res.status(400).json({
        error: 'Submission APK package file not found in storage. Cannot publish without verified binary.',
        code: 'APK_NOT_IN_STORAGE'
      });
    }

    const existingApp = await storageProvider.getAppByPackageId(sub.packageId);
    const releaseId = `rel-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    let targetAppId: string;
    let targetApp: AppRecord;

    if (existingApp) {
      // Check developer ownership conflict
      if (
        existingApp.developerId &&
        existingApp.developerId !== 'admin' &&
        existingApp.developerId.toLowerCase() !== sub.developerEmail.toLowerCase() &&
        (!existingApp.developerContact || existingApp.developerContact.toLowerCase() !== sub.developerEmail.toLowerCase())
      ) {
        if (!overrideOwnership) {
          return res.status(409).json({
            error: `Application ${existingApp.name} (${existingApp.packageId}) belongs to developer ${existingApp.developerId}. Explicit administrator overrideConfirmation (overrideOwnership: true) is required to reassign this application.`,
            code: 'OWNERSHIP_CONFLICT'
          });
        }
      }

      targetAppId = existingApp.id;
      const existingReleases = await storageProvider.getReleasesForApp(existingApp.id);
      const highestCode = existingReleases.length > 0 ? Math.max(...existingReleases.map(r => r.versionCode)) : 0;

      const newRelease: AppRelease = {
        id: releaseId,
        appId: targetAppId,
        packageId: sub.packageId,
        versionName: sub.versionName || '1.0.0',
        versionCode: highestCode + 1,
        apkStoragePath: sub.apkStoragePath,
        fileSize: sub.apkFileSize || 1024 * 1024,
        sha256: sub.apkSha256 || crypto.createHash('sha256').update(sub.packageId).digest('hex').toLowerCase(),
        changelog: 'Developer submission release.',
        releaseStatus: 'published',
        uploadedBy: sub.developerEmail,
        verificationStatus: 'verified',
        verificationSummary: 'Developer submission verified and authorized by administrator.',
        hasManifest: true,
        createdAt: new Date().toISOString(),
        publishedAt: new Date().toISOString()
      };

      await storageProvider.addRelease(newRelease);
      await storageProvider.updateApp(targetAppId, {
        currentReleaseId: releaseId,
        publicationStatus: 'published',
        updatedAt: new Date().toISOString()
      });
      targetApp = (await storageProvider.getAppById(targetAppId))!;
    } else {
      const slug = sub.appName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
      targetAppId = `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      const newApp: AppRecord = {
        id: targetAppId,
        name: sub.appName,
        slug,
        packageId: sub.packageId,
        shortDescription: sub.shortDescription,
        fullDescription: sub.fullDescription || sub.shortDescription,
        category: sub.category,
        iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80',
        screenshots: [],
        developerId: sub.developerEmail,
        publisher: sub.developerName,
        developerContact: sub.developerEmail,
        currentReleaseId: releaseId,
        publicationStatus: 'published',
        privacyPolicyUrl: sub.privacyPolicyUrl || '/privacy',
        minAndroidVersion: sub.minAndroidVersion,
        permissions: sub.permissions,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const newRelease: AppRelease = {
        id: releaseId,
        appId: targetAppId,
        packageId: sub.packageId,
        versionName: sub.versionName || '1.0.0',
        versionCode: 1,
        apkStoragePath: sub.apkStoragePath,
        fileSize: sub.apkFileSize || 1024 * 1024,
        sha256: sub.apkSha256 || crypto.createHash('sha256').update(sub.packageId).digest('hex').toLowerCase(),
        changelog: 'Initial public release on EM App Store.',
        releaseStatus: 'published',
        uploadedBy: sub.developerEmail,
        verificationStatus: 'verified',
        verificationSummary: 'Developer submission verified and authorized by administrator.',
        hasManifest: true,
        createdAt: new Date().toISOString(),
        publishedAt: new Date().toISOString()
      };

      await storageProvider.publishAppWithRelease(newApp, newRelease);
      targetApp = newApp;
    }

    await storageProvider.updateSubmission(id, { reviewStatus: 'published' });
    console.log(`[Diagnostic] Admin publish submission authoritative write completed: ${JSON.stringify({
      submissionId: id,
      appId: targetAppId,
      packageId: sub.packageId,
      releaseId,
      publicationStatus: 'published',
      storageBackend: storageConfig.backend,
      timestamp: new Date().toISOString()
    })}`);
    await storageProvider.addAuditLog('admin', 'admin@emappstore.local', 'SUBMISSION_PUBLISHED_TO_CATALOG', sub.id, 'app', {
      appId: targetAppId,
      releaseId,
      existingAppUpdated: Boolean(existingApp)
    }, 'success');

    res.json({
      success: true,
      app: targetApp,
      release: await storageProvider.getReleaseById(releaseId)
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to publish submission', details: message });
  }
});

// Admin audit logs
app.get('/api/admin/audit-logs', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const storageProvider = getStorageProvider();
    const logs = await storageProvider.getAuditLogs(100);
    res.json({ logs });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: 'Failed to get audit logs', details: message });
  }
});

// Explicit 404 handler for all unmatched /api routes
// MUST precede Vite dev server middleware so /api requests NEVER return index.html (<!doctype html>)
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({
    error: `API endpoint ${req.method} ${req.originalUrl} not found.`,
    code: 'ENDPOINT_NOT_FOUND'
  });
});

// Global Express error handler for API routes and upload errors
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(`[API Error] ${req.method} ${req.originalUrl}:`, err);

  if (res.headersSent) {
    return next(err);
  }

  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      const maxMb = process.env.MAX_UPLOAD_MB || '150';
      return res.status(413).json({
        error: `Uploaded APK file exceeds the allowed upload limit of ${maxMb}MB.`,
        code: 'LIMIT_FILE_SIZE'
      });
    }
    return res.status(400).json({
      error: `Upload error (${err.code}): ${err.message}`,
      code: err.code
    });
  }

  const statusCode = typeof err.statusCode === 'number'
    ? err.statusCode
    : typeof err.status === 'number'
    ? err.status
    : 500;

  const isProd = process.env.NODE_ENV === 'production';
  return res.status(statusCode).json({
    error: isProd ? 'An unexpected server error occurred.' : sanitizeErrorMessage(err),
    code: err.code || 'INTERNAL_ERROR'
  });
});

// -------------------------------------------------------------
// VITE DEV SERVER / STATIC FILE SERVING
// -------------------------------------------------------------
async function startServer() {
  await initializeStorage();
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EM App Store server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start EM App Store server:', err);
  process.exit(1);
});
