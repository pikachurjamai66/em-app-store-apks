import React from 'react';
import { BrandLogo } from './BrandLogo.tsx';
import { ShieldCheck, Smartphone, CheckCircle, FileText, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 text-slate-400 text-sm mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-4 md:col-span-1">
            <BrandLogo size="md" variant="full" />
            <p className="text-xs text-slate-400 leading-relaxed">
              Official Android distribution platform where administrators publish first-party applications
              and authorized developer software with explicit legal distribution consent.
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Cryptographic SHA-256 integrity & permission verification</span>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Application Catalog
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('/apps')}
                  className="hover:text-blue-400 transition-colors"
                >
                  All Applications
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/categories')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Categories
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/latest')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Latest Releases
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/recently-updated')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Recently Updated
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/popular')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Popular Applications
                </button>
              </li>
            </ul>
          </div>

          {/* Developers & Android */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Platform & Developers
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('/android-client')}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>EM Store Android Client</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/submit')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Submit an Application
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/developer-info')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Developer Guidelines & Verification
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/admin')}
                  className="hover:text-blue-400 transition-colors text-slate-500"
                >
                  Administrator Portal
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Takedown */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Compliance & Legal
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('/privacy')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/terms')}
                  className="hover:text-blue-400 transition-colors"
                >
                  Terms of Service
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/takedown')}
                  className="hover:text-blue-400 transition-colors flex items-center gap-1"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>Copyright & Takedown Policy</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/contact')}
                  className="hover:text-blue-400 transition-colors flex items-center gap-1"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Contact Platform Team</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            &copy; {new Date().getFullYear()} EM App Store. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1 text-slate-300">
              <CheckCircle className="w-3.5 h-3.5 text-blue-400" />
              Verified APK Repository
            </span>
            <span>&bull;</span>
            <span>Transparent Package Installation</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
