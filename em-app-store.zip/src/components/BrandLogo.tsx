import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'full' | 'short' | 'monogram';
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  variant = 'full',
  className = ''
}) => {
  const iconSizeClasses = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-9 h-9 text-sm',
    lg: 'w-12 h-12 text-lg'
  };

  const titleSizeClasses = {
    sm: 'text-base',
    md: 'text-lg',
    lg: 'text-2xl'
  };

  return (
    <div className={`flex items-center gap-2.5 font-sans select-none ${className}`}>
      {/* Monogram emblem */}
      <div
        className={`${iconSizeClasses[size]} rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-slate-900 flex items-center justify-center font-black tracking-wider text-white shadow-md shadow-blue-500/20 border border-blue-400/30 flex-shrink-0`}
      >
        <span className="bg-gradient-to-b from-white to-blue-100 bg-clip-text text-transparent drop-shadow-sm font-mono">
          EM
        </span>
      </div>

      {variant !== 'monogram' && (
        <div className="flex flex-col leading-none">
          <div className="flex items-center gap-1.5">
            <span className={`${titleSizeClasses[size]} font-bold tracking-tight text-white`}>
              EM <span className="text-blue-400">{variant === 'short' ? 'Store' : 'App Store'}</span>
            </span>
            {variant === 'short' && (
              <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Android
              </span>
            )}
          </div>
          <span className="text-[10px] uppercase tracking-widest text-slate-400 font-medium mt-0.5">
            Verified Distribution Platform
          </span>
        </div>
      )}
    </div>
  );
};
