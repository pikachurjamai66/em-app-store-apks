import React from 'react';
import { AppItem } from '../types/index.ts';
import { Download, ShieldCheck, Tag, HardDrive, Calendar } from 'lucide-react';

interface AppCardProps {
  app: AppItem;
  onSelect: (app: AppItem) => void;
  onQuickDownload?: (app: AppItem, e: React.MouseEvent) => void;
}

export const AppCard: React.FC<AppCardProps> = ({ app, onSelect, onQuickDownload }) => {
  const formatBytes = (bytes: number): string => {
    if (!bytes || bytes === 0) return 'N/A';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1) return `${mb.toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  const formatDate = (isoString: string): string => {
    try {
      return new Date(isoString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div
      onClick={() => onSelect(app)}
      className="group relative flex flex-col justify-between bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-xl p-4 transition-all duration-200 shadow-sm hover:shadow-lg hover:shadow-blue-500/5 cursor-pointer"
    >
      <div>
        {/* Top Header: Icon, Name, Category */}
        <div className="flex items-start gap-3.5">
          <img
            src={app.iconUrl}
            alt={app.name}
            className="w-14 h-14 rounded-xl object-cover bg-slate-800 border border-slate-700/60 shadow-sm flex-shrink-0 group-hover:scale-105 transition-transform"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&h=128&fit=crop&q=80';
            }}
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors truncate">
                {app.name}
              </h3>
            </div>

            <p className="text-xs text-slate-400 truncate mt-0.5">
              by <span className="text-slate-300 font-medium">{app.publisher}</span>
            </p>

            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700/70">
                <Tag className="w-3 h-3 text-blue-400" />
                {app.category}
              </span>

              {app.isDemonstration && (
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                  Demo
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Short Description */}
        <p className="text-xs text-slate-400 line-clamp-2 mt-3 leading-relaxed">
          {app.shortDescription}
        </p>
      </div>

      {/* Footer Info & Download Action */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <span className="font-mono text-slate-300 font-semibold text-[11px]">
              v{app.currentRelease?.versionName || '1.0.0'}
            </span>
            <span className="text-slate-600">&bull;</span>
            <span className="flex items-center gap-1 text-[11px] text-slate-400">
              <HardDrive className="w-3 h-3 text-slate-400" />
              {app.currentRelease?.fileSize ? formatBytes(app.currentRelease.fileSize) : 'APK'}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[10px] text-slate-400">
            <Calendar className="w-3 h-3" />
            <span>Updated {formatDate(app.updatedAt)}</span>
          </div>
        </div>

        {/* Quick download button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (onQuickDownload) {
              onQuickDownload(app, e);
            } else {
              onSelect(app);
            }
          }}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium flex items-center gap-1.5 shadow-sm transition-colors text-xs flex-shrink-0"
          title="Download APK package"
        >
          <Download className="w-3.5 h-3.5" />
          <span>APK</span>
        </button>
      </div>
    </div>
  );
};
