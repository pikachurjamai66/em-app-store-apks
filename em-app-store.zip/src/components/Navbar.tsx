import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo.tsx';
import {
  Search,
  Menu,
  X,
  Smartphone,
  ShieldCheck,
  Upload,
  Layers,
  Sparkles,
  TrendingUp,
  Clock,
  Lock
} from 'lucide-react';
import { useAdmin } from '../context/AdminContext.tsx';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onSearch: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate, onSearch }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const { isAuthenticated } = useAdmin();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
      setMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { label: 'All Apps', path: '/apps', icon: Layers },
    { label: 'Categories', path: '/categories', icon: Layers },
    { label: 'Latest', path: '/latest', icon: Sparkles },
    { label: 'Popular', path: '/popular', icon: TrendingUp },
    { label: 'Updated', path: '/recently-updated', icon: Clock },
    { label: 'Submit App', path: '/submit', icon: Upload }
  ];

  const handleNavClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <div
            className="cursor-pointer transition-opacity hover:opacity-90 flex-shrink-0"
            onClick={() => handleNavClick('/')}
          >
            <BrandLogo size="md" variant="full" />
          </div>

          {/* Desktop Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden md:flex flex-1 max-w-md relative items-center"
          >
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search apps, package IDs, publishers..."
              className="w-full pl-9 pr-4 py-1.5 text-sm rounded-lg bg-slate-900 border border-slate-700/80 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />
          </form>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 text-sm font-medium">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleNavClick(link.path)}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    isActive
                      ? 'bg-blue-600/20 text-blue-400 font-semibold border border-blue-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 opacity-80" />
                  <span>{link.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden sm:flex items-center gap-2">
            {/* Android Client Link Button */}
            <button
              onClick={() => handleNavClick('/android-client')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 border transition-all ${
                currentPath === '/android-client'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-emerald-500/50 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>EM Store Android</span>
            </button>

            {/* Admin Console Link */}
            <button
              onClick={() => handleNavClick('/admin')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1.5 border transition-all ${
                currentPath.startsWith('/admin')
                  ? 'bg-blue-600 text-white border-blue-500'
                  : isAuthenticated
                  ? 'bg-blue-950/60 text-blue-300 border-blue-700/60 hover:bg-blue-900/60'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isAuthenticated ? 'Admin Active' : 'Admin'}</span>
            </button>
          </div>

          {/* Mobile action buttons & menu hamburger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={() => handleNavClick('/android-client')}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 active:scale-95 transition-transform"
              title="Download EM Store Android APK"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>Get APK</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Tablet hamburger button (sm to md) */}
          <div className="hidden sm:flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="md:hidden pb-3">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search apps or package IDs..."
              className="w-full pl-9 pr-4 py-2 text-sm rounded-lg bg-slate-900 border border-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </form>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-slate-950 px-4 pt-2 pb-6 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = currentPath === link.path;
            return (
              <button
                key={link.path}
                onClick={() => handleNavClick(link.path)}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${
                  isActive
                    ? 'bg-blue-600/20 text-blue-400 font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{link.label}</span>
              </button>
            );
          })}

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <button
              onClick={() => handleNavClick('/android-client')}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium bg-emerald-950/40 text-emerald-300 border border-emerald-800/40"
            >
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>EM Store (Android Client)</span>
              </div>
              <span className="text-xs font-mono bg-emerald-900/60 px-1.5 py-0.5 rounded text-emerald-200">
                APK
              </span>
            </button>

            <button
              onClick={() => handleNavClick('/developer-info')}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Developer Guidelines</span>
            </button>

            <button
              onClick={() => handleNavClick('/admin')}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-blue-400 bg-blue-950/30 border border-blue-900/50"
            >
              <Lock className="w-4 h-4" />
              <span>{isAuthenticated ? 'Administrator Dashboard (Logged In)' : 'Admin Dashboard'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
