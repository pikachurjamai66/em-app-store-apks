import React from 'react';
import { ArrowLeft, Compass } from 'lucide-react';

interface NotFoundPageProps {
  onNavigateHome: () => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigateHome }) => {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center space-y-6">
      <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 text-blue-400 flex items-center justify-center mx-auto shadow-inner">
        <Compass className="w-8 h-8" />
      </div>
      <div className="space-y-2">
        <h1 className="text-4xl font-extrabold text-white tracking-tight">404</h1>
        <h2 className="text-lg font-bold text-slate-200">Page or Application Not Found</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          The requested route does not exist in the EM App Store catalog or may have been unlisted by the publisher.
        </p>
      </div>
      <div>
        <button
          onClick={onNavigateHome}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 shadow-md transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to EM App Store Home</span>
        </button>
      </div>
    </div>
  );
};
