import React, { useState, useMemo } from 'react';
import { AppItem } from '../types/index.ts';
import { AppCard } from '../components/AppCard.tsx';
import { Search, Filter, SortAsc, Sparkles, TrendingUp, Clock, Layers, X } from 'lucide-react';

interface AppsPageProps {
  apps: AppItem[];
  initialSort?: 'latest' | 'updated' | 'popular' | 'name';
  initialCategory?: string;
  initialSearch?: string;
  pageTitle?: string;
  pageSubtitle?: string;
  onSelectApp: (app: AppItem) => void;
  onQuickDownload: (app: AppItem, e: React.MouseEvent) => void;
}

export const AppsPage: React.FC<AppsPageProps> = ({
  apps,
  initialSort = 'latest',
  initialCategory = 'All',
  initialSearch = '',
  pageTitle = 'All Applications',
  pageSubtitle = 'Explore our catalog of verified Android software and developer packages.',
  onSelectApp,
  onQuickDownload
}) => {
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [sortBy, setSortBy] = useState<'latest' | 'updated' | 'popular' | 'name'>(initialSort);

  // Available categories derived from data
  const categories = useMemo(() => {
    const list = Array.from(new Set(apps.map(a => a.category))).sort();
    return ['All', ...list];
  }, [apps]);

  // Filtered and sorted apps
  const filteredApps = useMemo(() => {
    let result = [...apps];

    // Category filter
    if (selectedCategory && selectedCategory !== 'All') {
      result = result.filter(
        a => a.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        a =>
          a.name.toLowerCase().includes(q) ||
          a.shortDescription.toLowerCase().includes(q) ||
          a.packageId.toLowerCase().includes(q) ||
          a.publisher.toLowerCase().includes(q)
      );
    }

    // Sorting
    if (sortBy === 'popular') {
      result.sort((a, b) => b.downloads - a.downloads);
    } else if (sortBy === 'updated') {
      result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      // latest
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [apps, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="border-b border-slate-800 pb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {pageTitle}
        </h1>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl">
          {pageSubtitle}
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        {/* Search input */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, package ID, or developer..."
            className="w-full pl-9 pr-8 py-2 text-sm rounded-lg bg-slate-900 border border-slate-700/80 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 p-1 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Controls: Category & Sort */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Category Select */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 text-xs sm:text-sm rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'All Categories' : c}
                </option>
              ))}
            </select>
          </div>

          {/* Sort Select */}
          <div className="flex items-center gap-2">
            <SortAsc className="w-4 h-4 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 text-xs sm:text-sm rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="latest">Latest Added</option>
              <option value="updated">Recently Updated</option>
              <option value="popular">Most Downloaded</option>
              <option value="name">Alphabetical</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results Count & Badges */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <div>
          Showing <span className="font-semibold text-white">{filteredApps.length}</span>{' '}
          {filteredApps.length === 1 ? 'application' : 'applications'}
        </div>
        {(selectedCategory !== 'All' || searchQuery) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="text-blue-400 hover:text-blue-300 underline"
          >
            Reset filters
          </button>
        )}
      </div>

      {/* Grid of Apps */}
      {filteredApps.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredApps.map((app) => (
            <AppCard
              key={app.id}
              app={app}
              onSelect={onSelectApp}
              onQuickDownload={onQuickDownload}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900/30 rounded-2xl border border-slate-800/80 p-8 space-y-4">
          <Layers className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-lg font-bold text-white">No applications match your criteria</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Try adjusting your search terms or clearing the category filter to browse available APK releases.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
          >
            Clear all filters
          </button>
        </div>
      )}
    </div>
  );
};
