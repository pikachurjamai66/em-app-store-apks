import React from 'react';
import { ShieldCheck, Upload, FileText, CheckCircle2, AlertCircle, ArrowRight, Smartphone, Key } from 'lucide-react';

interface DeveloperInfoPageProps {
  onNavigate: (path: string) => void;
}

export const DeveloperInfoPage: React.FC<DeveloperInfoPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Developer Distribution & Authorization Standards</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">
          Developer Guidelines & Submission Policy
        </h1>
        <p className="text-sm text-slate-400">
          Learn how EM App Store reviews, verifies, and distributes Android applications while respecting copyright and user privacy.
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <h2 className="text-base font-bold text-white">Explicit Authorization Only</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            EM App Store never scrapes or mirrors third-party APKs without authorization. Submissions require explicit copyright proof and distributor consent declarations from verified publishers.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
            <Key className="w-5 h-5" />
          </div>
          <h2 className="text-base font-bold text-white">Cryptographic Release Signing</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            All submitted APKs must be signed using standard v2/v3 Android release keystores. When updating an existing app, the signing identity and package ID must match to permit seamless in-place updates.
          </p>
        </div>
      </div>

      {/* Submission Criteria Checklist */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <h2 className="text-lg font-bold text-white">Technical & Policy Checklist</h2>

        <div className="space-y-4 text-xs text-slate-300">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
              ✓
            </div>
            <div>
              <strong className="text-white block text-sm">Valid Android Package ID</strong>
              Reverse-DNS format (e.g. <code className="text-blue-400">com.company.appname</code>). Must be unique and cannot impersonate existing trademarks.
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
              ✓
            </div>
            <div>
              <strong className="text-white block text-sm">Monotonically Increasing Version Code</strong>
              For in-place updates, the <code className="text-blue-400">versionCode</code> integer in <code className="text-slate-300">build.gradle</code> must be strictly greater than the preceding published release.
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
              ✓
            </div>
            <div>
              <strong className="text-white block text-sm">Transparent Android Permissions</strong>
              Disclose all requested Android manifest permissions (such as camera, storage, network, or notifications). Invasive permissions without functional justification will result in submission rejection.
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
              ✓
            </div>
            <div>
              <strong className="text-white block text-sm">Public Privacy Policy</strong>
              A valid, reachable URL outlining how user data, diagnostics, or credentials are handled in compliance with privacy regulations.
            </div>
          </div>
        </div>
      </div>

      {/* Review Process */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
        <h2 className="text-lg font-bold text-white">Administrative Review Workflow</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-blue-400 font-bold uppercase text-[10px] tracking-wider">Step 1</span>
            <h3 className="font-semibold text-white">Developer Submission</h3>
            <p className="text-slate-400">Upload APK package with signed ownership and authorization declarations.</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-amber-400 font-bold uppercase text-[10px] tracking-wider">Step 2</span>
            <h3 className="font-semibold text-white">Admin Audit & Verification</h3>
            <p className="text-slate-400">File container validation, SHA-256 calculation, and ownership dispute check.</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-emerald-400 font-bold uppercase text-[10px] tracking-wider">Step 3</span>
            <h3 className="font-semibold text-white">Public Catalog Release</h3>
            <p className="text-slate-400">Approved applications appear on the website and inside the EM Store Android client.</p>
          </div>
        </div>
      </div>

      {/* Call to action */}
      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('/submit')}
          className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-sm inline-flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all"
        >
          <Upload className="w-4 h-4" />
          <span>Proceed to App Submission Form</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
