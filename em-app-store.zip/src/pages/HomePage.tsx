import React from 'react';
import { AppItem, PlatformStats } from '../types/index.ts';
import { AppCard } from '../components/AppCard.tsx';
import {
  Download,
  Smartphone,
  ShieldCheck,
  Search,
  Sparkles,
  TrendingUp,
  Clock,
  Layers,
  ArrowRight,
  CheckCircle2,
  Lock,
  HardDrive
} from 'lucide-react';

interface HomePageProps {
  apps: AppItem[];
  stats: PlatformStats | null;
  onSelectApp: (app: AppItem) => void;
  onNavigate: (path: string) => void;
  onSearch: (q: string) => void;
  onQuickDownload: (app: AppItem, e: React.MouseEvent) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  apps,
  stats,
  onSelectApp,
  onNavigate,
  onSearch,
  onQuickDownload
}) => {
  const [heroSearch, setHeroSearch] = React.useState('');

  const handleHeroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearch.trim()) {
      onSearch(heroSearch.trim());
    }
  };

  // Find official EM Store client app if present in catalog
  const emStoreClient = apps.find(a => a.packageId === 'com.em.store') || apps[0];

  // Recently Published
  const latestApps = [...apps].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 4);

  // Recently Updated
  const updatedApps = [...apps].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  ).slice(0, 4);

  // Popular Apps (by authentic download count)
  const popularApps = [...apps].sort((a, b) => b.downloads - a.downloads).slice(0, 4);

  // Unique categories
  const categories = Array.from(new Set(apps.map(a => a.category)));

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-b border-slate-800/80 pt-12 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(37,99,235,0.12),transparent_50%)] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Independent & Authorized Android Application Distribution</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
              Curated Android Software, <br />
              <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-sky-400 bg-clip-text text-transparent">
                Direct & Cryptographically Verified
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
              EM App Store distributes first-party tools and authorized third-party applications with
              strict developer authorization declarations, clean APK storage, and SHA-256 integrity checks.
            </p>

            {/* Prominent Search Bar */}
            <form onSubmit={handleHeroSubmit} className="max-w-xl mx-auto pt-2">
              <div className="relative flex items-center shadow-2xl rounded-xl">
                <Search className="absolute left-4 w-5 h-5 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={heroSearch}
                  onChange={(e) => setHeroSearch(e.target.value)}
                  placeholder="Search by application title, package ID (e.g. com.em.store), or publisher..."
                  className="w-full pl-12 pr-28 py-3.5 text-sm sm:text-base rounded-xl bg-slate-900/90 border border-slate-700/80 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all shadow-inner"
                />
                <button
                  type="submit"
                  className="absolute right-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow transition-colors"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Android Companion App Callout Banner */}
            <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
              {emStoreClient?.currentReleaseId && (
                <a
                  href={`/api/download/${emStoreClient.currentReleaseId}?client=web`}
                  download="com.em.store-v1.0.0.apk"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold text-sm flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-all border border-emerald-400/30"
                >
                  <Download className="w-4 h-4" />
                  <span>Download EM Store APK</span>
                </a>
              )}

              <button
                onClick={() => onNavigate('/android-client')}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-semibold text-sm flex items-center gap-2 border border-slate-700 transition-all"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Android Client & Sideload Guide</span>
              </button>

              <button
                onClick={() => onNavigate('/submit')}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl font-semibold text-sm flex items-center gap-2 border border-slate-800 transition-all"
              >
                <span>Submit Developer App</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Genuine Stats Metrics Bar */}
          <div className="mt-14 max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
            <div className="text-center p-3">
              <div className="text-2xl sm:text-3xl font-extrabold text-white">
                {stats ? stats.publishedAppsCount : apps.length}
              </div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-medium mt-1">
                Published Apps
              </div>
            </div>

            <div className="text-center p-3 border-l border-slate-800">
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-400">
                {stats ? stats.totalDownloadsRecorded : 0}
              </div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-medium mt-1">
                Recorded Downloads
              </div>
            </div>

            <div className="text-center p-3 border-l border-slate-800">
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
                {stats ? stats.publishedReleasesCount : apps.length}
              </div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-medium mt-1">
                Verified Releases
              </div>
            </div>

            <div className="text-center p-3 border-l border-slate-800">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-400">
                100%
              </div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-medium mt-1">
                Developer Authorized
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Spotlight: Official EM Store Client */}
      {emStoreClient && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-blue-500/30 p-6 sm:p-8 shadow-xl">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
              <div className="lg:col-span-2 space-y-4">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 text-xs font-semibold uppercase tracking-wider border border-blue-500/30">
                  <Smartphone className="w-3.5 h-3.5" />
                  Featured Application &bull; First Party Client
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                  {emStoreClient.name}
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {emStoreClient.shortDescription}
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-2">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Package: <span className="font-mono text-slate-200">{emStoreClient.packageId}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-blue-400" />
                    Requires Android 8.0+
                  </span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row lg:flex-col gap-3 justify-center items-stretch lg:items-end">
                <button
                  onClick={() => onSelectApp(emStoreClient)}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Inspect & Download APK</span>
                </button>
                <button
                  onClick={() => onNavigate('/android-client')}
                  className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 border border-slate-700 transition-colors"
                >
                  <span>Architecture & Sideload Guide</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Categories Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white">Browse by Category</h2>
          </div>
          <button
            onClick={() => onNavigate('/categories')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
          {categories.map((cat) => {
            const count = apps.filter(a => a.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => onNavigate(`/category/${cat}`)}
                className="p-3 bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-blue-500/40 rounded-xl text-left transition-all group"
              >
                <div className="text-xs font-semibold text-slate-200 group-hover:text-blue-400 transition-colors">
                  {cat}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {count} {count === 1 ? 'app' : 'apps'}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Latest Releases */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Latest Applications</h2>
              <p className="text-xs text-slate-400">Fresh additions to the platform repository</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('/latest')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>See more</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {latestApps.map(app => (
            <AppCard
              key={app.id}
              app={app}
              onSelect={onSelectApp}
              onQuickDownload={onQuickDownload}
            />
          ))}
        </div>
      </section>

      {/* Recently Updated */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-sky-400" />
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Recently Updated</h2>
              <p className="text-xs text-slate-400">Applications with recent version releases</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('/recently-updated')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>See more</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {updatedApps.map(app => (
            <AppCard
              key={app.id}
              app={app}
              onSelect={onSelectApp}
              onQuickDownload={onQuickDownload}
            />
          ))}
        </div>
      </section>

      {/* Popular Apps (strictly based on genuine download events) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Popular Applications</h2>
              <p className="text-xs text-slate-400">Ranked by authentic verified download activity</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('/popular')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>See more</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {popularApps.map(app => (
            <AppCard
              key={app.id}
              app={app}
              onSelect={onSelectApp}
              onQuickDownload={onQuickDownload}
            />
          ))}
        </div>
      </section>

      {/* Platform Security & Trust Commitments */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-8">
          <div className="max-w-2xl">
            <h3 className="text-xl font-bold text-white mb-2">
              Our Security & Verification Commitments
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">
              Unlike unmoderated mirror archives, EM App Store operates on strict developer accountability
              and cryptographic standards.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-slate-300 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center font-bold">
                1
              </div>
              <h4 className="font-semibold text-white text-sm">Explicit Authorization</h4>
              <p className="text-slate-400 leading-relaxed">
                Developers confirm copyright ownership and explicitly license EM App Store for public distribution. Unauthorized uploads are suspended upon report.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                2
              </div>
              <h4 className="font-semibold text-white text-sm">SHA-256 Checksums</h4>
              <p className="text-slate-400 leading-relaxed">
                Every release APK has its cryptographic SHA-256 checksum calculated and displayed. Compare the hash locally to ensure zero tampering.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
                3
              </div>
              <h4 className="font-semibold text-white text-sm">Zero Silent Installations</h4>
              <p className="text-slate-400 leading-relaxed">
                Both the website and native EM Store client utilize official Android PackageInstaller user consent handoffs. No background spyware or root escalation.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
