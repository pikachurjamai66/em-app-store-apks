import React from 'react';
import { AppItem } from '../types/index.ts';
import { Layers, ArrowRight, Tag } from 'lucide-react';

interface CategoriesPageProps {
  apps: AppItem[];
  onSelectCategory: (category: string) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ apps, onSelectCategory }) => {
  const categoryMeta: Record<string, { desc: string; iconBg: string }> = {
    Tools: { desc: 'Utilities, system helpers, maintenance tools, and device managers.', iconBg: 'from-blue-600 to-indigo-700' },
    Productivity: { desc: 'Note takers, calendars, documents, calculators, and task managers.', iconBg: 'from-emerald-600 to-teal-700' },
    Communication: { desc: 'Messaging, browsers, VoIP, mail, and local direct transfer.', iconBg: 'from-purple-600 to-pink-700' },
    Entertainment: { desc: 'Music players, video decoders, audio editors, and streaming clients.', iconBg: 'from-amber-600 to-orange-700' },
    Games: { desc: 'Offline arcade, puzzles, strategy, and casual Android games.', iconBg: 'from-rose-600 to-red-700' },
    Education: { desc: 'Scientific calculators, reference tools, linguistics, and learning.', iconBg: 'from-cyan-600 to-blue-700' },
    Social: { desc: 'Community networks, feeds, open-source microblogging clients.', iconBg: 'from-violet-600 to-indigo-700' },
    Utilities: { desc: 'Network diagnostics, hardware monitors, and file compressors.', iconBg: 'from-slate-600 to-slate-800' }
  };

  // Group apps by category
  const categoriesList = Object.keys(categoryMeta).map(catName => {
    const count = apps.filter(a => a.category.toLowerCase() === catName.toLowerCase()).length;
    return {
      name: catName,
      count,
      desc: categoryMeta[catName].desc,
      gradient: categoryMeta[catName].iconBg
    };
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="border-b border-slate-800 pb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
          <Layers className="w-8 h-8 text-blue-400" />
          <span>Application Categories</span>
        </h1>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl">
          Browse verified Android packages categorized by functionality and workflow.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categoriesList.map(cat => (
          <div
            key={cat.name}
            onClick={() => onSelectCategory(cat.name)}
            className="group relative bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-2xl p-6 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-lg hover:shadow-blue-500/5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center text-white shadow-md font-bold text-lg`}>
                  <Tag className="w-6 h-6 text-white" />
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {cat.count} {cat.count === 1 ? 'app' : 'apps'}
                </span>
              </div>

              <h2 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors">
                {cat.name}
              </h2>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                {cat.desc}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-blue-400 group-hover:text-blue-300">
              <span>Browse {cat.name}</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
