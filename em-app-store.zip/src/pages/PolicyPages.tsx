import React, { useState } from 'react';
import { ShieldCheck, FileText, AlertTriangle, Mail, CheckCircle2, Lock } from 'lucide-react';

interface PolicyPageProps {
  type: 'privacy' | 'terms' | 'takedown' | 'contact';
  onNavigate: (path: string) => void;
}

export const PolicyPages: React.FC<PolicyPageProps> = ({ type, onNavigate }) => {
  const [reportForm, setReportForm] = useState({
    claimantName: '',
    claimantEmail: '',
    appPackageId: '',
    infringementDescription: '',
    proofUrl: '',
    declarationAccepted: false
  });
  const [reportSubmitted, setReportSubmitted] = useState(false);

  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportForm.declarationAccepted) return;
    setReportSubmitted(true);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
  };

  if (type === 'privacy') {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-slate-300 text-xs sm:text-sm leading-relaxed">
        <div className="border-b border-slate-800 pb-6 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
            <Lock className="w-3.5 h-3.5" />
            <span>Data Minimization & Trust</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Privacy Policy</h1>
          <p className="text-xs text-slate-400">Effective Date: October 2026 &bull; EM App Store Platform</p>
        </div>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">1. Principles of Data Minimization</h2>
          <p>
            EM App Store is engineered around minimal telemetry. We do not harvest contacts, background location, device identifiers (IMEI/MAC), biometric scans, or browser cookies for advertising networks.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">2. Information We Collect</h2>
          <p>
            When downloading an application, our servers record standard HTTP request metrics (User-Agent header and IP hash) purely for authentic rate-limiting, counter auditing, and preventing denial-of-service floods. Download metrics displayed in the store represent actual download events and are never fabricated or sold.
          </p>
          <p>
            When developers submit applications, we collect the developer's name, verified email address, application metadata, and legally binding authorization statements.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">3. Third-Party Android Applications</h2>
          <p>
            Each published Android application lists its declared Android manifest permissions on its details page. Applications may link to their own privacy policies which govern their runtime data handling.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">4. Deletion & Contact</h2>
          <p>
            Users and developers may request data inquiries or removal of submission records by contacting the administrator via our contact form.
          </p>
        </section>
      </div>
    );
  }

  if (type === 'terms') {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-slate-300 text-xs sm:text-sm leading-relaxed">
        <div className="border-b border-slate-800 pb-6 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
            <FileText className="w-3.5 h-3.5" />
            <span>Platform Agreement</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Terms of Service</h1>
          <p className="text-xs text-slate-400">Effective Date: October 2026</p>
        </div>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">1. Platform Scope</h2>
          <p>
            EM App Store provides a platform where the administrator publishes first-party applications and distributes applications from authorized third-party developers with explicit legal authorization.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">2. Developer Obligations & Distribution License</h2>
          <p>
            Developers submitting software declare that they hold copyright or distribution rights. Developers grant EM App Store non-exclusive permission to host, verify, and deliver the APK to end users. Developers agree not to upload pirated software, cracked packages, malicious code, or unauthorized spyware.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">3. User Responsibilities & Android Sideloading</h2>
          <p>
            Users are responsible for evaluating software permissions before installing APK files. Sideloading requires standard Android system consent prompts. EM App Store computes and displays cryptographic SHA-256 hashes to facilitate file verification.
          </p>
        </section>
      </div>
    );
  }

  if (type === 'takedown') {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-slate-300 text-xs sm:text-sm leading-relaxed">
        <div className="border-b border-slate-800 pb-6 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Intellectual Property Protection</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Copyright & Takedown Policy
          </h1>
          <p className="text-xs text-slate-400">
            Authorization Dispute Resolution & Digital Millennium Copyright Act (DMCA) Notice Procedures
          </p>
        </div>

        <section className="space-y-3">
          <h2 className="text-base font-bold text-white">Zero Tolerance for Unauthorized Distribution</h2>
          <p>
            EM App Store strictly forbids the unauthorized hosting or distribution of copyrighted Android packages. If you believe an application published on EM App Store infringes upon your copyright or trademark, or was submitted without authorization, please submit a formal takedown notice below.
          </p>
        </section>

        {reportSubmitted ? (
          <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h3 className="text-base font-bold text-white">Takedown Notice Received</h3>
            <p className="text-xs text-slate-300">
              Your claim for package <code className="text-emerald-300 font-mono">{reportForm.appPackageId}</code> has been logged in our administrative security queue. Platform administrators will audit the submission declaration and take down infringing records immediately upon verification.
            </p>
            <button
              onClick={() => setReportSubmitted(false)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs"
            >
              Submit another notice
            </button>
          </div>
        ) : (
          <form onSubmit={handleReportSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-5">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-3">
              File a Takedown / Authorization Dispute Notice
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Copyright Owner / Representative Name *
                </label>
                <input
                  type="text"
                  required
                  value={reportForm.claimantName}
                  onChange={(e) => setReportForm({ ...reportForm, claimantName: e.target.value })}
                  placeholder="e.g. Legal Counsel, Acme Corp"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Contact Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={reportForm.claimantEmail}
                  onChange={(e) => setReportForm({ ...reportForm, claimantEmail: e.target.value })}
                  placeholder="legal@example.com"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Target Application Package ID or Title *
              </label>
              <input
                type="text"
                required
                value={reportForm.appPackageId}
                onChange={(e) => setReportForm({ ...reportForm, appPackageId: e.target.value })}
                placeholder="e.g. com.target.app or App Title"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Infringement / Unauthorized Distribution Details *
              </label>
              <textarea
                required
                rows={4}
                value={reportForm.infringementDescription}
                onChange={(e) => setReportForm({ ...reportForm, infringementDescription: e.target.value })}
                placeholder="Describe your copyrighted work, why the listing is unauthorized, and specify the exact infringing material..."
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <label className="flex items-start gap-2.5 cursor-pointer pt-2">
              <input
                type="checkbox"
                required
                checked={reportForm.declarationAccepted}
                onChange={(e) => setReportForm({ ...reportForm, declarationAccepted: e.target.checked })}
                className="mt-1 rounded bg-slate-950 border-slate-700 text-amber-600 focus:ring-amber-500"
              />
              <span className="text-xs text-slate-300">
                I declare under penalty of perjury that I am authorized to act on behalf of the copyright owner and that the information stated is accurate.
              </span>
            </label>

            <button
              type="submit"
              className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-md"
            >
              Submit Official Takedown Notice
            </button>
          </form>
        )}
      </div>
    );
  }

  // Contact
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-slate-300 text-xs sm:text-sm leading-relaxed">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
          <Mail className="w-3.5 h-3.5" />
          <span>Platform Communications</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Contact Platform Team</h1>
        <p className="text-xs text-slate-400">
          Inquiries regarding developer onboarding, security reports, or platform governance.
        </p>
      </div>

      {contactSubmitted ? (
        <div className="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-4">
          <CheckCircle2 className="w-12 h-12 text-blue-400 mx-auto" />
          <h2 className="text-lg font-bold text-white">Message Transmitted</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Thank you for reaching out to the EM App Store team. Our engineers and administrators review inbound messages regularly.
          </p>
          <button
            onClick={() => setContactSubmitted(false)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
          >
            Send another message
          </button>
        </div>
      ) : (
        <form onSubmit={handleContactSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Your Name *</label>
              <input
                type="text"
                required
                value={contactForm.name}
                onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                placeholder="Your full name"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Your Email *</label>
              <input
                type="email"
                required
                value={contactForm.email}
                onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                placeholder="you@example.com"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Subject</label>
            <input
              type="text"
              required
              value={contactForm.subject}
              onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
              placeholder="e.g. Developer Verification Inquiry"
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Message</label>
            <textarea
              required
              rows={5}
              value={contactForm.message}
              onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
              placeholder="Detail your question or request..."
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition-colors shadow-md"
          >
            Send Inbound Message
          </button>
        </form>
      )}
    </div>
  );
};
