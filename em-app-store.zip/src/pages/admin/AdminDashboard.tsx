import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../context/AdminContext.tsx';
import { AppItem, ReleaseItem, DeveloperSubmissionItem, AuditLogItem } from '../../types/index.ts';
import { parseApiResponse } from '../../utils/api.ts';
import {
  Lock,
  LayoutDashboard,
  Layers,
  Upload,
  Clock,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  LogOut,
  RefreshCw,
  Plus,
  Eye,
  FileCheck,
  Search,
  HardDrive,
  Copy,
  Check,
  Trash2,
  Edit,
  History,
  Archive,
  RotateCcw,
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { isAuthenticated, login, logout, fetchWithAuth } = useAdmin();

  const [activeTab, setActiveTab] = useState<'overview' | 'apps' | 'new-app' | 'releases' | 'submissions' | 'logs'>('overview');
  const [loginKey, setLoginKey] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isSubmittingLogin, setIsSubmittingLogin] = useState(false);

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [apps, setApps] = useState<AppItem[]>([]);
  const [submissions, setSubmissions] = useState<DeveloperSubmissionItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);

  // In-app Modal Dialog Confirmation States (avoiding window.confirm)
  const [appToDelete, setAppToDelete] = useState<AppItem | null>(null);
  const [deleteApkFilesChecked, setDeleteApkFilesChecked] = useState(true);
  const [isDeletingApp, setIsDeletingApp] = useState(false);
  const [deleteAppError, setDeleteAppError] = useState<string | null>(null);

  const [statusChangeTarget, setStatusChangeTarget] = useState<{ app: AppItem; newStatus: 'published' | 'draft' | 'archived' } | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  const [submissionToPublish, setSubmissionToPublish] = useState<DeveloperSubmissionItem | null>(null);
  const [isPublishingSubmission, setIsPublishingSubmission] = useState(false);

  const [releaseToSetActive, setReleaseToSetActive] = useState<{ appId: string; releaseId: string; versionName?: string } | null>(null);
  const [releaseToDelete, setReleaseToDelete] = useState<{ appId: string; releaseId: string; versionName?: string } | null>(null);

  // New App Form State
  const [newAppForm, setNewAppForm] = useState({
    name: '',
    slug: '',
    packageId: '',
    shortDescription: '',
    fullDescription: '',
    category: 'Tools',
    publisher: 'EM Platform Engineering',
    developerContact: 'developer@emappstore.local',
    iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80',
    minAndroidVersion: 'Android 8.0 (API 26)',
    targetAndroidVersion: 'Android 14 (API 34)',
    privacyPolicyUrl: '/privacy',
    versionName: '1.0.0',
    versionCode: '100',
    changelog: 'Initial production release on EM App Store.',
    customPermission: ''
  });
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE'
  ]);
  const [screenshotsList, setScreenshotsList] = useState<string[]>([
    'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&fit=crop&q=80'
  ]);
  const [newScreenshotInput, setNewScreenshotInput] = useState('');
  const [newAppApkFile, setNewAppApkFile] = useState<File | null>(null);
  const [newAppMessage, setNewAppMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const [isCreatingApp, setIsCreatingApp] = useState(false);

  // Selected App for Release History Tab
  const [selectedAppForReleases, setSelectedAppForReleases] = useState<string>('');
  const [currentAppReleases, setCurrentAppReleases] = useState<ReleaseItem[]>([]);
  const [isLoadingReleases, setIsLoadingReleases] = useState(false);

  // Upload New Release Modal State
  const [releaseModalApp, setReleaseModalApp] = useState<AppItem | null>(null);
  const [releaseVersionName, setReleaseVersionName] = useState('');
  const [releaseVersionCode, setReleaseVersionCode] = useState('');
  const [releaseChangelog, setReleaseChangelog] = useState('');
  const [releaseFile, setReleaseFile] = useState<File | null>(null);
  const [releaseStatusMode, setReleaseStatusMode] = useState<'published' | 'draft'>('published');
  const [isUploadingRelease, setIsUploadingRelease] = useState(false);
  const [releaseWarning, setReleaseWarning] = useState<string | null>(null);

  // Edit App Metadata Modal
  const [editingApp, setEditingApp] = useState<AppItem | null>(null);
  const [editFormData, setEditFormData] = useState<any>({});
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Preview Modal
  const [previewApp, setPreviewApp] = useState<AppItem | null>(null);

  // Submissions Review Modal State
  const [reviewModalSub, setReviewModalSub] = useState<DeveloperSubmissionItem | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);

  // Apps list filter
  const [appsSearch, setAppsSearch] = useState('');
  const [appsFilterStatus, setAppsFilterStatus] = useState('all');

  const commonPermissions = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.CAMERA',
    'android.permission.READ_MEDIA_AUDIO',
    'android.permission.USE_BIOMETRIC',
    'android.permission.REQUEST_INSTALL_PACKAGES'
  ];

  const loadAdminData = async () => {
    if (!isAuthenticated) return;
    setIsLoadingData(true);
    setDataError(null);
    try {
      const [statsRes, appsRes, subsRes, logsRes] = await Promise.all([
        fetchWithAuth('/api/admin/stats'),
        fetchWithAuth('/api/admin/apps'),
        fetchWithAuth('/api/admin/submissions'),
        fetchWithAuth('/api/admin/audit-logs')
      ]);

      if (!appsRes.ok) {
        const errData = await appsRes.json().catch(() => ({}));
        setDataError(errData.error || `Failed to fetch applications from server (Status ${appsRes.status})`);
        return;
      }

      if (statsRes.ok) setStats(await statsRes.json());
      const d = await appsRes.json();
      setApps(d.apps || []);
      if (d.apps?.length > 0 && !selectedAppForReleases) {
        setSelectedAppForReleases(d.apps[0].id);
      }
      if (subsRes.ok) {
        const subData = await subsRes.json();
        setSubmissions(subData.submissions || []);
      }
      if (logsRes.ok) {
        const logData = await logsRes.json();
        setAuditLogs(logData.logs || []);
      }
    } catch (err: any) {
      console.error('Failed to load admin dataset:', err);
      setDataError(err.message || 'Network connection failed. Could not communicate with server.');
    } finally {
      setIsLoadingData(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadAdminData();
    }
  }, [isAuthenticated]);

  // Load releases for selected app in Release History Tab
  useEffect(() => {
    if (selectedAppForReleases && isAuthenticated) {
      const fetchReleases = async () => {
        setIsLoadingReleases(true);
        try {
          const res = await fetchWithAuth(`/api/admin/apps/${selectedAppForReleases}/releases`);
          if (res.ok) {
            const data = await res.json();
            setCurrentAppReleases(data.releases || []);
          }
        } catch (e) {
          console.error('Failed to fetch releases:', e);
        } finally {
          setIsLoadingReleases(false);
        }
      };
      fetchReleases();
    }
  }, [selectedAppForReleases, isAuthenticated]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsSubmittingLogin(true);
    const res = await login(loginKey);
    setIsSubmittingLogin(false);
    if (!res.success) {
      setLoginError(res.error || 'Authentication rejected. Verify admin authorization key.');
    }
  };

  // Generate Slug automatically from Name
  const generateSlugFromName = () => {
    if (!newAppForm.name) return;
    const s = newAppForm.name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
    setNewAppForm(prev => ({ ...prev, slug: s }));
  };

  const togglePermission = (perm: string) => {
    if (selectedPermissions.includes(perm)) {
      setSelectedPermissions(selectedPermissions.filter(p => p !== perm));
    } else {
      setSelectedPermissions([...selectedPermissions, perm]);
    }
  };

  const addCustomPermission = () => {
    if (newAppForm.customPermission.trim() && !selectedPermissions.includes(newAppForm.customPermission.trim())) {
      setSelectedPermissions([...selectedPermissions, newAppForm.customPermission.trim()]);
      setNewAppForm(prev => ({ ...prev, customPermission: '' }));
    }
  };

  const addScreenshot = () => {
    if (newScreenshotInput.trim() && !screenshotsList.includes(newScreenshotInput.trim())) {
      setScreenshotsList([...screenshotsList, newScreenshotInput.trim()]);
      setNewScreenshotInput('');
    }
  };

  const removeScreenshot = (index: number) => {
    setScreenshotsList(screenshotsList.filter((_, i) => i !== index));
  };

  const handleCreateApp = async (publicationStatus: 'published' | 'draft') => {
    setNewAppMessage(null);

    // Validation
    if (!newAppForm.name.trim()) {
      setNewAppMessage({ text: 'Application name is required.', isError: true });
      return;
    }
    if (!newAppForm.packageId.trim()) {
      setNewAppMessage({ text: 'Android package identifier is required.', isError: true });
      return;
    }

    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i;
    if (!packageRegex.test(newAppForm.packageId.trim())) {
      setNewAppMessage({
        text: 'Invalid package identifier format. Must follow reverse-DNS convention (e.g. com.company.app).',
        isError: true
      });
      return;
    }

    if (!newAppForm.shortDescription.trim()) {
      setNewAppMessage({ text: 'Short description is required.', isError: true });
      return;
    }
    if (!newAppForm.publisher.trim()) {
      setNewAppMessage({ text: 'Publisher name is required.', isError: true });
      return;
    }

    if (publicationStatus === 'published' && !newAppApkFile) {
      setNewAppMessage({
        text: 'An APK package file is mandatory to submit directly as Published. Alternatively, choose Save Draft.',
        isError: true
      });
      return;
    }

    setIsCreatingApp(true);

    try {
      const formData = new FormData();
      formData.append('name', newAppForm.name.trim());
      formData.append('slug', (newAppForm.slug || newAppForm.name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, ''));
      formData.append('packageId', newAppForm.packageId.trim());
      formData.append('shortDescription', newAppForm.shortDescription.trim());
      formData.append('fullDescription', (newAppForm.fullDescription || newAppForm.shortDescription).trim());
      formData.append('category', newAppForm.category);
      formData.append('publisher', newAppForm.publisher.trim());
      if (newAppForm.developerContact) formData.append('developerContact', newAppForm.developerContact.trim());
      formData.append('iconUrl', newAppForm.iconUrl.trim());
      formData.append('screenshots', JSON.stringify(screenshotsList));
      formData.append('minAndroidVersion', newAppForm.minAndroidVersion);
      formData.append('targetAndroidVersion', newAppForm.targetAndroidVersion);
      formData.append('privacyPolicyUrl', newAppForm.privacyPolicyUrl);
      formData.append('permissions', JSON.stringify(selectedPermissions));
      formData.append('publicationStatus', publicationStatus);
      formData.append('versionName', newAppForm.versionName || '1.0.0');
      formData.append('versionCode', newAppForm.versionCode || '100');
      formData.append('changelog', newAppForm.changelog || 'Initial release.');

      if (newAppApkFile) {
        formData.append('apkFile', newAppApkFile);
      }

      const res = await fetchWithAuth('/api/admin/apps', {
        method: 'POST',
        body: formData
      });

      const data = await parseApiResponse<{ success: boolean; app: AppItem; release?: ReleaseItem }>(res);

      setNewAppMessage({
        text: `Application "${data.app.name}" (${data.app.packageId}) registered successfully as ${data.app.publicationStatus.toUpperCase()}!`
      });
      await loadAdminData();
      setNewAppApkFile(null);
      setTimeout(() => {
        setActiveTab('apps');
      }, 1500);
    } catch (err) {
      console.error('Application creation error:', err);
      setNewAppMessage({
        text: err instanceof Error ? err.message : 'Error creating application. Please verify details and try again.',
        isError: true
      });
    } finally {
      setIsCreatingApp(false);
    }
  };

  const handleUpdateAppStatus = (appId: string, publicationStatus: 'published' | 'draft' | 'archived') => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;
    setStatusChangeTarget({ app, newStatus: publicationStatus });
  };

  const confirmUpdateAppStatus = async () => {
    if (!statusChangeTarget) return;
    setIsUpdatingStatus(true);
    try {
      const res = await fetchWithAuth(`/api/admin/apps/${statusChangeTarget.app.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ publicationStatus: statusChangeTarget.newStatus })
      });
      await parseApiResponse(res);
      setStatusChangeTarget(null);
      await loadAdminData();
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Failed to update application status');
      console.error('Failed to update app status:', err);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleDeleteApp = (appId: string) => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;
    setAppToDelete(app);
    setDeleteAppError(null);
  };

  const confirmDeleteApp = async () => {
    if (!appToDelete) return;
    setIsDeletingApp(true);
    setDeleteAppError(null);
    try {
      const res = await fetchWithAuth(`/api/admin/apps/${appToDelete.id}?deleteFiles=${deleteApkFilesChecked}`, {
        method: 'DELETE'
      });
      await parseApiResponse(res);
      setAppToDelete(null);
      await loadAdminData();
    } catch (err) {
      setDeleteAppError(err instanceof Error ? err.message : 'Delete failed');
    } finally {
      setIsDeletingApp(false);
    }
  };

  // Upload Release APK
  const handleUploadRelease = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!releaseModalApp || !releaseFile) return;

    setIsUploadingRelease(true);
    setReleaseWarning(null);

    try {
      const formData = new FormData();
      formData.append('versionName', releaseVersionName || '1.0.0');
      if (releaseVersionCode) {
        formData.append('versionCode', releaseVersionCode);
      }
      formData.append('changelog', releaseChangelog);
      formData.append('releaseStatus', releaseStatusMode);
      formData.append('apkFile', releaseFile);

      const res = await fetchWithAuth(`/api/admin/apps/${releaseModalApp.id}/releases`, {
        method: 'POST',
        body: formData
      });

      const data = await parseApiResponse<{ success: boolean; release: ReleaseItem; compatibilityWarning?: string }>(res);

      if (data.compatibilityWarning) {
        setReleaseWarning(data.compatibilityWarning);
      }

      loadAdminData();
      if (selectedAppForReleases === releaseModalApp.id) {
        const refetch = await fetchWithAuth(`/api/admin/apps/${releaseModalApp.id}/releases`);
        if (refetch.ok) {
          const d = await refetch.json();
          setCurrentAppReleases(d.releases || []);
        }
      }

      setTimeout(() => {
        setReleaseModalApp(null);
        setReleaseFile(null);
        setReleaseVersionName('');
        setReleaseVersionCode('');
        setReleaseChangelog('');
        setIsUploadingRelease(false);
      }, 1500);
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Release upload failed');
      setIsUploadingRelease(false);
    }
  };

  // Set as current release
  const handleSetCurrentRelease = (appId: string, releaseId: string) => {
    const rel = currentAppReleases.find(r => r.id === releaseId);
    setReleaseToSetActive({ appId, releaseId, versionName: rel?.versionName });
  };

  const confirmSetCurrentRelease = async () => {
    if (!releaseToSetActive) return;
    const { appId, releaseId } = releaseToSetActive;
    try {
      const res = await fetchWithAuth(`/api/admin/apps/${appId}/releases/${releaseId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ setCurrent: true, releaseStatus: 'published' })
      });
      if (res.ok) {
        setDataError(null);
        await loadAdminData();
        const refetch = await fetchWithAuth(`/api/admin/apps/${appId}/releases`);
        if (refetch.ok) {
          const d = await refetch.json();
          setCurrentAppReleases(d.releases || []);
        }
      } else {
        const err = await res.json().catch(() => ({}));
        setDataError(err.error || 'Failed to activate release');
      }
    } catch (e) {
      setDataError(e instanceof Error ? e.message : 'Failed to set current release');
    } finally {
      setReleaseToSetActive(null);
    }
  };

  // Delete single release
  const handleDeleteRelease = (appId: string, releaseId: string) => {
    const rel = currentAppReleases.find(r => r.id === releaseId);
    setReleaseToDelete({ appId, releaseId, versionName: rel?.versionName });
  };

  const confirmDeleteRelease = async () => {
    if (!releaseToDelete) return;
    const { appId, releaseId } = releaseToDelete;
    try {
      const res = await fetchWithAuth(`/api/admin/apps/${appId}/releases/${releaseId}?deleteFile=true`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setDataError(null);
        await loadAdminData();
        const refetch = await fetchWithAuth(`/api/admin/apps/${appId}/releases`);
        if (refetch.ok) {
          const d = await refetch.json();
          setCurrentAppReleases(d.releases || []);
        }
      } else {
        const err = await res.json().catch(() => ({}));
        setDataError(err.error || 'Failed to delete release');
      }
    } catch (e) {
      setDataError(e instanceof Error ? e.message : 'Failed to delete release');
    } finally {
      setReleaseToDelete(null);
    }
  };

  // Edit App Metadata Save
  const handleSaveEditApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingApp) return;
    setIsSavingEdit(true);

    try {
      const res = await fetchWithAuth(`/api/admin/apps/${editingApp.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editFormData)
      });
      await parseApiResponse(res);
      setEditingApp(null);
      setDataError(null);
      await loadAdminData();
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Update failed');
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleReviewSubmission = async (status: 'approved' | 'rejected' | 'under_review') => {
    if (!reviewModalSub) return;
    setIsReviewing(true);
    try {
      const res = await fetchWithAuth(`/api/admin/submissions/${reviewModalSub.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewStatus: status,
          reviewNotes
        })
      });
      if (!res.ok) throw new Error('Failed to update review status');
      setDataError(null);
      await loadAdminData();
      setReviewModalSub(null);
      setReviewNotes('');
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Review action failed');
    } finally {
      setIsReviewing(false);
    }
  };

  const handlePublishSubmission = (subId: string) => {
    const sub = submissions.find(s => s.id === subId);
    if (!sub) return;
    setSubmissionToPublish(sub);
  };

  const confirmPublishSubmission = async () => {
    if (!submissionToPublish) return;
    setIsPublishingSubmission(true);
    try {
      const res = await fetchWithAuth(`/api/admin/submissions/${submissionToPublish.id}/publish`, {
        method: 'POST'
      });
      await parseApiResponse(res);
      setSubmissionToPublish(null);
      setDataError(null);
      await loadAdminData();
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Publish failed');
    } finally {
      setIsPublishingSubmission(false);
    }
  };

  const formatBytes = (bytes: number): string => {
    if (!bytes || bytes === 0) return '0 KB';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1) return `${mb.toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  // If NOT authenticated, render Secure Admin Login Form
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center mx-auto shadow-inner border border-blue-500/30">
            <Lock className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            EM App Store Administrator Portal
          </h1>
          <p className="text-xs text-slate-400">
            Restricted administrative console for catalog and release publication.
          </p>
        </div>

        {loginError && (
          <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-red-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{loginError}</span>
          </div>
        )}

        <form onSubmit={handleLoginSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Administrator Access Key
            </label>
            <input
              type="password"
              required
              value={loginKey}
              onChange={(e) => setLoginKey(e.target.value)}
              placeholder="Enter ADMIN_INIT_KEY"
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
            />
            <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
              Configured via server environment <code className="text-slate-400 font-mono">ADMIN_INIT_KEY</code>.
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmittingLogin}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors shadow-md"
          >
            {isSubmittingLogin ? 'Verifying Authorization...' : 'Authenticate Admin Session'}
          </button>
        </form>
      </div>
    );
  }

  // Filtered Apps list
  const filteredApps = apps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(appsSearch.toLowerCase()) ||
      app.packageId.toLowerCase().includes(appsSearch.toLowerCase()) ||
      app.publisher.toLowerCase().includes(appsSearch.toLowerCase());
    const matchesStatus = appsFilterStatus === 'all' || app.publicationStatus === appsFilterStatus;
    return matchesSearch && matchesStatus;
  });

  const selectedAppItem = apps.find(a => a.id === selectedAppForReleases);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h1 className="text-2xl font-bold text-white tracking-tight">Administrator Console</h1>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Platform: <span className="text-blue-400 font-semibold">EM App Store &bull; EM Store</span> &bull; Authorized Admin
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadAdminData}
            disabled={isLoadingData}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 flex items-center gap-1.5"
            title="Refresh database records"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingData ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>

          <button
            onClick={logout}
            className="px-3 py-1.5 bg-red-950/40 hover:bg-red-900/40 text-red-300 rounded-lg text-xs font-medium border border-red-800/50 flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Authoritative Database / Connection Error Alert Banner */}
      {dataError && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-300 p-4 rounded-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
            <div>
              <p className="font-semibold text-red-200 text-sm">Authoritative Database Error</p>
              <p className="text-xs text-red-300/80 mt-0.5">{dataError}</p>
            </div>
          </div>
          <button
            onClick={loadAdminData}
            disabled={isLoadingData}
            className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-lg text-xs font-semibold shrink-0"
          >
            Retry
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex border-b border-slate-800 gap-6 text-xs sm:text-sm font-semibold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'overview' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('apps')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'apps' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Manage Apps ({apps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('new-app')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'new-app' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>Add New App</span>
        </button>

        <button
          onClick={() => setActiveTab('releases')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'releases' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Release Management</span>
        </button>

        <button
          onClick={() => setActiveTab('submissions')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'submissions' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Developer Submissions ({submissions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`pb-3 border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'logs' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Audit Logs ({auditLogs.length})</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && stats && (
        <div className="space-y-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-2xl font-bold text-white">{stats.totalApps}</div>
              <div className="text-xs text-slate-400 mt-1 font-medium">Total Registered Apps</div>
              <div className="text-[11px] text-emerald-400 mt-2">{stats.publishedApps} currently published</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-2xl font-bold text-amber-400">{stats.pendingSubmissions}</div>
              <div className="text-xs text-slate-400 mt-1 font-medium">Pending Submissions</div>
              <div className="text-[11px] text-slate-500 mt-2">Awaiting authorization audit</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-2xl font-bold text-blue-400">{stats.totalDownloads}</div>
              <div className="text-xs text-slate-400 mt-1 font-medium">Recorded Download Events</div>
              <div className="text-[11px] text-slate-500 mt-2">From web and Android clients</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-2xl font-bold text-purple-400">{stats.totalReleases}</div>
              <div className="text-xs text-slate-400 mt-1 font-medium">Verified Release APKs</div>
              <div className="text-[11px] text-slate-500 mt-2">With SHA-256 integrity hashes</div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Phase 2 Publishing & Verification Standards</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <strong className="text-white block">1. Full Binary Inspection</strong>
                Every uploaded APK is structurally scanned for ZIP container validity and AndroidManifest.xml presence before storage.
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <strong className="text-white block">2. In-Place Update Enforcement</strong>
                When publishing new releases, version codes must increment monotonically to preserve Android OS update compatibility.
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <strong className="text-white block">3. Strict Publication Boundary</strong>
                Draft, archived, and rejected releases are filtered on the backend and blocked from public download streams.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MANAGE APPS */}
      {activeTab === 'apps' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={appsSearch}
                onChange={(e) => setAppsSearch(e.target.value)}
                placeholder="Search by title, package ID, or publisher..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={appsFilterStatus}
                onChange={(e) => setAppsFilterStatus(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Statuses</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>

              <button
                onClick={() => setActiveTab('new-app')}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add App</span>
              </button>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="p-3.5">Application</th>
                    <th className="p-3.5">Package Identifier</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Downloads</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredApps.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-800/40">
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={app.iconUrl}
                            alt=""
                            className="w-9 h-9 rounded-lg object-cover bg-slate-800 flex-shrink-0"
                          />
                          <div>
                            <div className="font-bold text-white flex items-center gap-1.5">
                              <span>{app.name}</span>
                              {app.isDemonstration && (
                                <span className="text-[9px] uppercase px-1 rounded bg-amber-500/20 text-amber-300">
                                  Demo
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400">{app.publisher}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 font-mono text-[11px] text-slate-300 select-all">
                        {app.packageId}
                      </td>
                      <td className="p-3.5">{app.category}</td>
                      <td className="p-3.5">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            app.publicationStatus === 'published'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : app.publicationStatus === 'draft'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {app.publicationStatus}
                        </span>
                      </td>
                      <td className="p-3.5 font-semibold text-white">{app.downloads || 0}</td>
                      <td className="p-3.5 text-right space-x-1.5">
                        <button
                          onClick={() => setPreviewApp(app)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
                          title="Preview Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => {
                            setEditingApp(app);
                            setEditFormData({
                              name: app.name,
                              shortDescription: app.shortDescription,
                              fullDescription: app.fullDescription,
                              category: app.category,
                              publisher: app.publisher,
                              developerContact: app.developerContact || '',
                              privacyPolicyUrl: app.privacyPolicyUrl,
                              minAndroidVersion: app.minAndroidVersion,
                              targetAndroidVersion: app.targetAndroidVersion || ''
                            });
                          }}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-blue-300 rounded text-xs"
                          title="Edit Metadata"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => {
                            setSelectedAppForReleases(app.id);
                            setActiveTab('releases');
                          }}
                          className="px-2 py-1 bg-blue-950/50 hover:bg-blue-900/60 text-blue-300 rounded text-[11px] font-medium border border-blue-800/40"
                          title="View Releases"
                        >
                          Releases
                        </button>

                        <button
                          onClick={() => {
                            setReleaseModalApp(app);
                            setReleaseVersionName('');
                            setReleaseVersionCode('');
                            setReleaseChangelog('');
                            setReleaseFile(null);
                            setReleaseStatusMode('published');
                          }}
                          className="px-2 py-1 bg-emerald-950/50 hover:bg-emerald-900/60 text-emerald-300 rounded text-[11px] font-medium border border-emerald-800/40"
                          title="Upload new APK version"
                        >
                          + APK
                        </button>

                        {app.publicationStatus === 'published' ? (
                          <button
                            onClick={() => handleUpdateAppStatus(app.id, 'draft')}
                            className="px-2 py-1 bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 rounded text-[11px] font-medium border border-amber-800/40"
                          >
                            Unpublish
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUpdateAppStatus(app.id, 'published')}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-medium"
                          >
                            Publish
                          </button>
                        )}

                        {app.publicationStatus !== 'archived' ? (
                          <button
                            onClick={() => handleUpdateAppStatus(app.id, 'archived')}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded text-xs"
                            title="Archive Listing"
                          >
                            <Archive className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUpdateAppStatus(app.id, 'draft')}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded text-xs"
                            title="Restore from Archive"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => handleDeleteApp(app.id)}
                          className="p-1.5 bg-red-950/40 hover:bg-red-900/60 text-red-400 rounded text-xs"
                          title="Permanently Delete Application"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ADD NEW APP WORKFLOW */}
      {activeTab === 'new-app' && (
        <div className="max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">Add New Application & Release</h2>
            <p className="text-xs text-slate-400">
              Publish first-party software or authorized developer packages. Upload APK directly or save initial draft.
            </p>
          </div>

          {newAppMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
                newAppMessage.isError
                  ? 'bg-red-950/50 text-red-300 border border-red-800'
                  : 'bg-emerald-950/50 text-emerald-300 border border-emerald-800'
              }`}
            >
              {newAppMessage.isError ? <AlertTriangle className="w-4 h-4 flex-shrink-0" /> : <CheckCircle2 className="w-4 h-4 flex-shrink-0" />}
              <span>{newAppMessage.text}</span>
            </div>
          )}

          <div className="space-y-6 text-xs">
            {/* Identity & Slug */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Application Name *</label>
                <input
                  type="text"
                  required
                  value={newAppForm.name}
                  onChange={(e) => setNewAppForm({ ...newAppForm, name: e.target.value })}
                  placeholder="e.g. Zenith Markdown Notes"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Unique URL Slug *
                  <button
                    type="button"
                    onClick={generateSlugFromName}
                    className="ml-2 text-blue-400 hover:text-blue-300 font-normal underline text-[10px]"
                  >
                    Auto-generate
                  </button>
                </label>
                <input
                  type="text"
                  required
                  value={newAppForm.slug}
                  onChange={(e) => setNewAppForm({ ...newAppForm, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') })}
                  placeholder="zenith-markdown-notes"
                  className="w-full px-3 py-2 font-mono rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Package Identifier *</label>
                <input
                  type="text"
                  required
                  value={newAppForm.packageId}
                  onChange={(e) => setNewAppForm({ ...newAppForm, packageId: e.target.value.trim() })}
                  placeholder="org.zenith.notes"
                  className="w-full px-3 py-2 font-mono rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">Format: com.company.app</span>
              </div>
            </div>

            {/* Category & Publisher */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Category *</label>
                <select
                  value={newAppForm.category}
                  onChange={(e) => setNewAppForm({ ...newAppForm, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Tools">Tools</option>
                  <option value="Productivity">Productivity</option>
                  <option value="Communication">Communication</option>
                  <option value="Entertainment">Entertainment</option>
                  <option value="Games">Games</option>
                  <option value="Education">Education</option>
                  <option value="Social">Social</option>
                  <option value="Utilities">Utilities</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Publisher Name *</label>
                <input
                  type="text"
                  required
                  value={newAppForm.publisher}
                  onChange={(e) => setNewAppForm({ ...newAppForm, publisher: e.target.value })}
                  placeholder="e.g. Zenith Software Foundation"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Developer Contact (Email/URL)</label>
                <input
                  type="text"
                  value={newAppForm.developerContact}
                  onChange={(e) => setNewAppForm({ ...newAppForm, developerContact: e.target.value })}
                  placeholder="contact@example.org"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Descriptions */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">Short Description *</label>
              <input
                type="text"
                required
                maxLength={150}
                value={newAppForm.shortDescription}
                onChange={(e) => setNewAppForm({ ...newAppForm, shortDescription: e.target.value })}
                placeholder="Single sentence summarizing purpose and functionality"
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Full Description</label>
              <textarea
                rows={4}
                value={newAppForm.fullDescription}
                onChange={(e) => setNewAppForm({ ...newAppForm, fullDescription: e.target.value })}
                placeholder="In-depth overview of architecture, features, storage, and user workflow..."
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Media: Icon & Screenshots */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">App Icon URL *</label>
                <input
                  type="url"
                  required
                  value={newAppForm.iconUrl}
                  onChange={(e) => setNewAppForm({ ...newAppForm, iconUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {newAppForm.iconUrl && (
                  <div className="mt-2 flex items-center gap-2">
                    <img
                      src={newAppForm.iconUrl}
                      alt="Icon preview"
                      className="w-10 h-10 rounded-lg object-cover bg-slate-800 border border-slate-700"
                      onError={(e) => (e.target as any).src = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&h=128&fit=crop&q=80'}
                    />
                    <span className="text-[10px] text-slate-500">Icon preview</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Screenshots (Image URLs)</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={newScreenshotInput}
                    onChange={(e) => setNewScreenshotInput(e.target.value)}
                    placeholder="https://.../screenshot.jpg"
                    className="flex-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={addScreenshot}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold"
                  >
                    Add
                  </button>
                </div>

                <div className="flex gap-2 mt-2 flex-wrap">
                  {screenshotsList.map((url, i) => (
                    <div key={i} className="relative group">
                      <img src={url} alt="" className="w-12 h-12 rounded object-cover border border-slate-700" />
                      <button
                        type="button"
                        onClick={() => removeScreenshot(i)}
                        className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Android System Requirements & Privacy */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Minimum Android OS</label>
                <input
                  type="text"
                  value={newAppForm.minAndroidVersion}
                  onChange={(e) => setNewAppForm({ ...newAppForm, minAndroidVersion: e.target.value })}
                  placeholder="Android 8.0 (API 26)"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Target Android SDK</label>
                <input
                  type="text"
                  value={newAppForm.targetAndroidVersion}
                  onChange={(e) => setNewAppForm({ ...newAppForm, targetAndroidVersion: e.target.value })}
                  placeholder="Android 14 (API 34)"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Privacy Policy URL</label>
                <input
                  type="text"
                  value={newAppForm.privacyPolicyUrl}
                  onChange={(e) => setNewAppForm({ ...newAppForm, privacyPolicyUrl: e.target.value })}
                  placeholder="/privacy or https://..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Permission Disclosures */}
            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Declared Android Manifest Permissions</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 p-3 bg-slate-950 rounded-xl border border-slate-800">
                {commonPermissions.map((perm) => (
                  <label key={perm} className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={selectedPermissions.includes(perm)}
                      onChange={() => togglePermission(perm)}
                      className="rounded bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-[11px] font-mono text-slate-300 truncate">{perm}</span>
                  </label>
                ))}
              </div>

              <div className="flex gap-2 mt-2">
                <input
                  type="text"
                  value={newAppForm.customPermission}
                  onChange={(e) => setNewAppForm({ ...newAppForm, customPermission: e.target.value })}
                  placeholder="Add custom permission e.g. android.permission.ACCESS_FINE_LOCATION"
                  className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={addCustomPermission}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Add
                </button>
              </div>
            </div>

            {/* APK Package Binary & Release Setup */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
              <h3 className="font-semibold text-white text-xs uppercase tracking-wider flex items-center gap-1.5 text-blue-400">
                <HardDrive className="w-4 h-4" />
                <span>Initial Release APK Package</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Name</label>
                  <input
                    type="text"
                    value={newAppForm.versionName}
                    onChange={(e) => setNewAppForm({ ...newAppForm, versionName: e.target.value })}
                    placeholder="1.0.0"
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Code (integer)</label>
                  <input
                    type="number"
                    value={newAppForm.versionCode}
                    onChange={(e) => setNewAppForm({ ...newAppForm, versionCode: e.target.value })}
                    placeholder="100"
                    className="w-full px-3 py-2 font-mono rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Changelog / Release Notes</label>
                <input
                  type="text"
                  value={newAppForm.changelog}
                  onChange={(e) => setNewAppForm({ ...newAppForm, changelog: e.target.value })}
                  placeholder="Summary of changes in this release"
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Upload APK File (.apk) {newAppApkFile ? `— ${newAppApkFile.name} (${(newAppApkFile.size / (1024 * 1024)).toFixed(2)} MB)` : ''}
                </label>
                <input
                  type="file"
                  accept=".apk"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setNewAppApkFile(e.target.files[0]);
                    }
                  }}
                  className="w-full text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Mandatory when submitting for immediate publication. Optional when saving a draft.
                </span>
              </div>
            </div>

            {/* Actions: Save Draft vs Submit for Publication */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                disabled={isCreatingApp}
                onClick={() => handleCreateApp('draft')}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs transition-colors border border-slate-700"
              >
                Save Draft
              </button>

              <button
                type="button"
                disabled={isCreatingApp}
                onClick={() => handleCreateApp('published')}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors shadow-md"
              >
                {isCreatingApp ? 'Verifying APK & Publishing...' : 'Submit for Publication'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RELEASE MANAGEMENT */}
      {activeTab === 'releases' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <History className="w-5 h-5 text-blue-400" />
                <span>Application Release History & Management</span>
              </h2>
              <p className="text-xs text-slate-400">
                Inspect release binaries, rollback versions, or verify SHA-256 container hashes.
              </p>
            </div>

            {selectedAppItem && (
              <button
                onClick={() => {
                  setReleaseModalApp(selectedAppItem);
                  setReleaseVersionName('');
                  setReleaseVersionCode('');
                  setReleaseChangelog('');
                  setReleaseFile(null);
                  setReleaseStatusMode('published');
                }}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow"
              >
                <Plus className="w-4 h-4" />
                <span>Upload New Release APK</span>
              </button>
            )}
          </div>

          {/* Select Application */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <span className="text-xs font-semibold text-slate-300 whitespace-nowrap">Select Application:</span>
            <select
              value={selectedAppForReleases}
              onChange={(e) => setSelectedAppForReleases(e.target.value)}
              className="flex-1 px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {apps.map(a => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.packageId}) &bull; {a.publicationStatus.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          {/* Releases Table */}
          {isLoadingReleases ? (
            <div className="text-center py-12 text-slate-400 text-xs">Loading releases...</div>
          ) : currentAppReleases.length > 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="p-3.5">Version</th>
                    <th className="p-3.5">Code</th>
                    <th className="p-3.5">Size</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">SHA-256 Checksum</th>
                    <th className="p-3.5">Published</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {currentAppReleases.map((rel) => {
                    const isCurrent = selectedAppItem?.currentReleaseId === rel.id;
                    return (
                      <tr key={rel.id} className={`hover:bg-slate-800/40 ${isCurrent ? 'bg-blue-950/20' : ''}`}>
                        <td className="p-3.5">
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <span>v{rel.versionName}</span>
                            {isCurrent && (
                              <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono text-[9px] border border-blue-500/30">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate max-w-xs">{rel.changelog}</div>
                        </td>
                        <td className="p-3.5 font-mono text-[11px]">{rel.versionCode}</td>
                        <td className="p-3.5">{formatBytes(rel.fileSize)}</td>
                        <td className="p-3.5">
                          <span
                            className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                              rel.releaseStatus === 'published'
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : rel.releaseStatus === 'draft'
                                ? 'bg-amber-500/20 text-amber-400'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {rel.releaseStatus}
                          </span>
                        </td>
                        <td className="p-3.5 font-mono text-[10px] text-slate-400 max-w-xs truncate select-all">
                          {rel.sha256}
                        </td>
                        <td className="p-3.5 text-slate-400 text-[11px]">
                          {rel.publishedAt ? new Date(rel.publishedAt).toLocaleDateString() : 'Unpublished'}
                        </td>
                        <td className="p-3.5 text-right space-x-2 whitespace-nowrap">
                          {!isCurrent && rel.releaseStatus === 'published' && (
                            <button
                              onClick={() => handleSetCurrentRelease(selectedAppForReleases, rel.id)}
                              className="px-2 py-1 bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white rounded text-[11px] font-medium"
                            >
                              Set Active
                            </button>
                          )}

                          <a
                            href={`/api/download/${rel.id}?client=web`}
                            className="inline-block px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px]"
                            title="Download APK"
                          >
                            Download
                          </a>

                          <button
                            onClick={() => handleDeleteRelease(selectedAppForReleases, rel.id)}
                            className="p-1 text-slate-500 hover:text-red-400"
                            title="Delete Release"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl text-xs text-slate-400">
              No releases uploaded yet for this application. Click "Upload New Release APK" above.
            </div>
          )}
        </div>
      )}

      {/* TAB 5: DEVELOPER SUBMISSIONS */}
      {activeTab === 'submissions' && (
        <div className="space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">Developer Review Queue</h2>
            <p className="text-xs text-slate-400">
              Audit developer submissions, verify legal authorization statements, and publish approved APKs.
            </p>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="p-3.5">Application</th>
                    <th className="p-3.5">Developer</th>
                    <th className="p-3.5">Submitted</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {submissions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-slate-800/40">
                      <td className="p-3.5">
                        <div className="font-bold text-white">{sub.appName}</div>
                        <div className="font-mono text-[11px] text-slate-400">{sub.packageId}</div>
                      </td>
                      <td className="p-3.5">
                        <div>{sub.developerName}</div>
                        <div className="text-[11px] text-slate-400">{sub.developerEmail}</div>
                      </td>
                      <td className="p-3.5 text-slate-400">
                        {new Date(sub.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            sub.reviewStatus === 'approved'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : sub.reviewStatus === 'published'
                              ? 'bg-blue-500/20 text-blue-400'
                              : sub.reviewStatus === 'rejected'
                              ? 'bg-red-500/20 text-red-400'
                              : 'bg-amber-500/20 text-amber-400'
                          }`}
                        >
                          {sub.reviewStatus}
                        </span>
                      </td>
                      <td className="p-3.5 text-right space-x-2">
                        <button
                          onClick={() => {
                            setReviewModalSub(sub);
                            setReviewNotes(sub.reviewNotes || '');
                          }}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium"
                        >
                          Audit & Review
                        </button>

                        {sub.reviewStatus === 'approved' && (
                          <button
                            onClick={() => handlePublishSubmission(sub.id)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold"
                          >
                            Publish to Catalog
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AUDIT LOGS */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">Security & Administrative Audit Log</h2>
            <p className="text-xs text-slate-400">
              Chronological ledger of logins, publications, uploads, and authorization decisions.
            </p>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="p-3.5">Timestamp</th>
                    <th className="p-3.5">Actor</th>
                    <th className="p-3.5">Action</th>
                    <th className="p-3.5">Target</th>
                    <th className="p-3.5">Outcome</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 font-mono text-[11px]">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40">
                      <td className="p-3.5 text-slate-400">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-slate-200">{log.actorEmail}</td>
                      <td className="p-3.5 font-bold text-blue-400">{log.action}</td>
                      <td className="p-3.5 text-slate-300">{log.targetRecordId}</td>
                      <td className="p-3.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] ${
                            log.outcome === 'success'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {log.outcome}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Upload Release APK */}
      {releaseModalApp && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Upload New Release APK</h3>
                <p className="text-xs text-slate-400">{releaseModalApp.name} &bull; {releaseModalApp.packageId}</p>
              </div>
              <button
                onClick={() => setReleaseModalApp(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {releaseWarning && (
              <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-800 text-amber-300 text-xs">
                {releaseWarning}
              </div>
            )}

            <form onSubmit={handleUploadRelease} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Name *</label>
                  <input
                    type="text"
                    required
                    value={releaseVersionName}
                    onChange={(e) => setReleaseVersionName(e.target.value)}
                    placeholder="e.g. 1.2.0"
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Code (integer) *</label>
                  <input
                    type="number"
                    value={releaseVersionCode}
                    onChange={(e) => setReleaseVersionCode(e.target.value)}
                    placeholder="e.g. 102"
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Release Status</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="relStatus"
                      checked={releaseStatusMode === 'published'}
                      onChange={() => setReleaseStatusMode('published')}
                      className="text-blue-600"
                    />
                    <span className="text-white">Publish Immediately</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="relStatus"
                      checked={releaseStatusMode === 'draft'}
                      onChange={() => setReleaseStatusMode('draft')}
                      className="text-blue-600"
                    />
                    <span className="text-slate-300">Save as Draft / Inactive</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Changelog / Release Notes</label>
                <textarea
                  rows={3}
                  value={releaseChangelog}
                  onChange={(e) => setReleaseChangelog(e.target.value)}
                  placeholder="Bug fixes, performance improvements..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Select APK Binary File (.apk) *</label>
                <input
                  type="file"
                  required
                  accept=".apk"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setReleaseFile(e.target.files[0]);
                    }
                  }}
                  className="w-full text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Scanned for AndroidManifest.xml and computed SHA-256 hash upon upload.
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setReleaseModalApp(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploadingRelease}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  {isUploadingRelease ? 'Inspecting & Uploading...' : 'Upload & Process Release'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Edit Metadata */}
      {editingApp && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Edit Application Metadata</h3>
                <p className="text-xs text-slate-400">{editingApp.name} ({editingApp.packageId})</p>
              </div>
              <button onClick={() => setEditingApp(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveEditApp} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Application Name</label>
                <input
                  type="text"
                  required
                  value={editFormData.name}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Short Description</label>
                <input
                  type="text"
                  required
                  value={editFormData.shortDescription}
                  onChange={(e) => setEditFormData({ ...editFormData, shortDescription: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Full Description</label>
                <textarea
                  rows={3}
                  value={editFormData.fullDescription}
                  onChange={(e) => setEditFormData({ ...editFormData, fullDescription: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Publisher</label>
                  <input
                    type="text"
                    value={editFormData.publisher}
                    onChange={(e) => setEditFormData({ ...editFormData, publisher: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Developer Contact</label>
                  <input
                    type="text"
                    value={editFormData.developerContact}
                    onChange={(e) => setEditFormData({ ...editFormData, developerContact: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Privacy Policy URL</label>
                <input
                  type="text"
                  value={editFormData.privacyPolicyUrl}
                  onChange={(e) => setEditFormData({ ...editFormData, privacyPolicyUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingApp(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold"
                >
                  {isSavingEdit ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: App Preview */}
      {previewApp && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-blue-400" />
                <span className="font-bold text-white text-sm">Storefront Preview</span>
                <span className="text-[10px] px-2 py-0.5 rounded uppercase font-mono bg-blue-500/20 text-blue-300">
                  {previewApp.publicationStatus}
                </span>
              </div>
              <button onClick={() => setPreviewApp(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="flex items-center gap-4">
              <img src={previewApp.iconUrl} alt="" className="w-16 h-16 rounded-xl object-cover bg-slate-800" />
              <div>
                <h2 className="text-lg font-bold text-white">{previewApp.name}</h2>
                <div className="text-xs text-slate-400">{previewApp.publisher} &bull; {previewApp.category}</div>
                <div className="text-[11px] font-mono text-blue-400 mt-0.5">{previewApp.packageId}</div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed whitespace-pre-line">
              {previewApp.fullDescription}
            </div>

            <div className="text-xs text-slate-400 space-y-1">
              <div><strong>Min Android:</strong> {previewApp.minAndroidVersion}</div>
              <div><strong>Privacy Policy:</strong> {previewApp.privacyPolicyUrl}</div>
              <div><strong>Permissions:</strong> {previewApp.permissions.join(', ') || 'None'}</div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: Review Developer Submission */}
      {reviewModalSub && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Audit Developer Submission</h3>
                <p className="text-xs text-slate-400">{reviewModalSub.appName} ({reviewModalSub.packageId})</p>
              </div>
              <button
                onClick={() => setReviewModalSub(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-semibold text-white">Developer Contact</div>
                <div>{reviewModalSub.developerName} &bull; {reviewModalSub.developerEmail}</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-semibold text-white flex items-center gap-1.5 text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Ownership Declaration</span>
                </div>
                <p className="text-slate-400 italic">
                  "{reviewModalSub.authorizationDeclaration?.legalEntityStatement}"
                </p>
              </div>

              {reviewModalSub.apkSha256 && (
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="font-semibold text-white">Uploaded APK SHA-256</div>
                  <div className="font-mono text-[10px] text-slate-400 break-all select-all">
                    {reviewModalSub.apkSha256}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-medium mb-1">Administrative Review Notes</label>
                <textarea
                  rows={2}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Notes on authorization proof, permissions check, or rejection reason..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => handleReviewSubmission('rejected')}
                disabled={isReviewing}
                className="px-4 py-2 bg-red-950/60 hover:bg-red-900/60 text-red-300 rounded-lg text-xs font-semibold border border-red-800/40"
              >
                Reject
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleReviewSubmission('under_review')}
                  disabled={isReviewing}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Mark Under Review
                </button>
                <button
                  type="button"
                  onClick={() => handleReviewSubmission('approved')}
                  disabled={isReviewing}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                >
                  Approve Submission
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: Delete Application Confirmation Modal */}
      {appToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-red-400 border-b border-slate-800 pb-3">
              <div className="p-2 bg-red-500/10 rounded-xl">
                <Trash2 className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Application</h3>
                <p className="text-xs text-slate-400">This action will remove the app from the catalog</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p>
                Are you sure you want to delete <strong className="text-white">{appToDelete.name}</strong> (<span className="font-mono text-blue-400">{appToDelete.packageId}</span>)?
              </p>

              <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={deleteApkFilesChecked}
                  onChange={(e) => setDeleteApkFilesChecked(e.target.checked)}
                  className="mt-0.5 rounded bg-slate-900 border-slate-700 text-red-600 focus:ring-red-500"
                />
                <div>
                  <span className="font-medium text-white block">Delete stored APK binary files</span>
                  <span className="text-slate-400 text-[11px] block mt-0.5">
                    Uncheck to keep uploaded APK packages in storage while deleting the catalog record.
                  </span>
                </div>
              </label>

              {deleteAppError && (
                <div className="p-2.5 rounded-lg bg-red-950/50 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{deleteAppError}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setAppToDelete(null)}
                disabled={isDeletingApp}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteApp}
                disabled={isDeletingApp}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5"
              >
                {isDeletingApp ? 'Deleting...' : 'Confirm Permanent Deletion'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: Status Change Confirmation Modal */}
      {statusChangeTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400">
                <AlertTriangle className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Confirm Publication Status</h3>
                <p className="text-xs text-slate-400">{statusChangeTarget.app.name}</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Change status of <strong className="text-white">{statusChangeTarget.app.name}</strong> to{' '}
                <span className="uppercase font-mono text-blue-400 font-bold px-1.5 py-0.5 rounded bg-blue-500/10">
                  {statusChangeTarget.newStatus}
                </span>?
              </p>
              <p className="text-slate-400">
                {statusChangeTarget.newStatus === 'published' && 'This will make the application and its verified APK packages publicly downloadable in the store.'}
                {statusChangeTarget.newStatus === 'draft' && 'This will hide the application from the public store catalog while keeping all records and files intact.'}
                {statusChangeTarget.newStatus === 'archived' && 'This will archive the application, preventing any public discovery or downloads.'}
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setStatusChangeTarget(null)}
                disabled={isUpdatingStatus}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmUpdateAppStatus}
                disabled={isUpdatingStatus}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold"
              >
                {isUpdatingStatus ? 'Updating...' : `Confirm ${statusChangeTarget.newStatus.toUpperCase()}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 7: Publish Submission Confirmation Modal */}
      {submissionToPublish && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-400">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Publish Developer Submission</h3>
                <p className="text-xs text-slate-400">{submissionToPublish.appName}</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Convert approved developer submission for <strong className="text-white">{submissionToPublish.appName}</strong> (<span className="font-mono text-blue-400">{submissionToPublish.packageId}</span>) into a live public store listing?
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSubmissionToPublish(null)}
                disabled={isPublishingSubmission}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmPublishSubmission}
                disabled={isPublishingSubmission}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
              >
                {isPublishingSubmission ? 'Publishing...' : 'Confirm Publish'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 8: Set Active Release Confirmation Modal */}
      {releaseToSetActive && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400">
                <CheckCircle2 className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Activate Release</h3>
                <p className="text-xs text-slate-400">Release ID: {releaseToSetActive.releaseId}</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Set version <strong className="text-white">v{releaseToSetActive.versionName || '1.0.0'}</strong> as the current active version for public store downloads?
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setReleaseToSetActive(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmSetCurrentRelease}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold"
              >
                Set as Active
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 9: Delete Release Confirmation Modal */}
      {releaseToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2 bg-red-500/10 rounded-xl text-red-400">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Release Package</h3>
                <p className="text-xs text-slate-400">Release ID: {releaseToDelete.releaseId}</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Delete release record <strong className="text-white">v{releaseToDelete.versionName || '1.0.0'}</strong> and its stored APK binary package? This action cannot be undone.
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setReleaseToDelete(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteRelease}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
