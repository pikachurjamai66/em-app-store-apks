import React, { useState, useEffect } from 'react';
import { AppItem, ReleaseItem } from '../types/index.ts';
import {
  Download,
  ShieldCheck,
  Tag,
  HardDrive,
  Calendar,
  CheckCircle2,
  Copy,
  Check,
  ArrowLeft,
  ExternalLink,
  AlertTriangle,
  History,
  Lock,
  Layers,
  Smartphone
} from 'lucide-react';

interface AppDetailsPageProps {
  slugOrId: string;
  onBack: () => void;
  onNavigate: (path: string) => void;
}

export const AppDetailsPage: React.FC<AppDetailsPageProps> = ({
  slugOrId,
  onBack,
  onNavigate
}) => {
  const [app, setApp] = useState<AppItem | null>(null);
  const [releases, setReleases] = useState<ReleaseItem[]>([]);
  const [downloads, setDownloads] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedSha, setCopiedSha] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [activeScreenshot, setActiveScreenshot] = useState<string | null>(null);

  useEffect(() => {
    const fetchAppDetails = async () => {
      setIsLoading(true);
      setErrorMessage(null);
      try {
        const res = await fetch(`/api/apps/${slugOrId}`);
        if (!res.ok) {
          throw new Error('Application could not be located or is not currently published.');
        }
        const data = await res.json();
        setApp(data.app);
        setReleases(data.releases || []);
        setDownloads(data.downloads || 0);
        if (data.app?.screenshots?.length > 0) {
          setActiveScreenshot(data.app.screenshots[0]);
        }
      } catch (err) {
        setErrorMessage(err instanceof Error ? err.message : 'Failed to fetch application details');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAppDetails();
  }, [slugOrId]);

  const currentRelease = releases.find(r => r.id === app?.currentReleaseId) || releases[0] || null;

  const handleDownload = (releaseId?: string) => {
    const targetReleaseId = releaseId || currentRelease?.id;
    if (!targetReleaseId) return;

    setIsDownloading(true);
    // Trigger direct stream download
    const downloadUrl = `/api/download/${targetReleaseId}?client=web`;
    window.location.href = downloadUrl;

    setTimeout(() => {
      setIsDownloading(false);
      setDownloads(prev => prev + 1);
    }, 2000);
  };

  const handleCopySha = (sha: string) => {
    navigator.clipboard.writeText(sha);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const formatBytes = (bytes: number): string => {
    if (!bytes || bytes === 0) return 'N/A';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1) return `${mb.toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  const formatDate = (isoString: string): string => {
    try {
      return new Date(isoString).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return isoString;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 text-center">
        <div className="inline-block w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-400">Loading verified application metadata...</p>
      </div>
    );
  }

  if (errorMessage || !app) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
        <h2 className="text-xl font-bold text-white">Application Not Found</h2>
        <p className="text-sm text-slate-400">{errorMessage || 'The requested application is unavailable.'}</p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Application Catalog</span>
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Catalog</span>
      </button>

      {/* Main Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-5">
            <img
              src={app.iconUrl}
              alt={app.name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover bg-slate-800 border border-slate-700/80 shadow-md flex-shrink-0"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=256&h=256&fit=crop&q=80';
              }}
            />

            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {app.name}
                </h1>
                {app.isDemonstration && (
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Demonstration Record
                  </span>
                )}
                {app.publicationStatus !== 'published' && (
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30">
                    {app.publicationStatus} Listing
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-400 flex-wrap">
                <span>By <strong className="text-slate-200">{app.publisher}</strong></span>
                <span>&bull;</span>
                <span className="text-blue-400 font-medium">{app.category}</span>
                <span>&bull;</span>
                <span className="font-mono text-slate-400">ID: {app.packageId}</span>
              </div>

              <div className="flex items-center gap-3 pt-1 text-xs text-slate-400">
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Authorized Distribution
                </span>
                <span>&bull;</span>
                <span>{downloads} recorded downloads</span>
              </div>
            </div>
          </div>

          {/* Download Action Box */}
          <div className="w-full md:w-auto flex flex-col sm:flex-row md:flex-col gap-2">
            <button
              onClick={() => handleDownload()}
              disabled={isDownloading || !currentRelease || app.publicationStatus !== 'published'}
              className="px-8 py-3.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-blue-600/30 transition-all"
            >
              <Download className="w-5 h-5" />
              <span>
                {isDownloading
                  ? 'Starting APK Download...'
                  : !currentRelease
                  ? 'No APK Package Available'
                  : app.publicationStatus !== 'published'
                  ? 'Listing Currently Unpublished'
                  : 'Download APK Package'}
              </span>
            </button>

            {currentRelease ? (
              <div className="text-[11px] text-center text-slate-400">
                <span>v{currentRelease.versionName}</span> &bull;{' '}
                <span>{formatBytes(currentRelease.fileSize)}</span>
              </div>
            ) : (
              <div className="text-[10px] text-center text-amber-400">
                Pending release upload
              </div>
            )}
          </div>
        </div>

        {/* Companion App Source Notice */}
        {app.packageId === 'com.em.store' && (
          <div className="mt-6 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300 flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-white block font-semibold">Official Companion Client Source Available:</strong>
              <p>
                This application is the native Android companion client for EM App Store. The source code is organized under <code className="text-white font-mono">/android</code> with Jetpack Compose, Material 3, and full administrator management screens. To build the native APK on a developer machine, run <code className="text-emerald-400 font-mono">cd android && ./gradlew assembleRelease</code>.
              </p>
            </div>
          </div>
        )}

        {/* SHA-256 Integrity Verification Box */}
        {currentRelease && (
          <div className="mt-8 pt-6 border-t border-slate-800/80 bg-slate-950/60 -mx-6 sm:-mx-8 -mb-6 sm:-mb-8 p-6 sm:p-8 rounded-b-2xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Cryptographic SHA-256 Release Hash</span>
                </div>
                <div className="font-mono text-[11px] sm:text-xs text-slate-400 break-all select-all">
                  {currentRelease.sha256}
                </div>
              </div>

              <button
                onClick={() => handleCopySha(currentRelease.sha256)}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex-shrink-0"
              >
                {copiedSha ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Hash</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Two Column Layout: Description & Specs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Description, Screenshots, Changelog */}
        <div className="lg:col-span-2 space-y-8">
          {/* About Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">About This Application</h2>
            <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
              {app.fullDescription}
            </div>
          </div>

          {/* Screenshots Gallery */}
          {app.screenshots && app.screenshots.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-bold text-white">Screenshots</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {app.screenshots.map((url, i) => (
                  <img
                    key={i}
                    src={url}
                    alt={`${app.name} preview ${i + 1}`}
                    className="w-full h-48 sm:h-56 object-cover rounded-xl border border-slate-800 bg-slate-950"
                  />
                ))}
              </div>
            </div>
          )}

          {/* Changelog & Release Notes */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <History className="w-5 h-5 text-blue-400" />
                <span>What's New in v{currentRelease?.versionName || '1.0.0'}</span>
              </h2>
              <span className="text-xs text-slate-400">
                {formatDate(currentRelease?.publishedAt || currentRelease?.createdAt || app.updatedAt)}
              </span>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-800">
              {currentRelease?.changelog || 'No specific release notes supplied for this build.'}
            </p>
          </div>

          {/* Version History Table (Rollback & Earlier Releases) */}
          {releases.length > 1 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-bold text-white">Previous Releases</h2>
              <div className="divide-y divide-slate-800">
                {releases.map((rel) => (
                  <div key={rel.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="font-mono font-semibold text-white">
                        v{rel.versionName}{' '}
                        <span className="text-slate-400 font-normal">
                          (Code: {rel.versionCode})
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px] mt-0.5">
                        {formatBytes(rel.fileSize)} &bull; {formatDate(rel.publishedAt || rel.createdAt)}
                      </div>
                    </div>

                    <button
                      onClick={() => handleDownload(rel.id)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium flex items-center gap-1.5 border border-slate-700"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Technical Specifications & Verification */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-3">
              Technical Specifications
            </h3>

            <dl className="space-y-3 text-xs">
              <div>
                <dt className="text-slate-400">Package Identifier</dt>
                <dd className="font-mono text-slate-200 mt-0.5 select-all">{app.packageId}</dd>
              </div>

              <div>
                <dt className="text-slate-400">Current Version</dt>
                <dd className="font-mono text-slate-200 mt-0.5">
                  v{currentRelease?.versionName || '1.0.0'} (Version Code: {currentRelease?.versionCode || 1})
                </dd>
              </div>

              <div>
                <dt className="text-slate-400">Minimum Android Version</dt>
                <dd className="text-slate-200 mt-0.5">{app.minAndroidVersion}</dd>
              </div>

              {app.targetAndroidVersion && (
                <div>
                  <dt className="text-slate-400">Target SDK Version</dt>
                  <dd className="text-slate-200 mt-0.5">{app.targetAndroidVersion}</dd>
                </div>
              )}

              <div>
                <dt className="text-slate-400">Package File Size</dt>
                <dd className="text-slate-200 mt-0.5">
                  {currentRelease ? formatBytes(currentRelease.fileSize) : 'N/A'}
                </dd>
              </div>

              <div>
                <dt className="text-slate-400">Last Updated</dt>
                <dd className="text-slate-200 mt-0.5">{formatDate(app.updatedAt)}</dd>
              </div>

              {currentRelease?.signatureCertSha256 && (
                <div>
                  <dt className="text-slate-400">Signing Certificate SHA-256</dt>
                  <dd className="font-mono text-[10px] text-slate-300 mt-0.5 break-all">
                    {currentRelease.signatureCertSha256}
                  </dd>
                </div>
              )}
            </dl>
          </div>

          {/* Android Permissions Disclosed */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-3 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-blue-400" />
              <span>Declared Permissions</span>
            </h3>

            {app.permissions && app.permissions.length > 0 ? (
              <div className="space-y-1.5">
                {app.permissions.map((perm, i) => (
                  <div
                    key={i}
                    className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 break-all"
                  >
                    {perm}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400">No special Android permissions declared.</p>
            )}
          </div>

          {/* Publisher & Dispute Resolution */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-3">
              Publisher & Legal
            </h3>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Developer</span>
                <span className="text-slate-200 font-medium">{app.publisher}</span>
              </div>

              {app.privacyPolicyUrl && (
                <div className="pt-2">
                  <a
                    href={app.privacyPolicyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 font-medium"
                  >
                    <span>Developer Privacy Policy</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Notice an authorization infringement or suspicious software behavior?
              </p>
              <button
                onClick={() => onNavigate('/takedown')}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 transition-colors"
              >
                File Copyright Notice / Takedown
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
