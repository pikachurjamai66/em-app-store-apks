import React, { useState } from 'react';
import { Upload, ShieldCheck, CheckCircle2, AlertTriangle, FileText, ArrowLeft } from 'lucide-react';
import { parseApiResponse } from '../utils/api.ts';

interface SubmitAppPageProps {
  onBack: () => void;
  onNavigate: (path: string) => void;
}

export const SubmitAppPage: React.FC<SubmitAppPageProps> = ({ onBack, onNavigate }) => {
  const [formData, setFormData] = useState({
    developerName: '',
    developerEmail: '',
    appName: '',
    packageId: '',
    category: 'Tools',
    shortDescription: '',
    fullDescription: '',
    versionName: '1.0.0',
    minAndroidVersion: 'Android 8.0 (API 26)',
    privacyPolicyUrl: '',
    permissionsInput: 'android.permission.INTERNET',
    legalEntityStatement: '',
    ownsCopyrightOrLicense: false,
    developerAuthorizedDistribution: false,
    termsAccepted: false
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<{ id: string; message: string } | null>(null);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.name.toLowerCase().endsWith('.apk')) {
        setErrorMsg('Please select a valid Android package file ending with .apk');
        setSelectedFile(null);
        return;
      }
      setSelectedFile(file);
      setErrorMsg(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Validation checks
    if (!formData.ownsCopyrightOrLicense || !formData.developerAuthorizedDistribution || !formData.termsAccepted) {
      setErrorMsg('You must check all three authorization declarations before submitting.');
      return;
    }

    if (!formData.appName || !formData.packageId || !formData.developerName || !formData.developerEmail) {
      setErrorMsg('Please provide application name, package identifier, developer name, and contact email.');
      return;
    }

    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i;
    if (!packageRegex.test(formData.packageId.trim())) {
      setErrorMsg('Invalid Android package identifier format. Example: com.developer.appname');
      return;
    }

    setIsSubmitting(true);

    try {
      const formPayload = new FormData();
      formPayload.append('developerName', formData.developerName);
      formPayload.append('developerEmail', formData.developerEmail);
      formPayload.append('appName', formData.appName);
      formPayload.append('packageId', formData.packageId);
      formPayload.append('category', formData.category);
      formPayload.append('shortDescription', formData.shortDescription);
      formPayload.append('fullDescription', formData.fullDescription);
      formPayload.append('versionName', formData.versionName);
      formPayload.append('minAndroidVersion', formData.minAndroidVersion);
      formPayload.append('privacyPolicyUrl', formData.privacyPolicyUrl);
      formPayload.append('ownsCopyrightOrLicense', String(formData.ownsCopyrightOrLicense));
      formPayload.append('developerAuthorizedDistribution', String(formData.developerAuthorizedDistribution));
      formPayload.append('termsAccepted', String(formData.termsAccepted));
      formPayload.append('legalEntityStatement', formData.legalEntityStatement || `Submitted by ${formData.developerName}`);

      const perms = formData.permissionsInput.split(',').map(s => s.trim()).filter(Boolean);
      formPayload.append('permissions', JSON.stringify(perms));

      if (selectedFile) {
        formPayload.append('apkFile', selectedFile);
      }

      const res = await fetch('/api/submissions', {
        method: 'POST',
        body: formPayload
      });

      const data = await parseApiResponse<{ success: boolean; submissionId: string; message: string }>(res);

      setSuccessInfo({
        id: data.submissionId,
        message: data.message
      });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (successInfo) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-white">Application Submitted for Review</h2>
        <p className="text-sm text-slate-300 leading-relaxed">
          {successInfo.message}
        </p>
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-400">
          Tracking ID: <span className="text-blue-400 font-semibold">{successInfo.id}</span>
        </div>
        <p className="text-xs text-slate-400">
          EM App Store administrators will inspect the binary format, verify the declared ownership, and calculate cryptographic checksums before publishing to the public store.
        </p>
        <div className="pt-4 flex justify-center gap-3">
          <button
            onClick={() => onNavigate('/apps')}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold"
          >
            Browse Public Catalog
          </button>
          <button
            onClick={() => {
              setSuccessInfo(null);
              setSelectedFile(null);
            }}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700"
          >
            Submit Another App
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return</span>
      </button>

      <div className="border-b border-slate-800 pb-6 space-y-2">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
          <Upload className="w-8 h-8 text-blue-400" />
          <span>Submit an Android Application</span>
        </h1>
        <p className="text-sm text-slate-400">
          Submit your APK package for EM App Store publication. All submissions undergo administrative review and legal distribution authorization checks.
        </p>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 flex-shrink-0 text-red-400 mt-0.5" />
          <div>
            <strong className="block font-semibold">Submission Incomplete</strong>
            <span>{errorMsg}</span>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Section 1: Developer Information */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white border-b border-slate-800 pb-2">
            1. Developer & Legal Contact
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Developer / Publisher Name *
              </label>
              <input
                type="text"
                name="developerName"
                value={formData.developerName}
                onChange={handleInputChange}
                required
                placeholder="e.g. Zenith Software Foundation"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Official Contact Email *
              </label>
              <input
                type="email"
                name="developerEmail"
                value={formData.developerEmail}
                onChange={handleInputChange}
                required
                placeholder="developer@example.org"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Application Metadata */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white border-b border-slate-800 pb-2">
            2. Application Metadata & Requirements
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Application Name *
              </label>
              <input
                type="text"
                name="appName"
                value={formData.appName}
                onChange={handleInputChange}
                required
                placeholder="e.g. Zenith Markdown Notes"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Android Package Identifier *
              </label>
              <input
                type="text"
                name="packageId"
                value={formData.packageId}
                onChange={handleInputChange}
                required
                placeholder="e.g. org.zenith.notes"
                className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Reverse-DNS format matching AndroidManifest.xml package
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Category
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Tools">Tools</option>
                <option value="Productivity">Productivity</option>
                <option value="Communication">Communication</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Games">Games</option>
                <option value="Education">Education</option>
                <option value="Social">Social</option>
                <option value="Utilities">Utilities</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Version Name
              </label>
              <input
                type="text"
                name="versionName"
                value={formData.versionName}
                onChange={handleInputChange}
                placeholder="1.0.0"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Min Android OS
              </label>
              <input
                type="text"
                name="minAndroidVersion"
                value={formData.minAndroidVersion}
                onChange={handleInputChange}
                placeholder="Android 8.0 (API 26)"
                className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Short Description *
            </label>
            <input
              type="text"
              name="shortDescription"
              value={formData.shortDescription}
              onChange={handleInputChange}
              required
              maxLength={150}
              placeholder="Brief 1-line summary of what the application does"
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Full Description
            </label>
            <textarea
              name="fullDescription"
              value={formData.fullDescription}
              onChange={handleInputChange}
              rows={4}
              placeholder="Detailed application overview, key features, architecture, and user workflow..."
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Privacy Policy URL
            </label>
            <input
              type="url"
              name="privacyPolicyUrl"
              value={formData.privacyPolicyUrl}
              onChange={handleInputChange}
              placeholder="https://example.org/privacy"
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Declared Manifest Permissions (comma-separated)
            </label>
            <input
              type="text"
              name="permissionsInput"
              value={formData.permissionsInput}
              onChange={handleInputChange}
              placeholder="android.permission.INTERNET, android.permission.CAMERA"
              className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Section 3: APK Upload */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white border-b border-slate-800 pb-2">
            3. Android APK Package Binary
          </h2>

          <div className="border-2 border-dashed border-slate-700 hover:border-blue-500/60 rounded-xl p-6 text-center transition-colors">
            <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <div className="text-xs text-slate-300 font-medium">
              {selectedFile ? (
                <span className="text-blue-400 font-bold">{selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)</span>
              ) : (
                'Select APK file to upload'
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              APK files up to 150MB. File contents will be verified for valid ZIP container headers and SHA-256 hashed.
            </p>
            <input
              type="file"
              accept=".apk"
              onChange={handleFileChange}
              className="mt-3 block mx-auto text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Section 4: Mandatory Legal Authorization Declarations */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>4. Mandatory Ownership & Distribution Declarations</span>
          </h2>

          <p className="text-xs text-slate-400 leading-relaxed">
            EM App Store requires explicit legal authorization from developers to distribute software.
            Submissions without confirmed ownership declarations will be rejected automatically.
          </p>

          <div className="space-y-3 pt-2">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                name="ownsCopyrightOrLicense"
                checked={formData.ownsCopyrightOrLicense}
                onChange={handleInputChange}
                className="mt-1 rounded bg-slate-950 border-slate-700 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-xs text-slate-300">
                <strong className="text-white block">Intellectual Property Ownership Declaration</strong>
                I confirm that I or my organization represent the sole author, copyright holder, or legally authorized licensee of this application software.
              </span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                name="developerAuthorizedDistribution"
                checked={formData.developerAuthorizedDistribution}
                onChange={handleInputChange}
                className="mt-1 rounded bg-slate-950 border-slate-700 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-xs text-slate-300">
                <strong className="text-white block">Distribution Consent Grant</strong>
                I hereby grant EM App Store non-exclusive authorization to host, verify, and publicly distribute the submitted Android APK package to end users.
              </span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                name="termsAccepted"
                checked={formData.termsAccepted}
                onChange={handleInputChange}
                className="mt-1 rounded bg-slate-950 border-slate-700 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-xs text-slate-300">
                <strong className="text-white block">Platform Terms & Integrity Confirmation</strong>
                I accept the EM App Store Developer Terms and confirm this package contains no backdoors, cryptominers, unauthorized tracking, or malware.
              </span>
            </label>
          </div>

          <div className="pt-3">
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Authorized Representative Statement
            </label>
            <input
              type="text"
              name="legalEntityStatement"
              value={formData.legalEntityStatement}
              onChange={handleInputChange}
              placeholder="e.g. Authorized by Jane Doe, Head of Engineering at Aero Labs Inc."
              className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>{isSubmitting ? 'Verifying APK & Submitting...' : 'Submit Application for Review'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
