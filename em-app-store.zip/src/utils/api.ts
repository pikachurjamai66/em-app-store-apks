/**
 * Secure and robust API response parser for EM App Store frontend.
 * Safely parses JSON responses and converts any non-JSON or HTML error responses
 * (such as Vite SPA fallbacks or unhandled server error pages) into readable error messages
 * instead of throwing uncaught SyntaxError "Unexpected token '<', "<!doctype "... is not valid JSON".
 */
export async function parseApiResponse<T = any>(res: Response): Promise<T> {
  const contentType = res.headers.get('content-type') || '';

  if (contentType.includes('application/json')) {
    try {
      const data = await res.json();
      if (!res.ok) {
        const errorMsg = data.error || data.message || `Server returned error status ${res.status} (${res.statusText})`;
        throw new Error(errorMsg);
      }
      return data as T;
    } catch (err: any) {
      if (!res.ok && err.message) throw err;
      throw new Error(`Failed to parse JSON server response (HTTP ${res.status}): ${err.message}`);
    }
  }

  // Response is not application/json — could be HTML error, plaintext, or SPA fallback
  const rawText = await res.text();

  if (!res.ok) {
    // Extract readable text from HTML if present
    if (rawText.includes('<!DOCTYPE') || rawText.includes('<!doctype') || rawText.includes('<html')) {
      const preMatch = rawText.match(/<pre[^>]*>([\s\S]*?)<\/pre>/i);
      const titleMatch = rawText.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const cleanMessage = preMatch
        ? preMatch[1].replace(/<[^>]+>/g, '').trim()
        : titleMatch
        ? titleMatch[1].trim()
        : `HTTP ${res.status} ${res.statusText}`;

      throw new Error(`Server Error (${res.status}): ${cleanMessage}`);
    }

    throw new Error(rawText.trim() || `Server error (${res.status}: ${res.statusText})`);
  }

  // If HTTP status is 200/201 but body contains HTML (e.g. Vite SPA index.html fallback)
  if (rawText.includes('<!doctype') || rawText.includes('<!DOCTYPE') || rawText.includes('<html')) {
    throw new Error(
      `API endpoint returned an HTML document instead of JSON (HTTP ${res.status}). The requested endpoint may not exist or was caught by frontend routing.`
    );
  }

  try {
    return JSON.parse(rawText) as T;
  } catch {
    throw new Error(`Expected JSON response, but server returned plaintext: "${rawText.slice(0, 120)}..."`);
  }
}
