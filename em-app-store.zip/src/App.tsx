import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { AppsPage } from './pages/AppsPage.tsx';
import { AppDetailsPage } from './pages/AppDetailsPage.tsx';
import { CategoriesPage } from './pages/CategoriesPage.tsx';
import { DeveloperInfoPage } from './pages/DeveloperInfoPage.tsx';
import { SubmitAppPage } from './pages/SubmitAppPage.tsx';
import { AndroidClientPage } from './pages/AndroidClientPage.tsx';
import { PolicyPages } from './pages/PolicyPages.tsx';
import { AdminDashboard } from './pages/admin/AdminDashboard.tsx';
import { NotFoundPage } from './pages/NotFoundPage.tsx';
import { AdminProvider } from './context/AdminContext.tsx';
import { AppItem, PlatformStats } from './types/index.ts';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });
  const [apps, setApps] = useState<AppItem[]>([]);
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [catalogError, setCatalogError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync with browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Fetch initial apps and stats
  const refreshCatalog = async () => {
    try {
      const [appsRes, statsRes] = await Promise.all([
        fetch('/api/apps'),
        fetch('/api/stats')
      ]);

      if (!appsRes.ok) {
        const errJson = await appsRes.json().catch(() => ({}));
        setCatalogError(errJson.error || `Unable to load catalog from authoritative server (HTTP ${appsRes.status})`);
        return;
      }

      setCatalogError(null);
      const data = await appsRes.json();
      setApps(data.apps || []);

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }
    } catch (err: any) {
      console.error('Failed to load EM App Store catalog:', err);
      setCatalogError(err.message || 'Network connection failed. Could not reach authoritative application catalog.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshCatalog();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleQuickDownload = (app: AppItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!app.currentReleaseId) {
      navigate(`/app/${app.slug || app.id}`);
      return;
    }
    showToast(`Initiating APK download for ${app.name}...`);
    window.location.href = `/api/download/${app.currentReleaseId}?client=web`;
    setTimeout(() => {
      refreshCatalog();
    }, 1500);
  };

  const handleSearch = (query: string) => {
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  // Route Dispatcher
  const renderCurrentView = () => {
    // 1. Home
    if (currentPath === '/' || currentPath === '') {
      return (
        <HomePage
          apps={apps}
          stats={stats}
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onNavigate={navigate}
          onSearch={handleSearch}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 2. App Details: /app/:slugOrId
    if (currentPath.startsWith('/app/')) {
      const slugOrId = currentPath.substring(5).split('/')[0];
      return (
        <AppDetailsPage
          slugOrId={slugOrId}
          onBack={() => navigate('/apps')}
          onNavigate={navigate}
        />
      );
    }

    // 3. All Apps
    if (currentPath === '/apps') {
      return (
        <AppsPage
          apps={apps}
          pageTitle="All Applications"
          pageSubtitle="Complete verified index of first-party and authorized developer APK packages."
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 4. Latest
    if (currentPath === '/latest') {
      return (
        <AppsPage
          apps={apps}
          initialSort="latest"
          pageTitle="Latest Releases"
          pageSubtitle="Recently published packages on the EM App Store repository."
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 5. Recently Updated
    if (currentPath === '/recently-updated') {
      return (
        <AppsPage
          apps={apps}
          initialSort="updated"
          pageTitle="Recently Updated Applications"
          pageSubtitle="Applications with verified version upgrades and new releases."
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 6. Popular
    if (currentPath === '/popular') {
      return (
        <AppsPage
          apps={apps}
          initialSort="popular"
          pageTitle="Popular Applications"
          pageSubtitle="Applications ranked by real, verified download event counts."
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 7. Search Results: /search?q=...
    if (currentPath.startsWith('/search')) {
      const urlParams = new URLSearchParams(window.location.search);
      const query = urlParams.get('q') || '';
      return (
        <AppsPage
          apps={apps}
          initialSearch={query}
          pageTitle={`Search Results`}
          pageSubtitle={query ? `Matching packages for "${query}"` : 'Enter a search term above'}
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 8. Categories: /categories or /category/:cat
    if (currentPath === '/categories') {
      return (
        <CategoriesPage
          apps={apps}
          onSelectCategory={(category) => navigate(`/category/${category}`)}
        />
      );
    }

    if (currentPath.startsWith('/category/')) {
      const category = decodeURIComponent(currentPath.substring(10));
      return (
        <AppsPage
          apps={apps}
          initialCategory={category}
          pageTitle={`${category} Applications`}
          pageSubtitle={`Verified Android packages under the ${category} category.`}
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onQuickDownload={handleQuickDownload}
        />
      );
    }

    // 9. Developer Guidelines & Submission
    if (currentPath === '/developer-info') {
      return <DeveloperInfoPage onNavigate={navigate} />;
    }

    if (currentPath === '/submit') {
      return (
        <SubmitAppPage
          onBack={() => navigate('/')}
          onNavigate={navigate}
        />
      );
    }

    // 10. Android Client: EM Store
    if (currentPath === '/android-client') {
      return (
        <AndroidClientPage
          apps={apps}
          onSelectApp={(app) => navigate(`/app/${app.slug || app.id}`)}
          onNavigate={navigate}
        />
      );
    }

    // 11. Policy pages
    if (currentPath === '/privacy') {
      return <PolicyPages type="privacy" onNavigate={navigate} />;
    }
    if (currentPath === '/terms') {
      return <PolicyPages type="terms" onNavigate={navigate} />;
    }
    if (currentPath === '/takedown') {
      return <PolicyPages type="takedown" onNavigate={navigate} />;
    }
    if (currentPath === '/contact') {
      return <PolicyPages type="contact" onNavigate={navigate} />;
    }

    // 12. Administrator Dashboard
    if (currentPath.startsWith('/admin')) {
      return <AdminDashboard />;
    }

    // 13. Fallback: 404
    return <NotFoundPage onNavigateHome={() => navigate('/')} />;
  };

  return (
    <AdminProvider>
      <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-blue-600 selection:text-white">
        {/* Navigation Bar */}
        <Navbar
          currentPath={currentPath}
          onNavigate={navigate}
          onSearch={handleSearch}
        />

        {/* Global Catalog Error Banner */}
        {catalogError && (
          <div className="bg-red-500/10 border-b border-red-500/20 text-red-300 py-2.5 px-4 text-xs text-center flex items-center justify-center gap-2">
            <span>⚠️ {catalogError}</span>
            <button
              onClick={refreshCatalog}
              className="px-2 py-0.5 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded font-semibold text-[11px]"
            >
              Retry
            </button>
          </div>
        )}

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-2xl border border-blue-400/40 animate-bounce">
            {toastMessage}
          </div>
        )}

        {/* Main Route Content */}
        <main className="flex-1">
          {isLoading ? (
            <div className="max-w-7xl mx-auto px-4 py-24 text-center">
              <div className="inline-block w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4" />
              <p className="text-sm text-slate-400">Connecting to EM App Store repository...</p>
            </div>
          ) : (
            renderCurrentView()
          )}
        </main>

        {/* Footer */}
        <Footer onNavigate={navigate} />
      </div>
    </AdminProvider>
  );
}
