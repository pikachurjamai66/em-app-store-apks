import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { parseApiResponse } from '../utils/api.ts';

interface AdminContextType {
  adminToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (key: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  fetchWithAuth: (url: string, options?: RequestInit) => Promise<Response>;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('em_admin_token') || null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Validate stored token on mount
  useEffect(() => {
    const verifyToken = async () => {
      if (!adminToken) {
        setIsAuthenticated(false);
        setIsLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/admin/me', {
          headers: {
            'x-admin-token': adminToken
          }
        });
        if (res.ok) {
          setIsAuthenticated(true);
        } else {
          // Token is no longer valid
          localStorage.removeItem('em_admin_token');
          setAdminToken(null);
          setIsAuthenticated(false);
        }
      } catch (err) {
        console.error('Failed to verify admin token:', err);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    verifyToken();
  }, [adminToken]);

  const login = async (key: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key })
      });

      const data = await parseApiResponse<{ success: boolean; token?: string; error?: string }>(res);
      if (data.token) {
        localStorage.setItem('em_admin_token', data.token);
        setAdminToken(data.token);
        setIsAuthenticated(true);
        return { success: true };
      }
      return { success: false, error: data.error || 'Invalid administrator key.' };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Network failure' };
    }
  };

  const logout = () => {
    localStorage.removeItem('em_admin_token');
    setAdminToken(null);
    setIsAuthenticated(false);
  };

  const fetchWithAuth = async (url: string, options: RequestInit = {}): Promise<Response> => {
    const headers = new Headers(options.headers || {});
    if (adminToken) {
      headers.set('x-admin-token', adminToken);
      headers.set('Authorization', `Bearer ${adminToken}`);
    }
    return fetch(url, {
      ...options,
      headers
    });
  };

  return (
    <AdminContext.Provider
      value={{
        adminToken,
        isAuthenticated,
        isLoading,
        login,
        logout,
        fetchWithAuth
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = (): AdminContextType => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};
