export interface AppItem {
  id: string;
  name: string;
  slug: string;
  packageId: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  iconUrl: string;
  screenshots: string[];
  developerId: string;
  publisher: string;
  developerContact?: string;
  currentReleaseId: string;
  publicationStatus: 'draft' | 'published' | 'unlisted' | 'archived';
  privacyPolicyUrl: string;
  minAndroidVersion: string;
  targetAndroidVersion?: string;
  permissions: string[];
  isDemonstration?: boolean;
  downloads: number;
  createdAt: string;
  updatedAt: string;
  currentRelease?: {
    id?: string;
    versionName: string;
    versionCode: number;
    fileSize: number;
    sha256: string;
    changelog: string;
    publishedAt: string;
    verificationStatus?: string;
    verificationSummary?: string;
  } | null;
}

export interface ReleaseItem {
  id: string;
  appId: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  apkStoragePath: string;
  fileSize: number;
  sha256: string;
  changelog: string;
  releaseStatus: 'draft' | 'pending_review' | 'approved' | 'published' | 'rejected' | 'archived';
  uploadedBy: string;
  signatureCertSha256?: string;
  verificationStatus?: 'verified' | 'suspicious' | 'invalid';
  verificationSummary?: string;
  hasManifest?: boolean;
  entryCount?: number;
  createdAt: string;
  publishedAt?: string;
}

export interface DeveloperSubmissionItem {
  id: string;
  developerName: string;
  developerEmail: string;
  appName: string;
  packageId: string;
  category: string;
  shortDescription: string;
  fullDescription: string;
  versionName: string;
  minAndroidVersion: string;
  privacyPolicyUrl: string;
  permissions: string[];
  authorizationDeclaration: {
    ownsCopyrightOrLicense: boolean;
    developerAuthorizedDistribution: boolean;
    termsAccepted: boolean;
    legalEntityStatement: string;
    submissionContactEmail: string;
  };
  apkFileName?: string;
  apkStoragePath?: string;
  apkFileSize?: number;
  apkSha256?: string;
  reviewStatus: 'submitted' | 'under_review' | 'approved' | 'rejected' | 'published' | 'suspended';
  reviewerId?: string;
  reviewNotes?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface AuditLogItem {
  id: string;
  actorId: string;
  actorEmail: string;
  action: string;
  targetRecordId: string;
  targetType: 'app' | 'release' | 'submission' | 'user' | 'system';
  details: Record<string, unknown>;
  timestamp: string;
  outcome: 'success' | 'failure';
}

export interface PlatformStats {
  publishedAppsCount: number;
  totalDownloadsRecorded: number;
  publishedReleasesCount: number;
  lastUpdated: string | null;
}
